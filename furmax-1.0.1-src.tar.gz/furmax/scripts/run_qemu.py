#!/usr/bin/env python3
"""启动 QEMU，等 Furmax 引导，截屏存 PNG，然后关机。"""
import os, socket, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
MON = "/tmp/furmax-mon.sock"
SHOT = "/tmp/furmax-shot.ppm"
PNG = os.path.join(BUILD, "screenshots", "m0.png")

WAIT = float(sys.argv[1]) if len(sys.argv) > 1 else 25

os.makedirs(os.path.dirname(PNG), exist_ok=True)
for p in (MON, SHOT):
    if os.path.exists(p):
        os.remove(p)

vars_src = "/usr/share/OVMF/OVMF_VARS_4M.fd"
vars_dst = os.path.join(BUILD, "vars.fd")
if not os.path.exists(vars_dst):
    subprocess.run(["cp", vars_src, vars_dst], check=True)

cmd = [
    "qemu-system-x86_64",
    "-machine", os.environ.get("MACHINE", "q35"),
    "-m", "256",
    "-smp", "1",
    "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd",
    "-drive", f"if=pflash,format=raw,unit=1,file={vars_dst}",
    "-drive", f"file={BUILD}/furmax.img,format=raw,if=ide",
    "-drive", f"file={BUILD}/furmax-data.img,format=raw,if=virtio",
    "-display", "none",
    "-monitor", f"unix:{MON},server,nowait",
    "-serial", f"file:{BUILD}/serial.log",
] + os.environ.get("EXTRA_QEMU", "").split()
print("starting qemu, waiting %.0fs ..." % WAIT, flush=True)
q = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

try:
    time.sleep(WAIT)
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(10)
    s.connect(MON)
    time.sleep(0.3)
    s.recv(65536)
    s.sendall(("screendump %s\n" % SHOT).encode())
    time.sleep(1.5)
    s.sendall(b"quit\n")
    time.sleep(0.5)
    s.close()
finally:
    try:
        q.wait(timeout=10)
    except subprocess.TimeoutExpired:
        q.kill()

if not os.path.exists(SHOT):
    print("NO SCREENSHOT", file=sys.stderr)
    print(q.stderr.read().decode()[-2000:] if q.stderr else "", file=sys.stderr)
    sys.exit(1)

subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "ppm2png.py"), SHOT, PNG], check=True)
print("saved", PNG)
