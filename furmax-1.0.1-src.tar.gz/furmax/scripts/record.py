#!/usr/bin/env python3
"""Furmax OS 无头录屏：从固件启动开始抓帧，中途注入鼠标操作，最后编码 mp4/gif。"""
import os, shutil, socket, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
MON = "/tmp/furmax-rec.sock"
FRAMES = os.path.join(BUILD, "frames")
OUT_MP4 = os.path.join(BUILD, "furmax-demo.mp4")
OUT_GIF = os.path.join(BUILD, "furmax-demo.gif")

DURATION = float(os.environ.get("DURATION", "90"))   # 上限，实际在演示结束后停止

# 相对“桌面首帧渲染完成”之后的秒数
ACTIONS = [
    (1.5, ("key", "ctrl-left")),    # 文件池
    (3.8, ("key", "ctrl-left")),
    (5.0, ("key", "ctrl-up")),      # 动效视窗
    (7.2, ("key", "ctrl-up")),
    (8.2, ("key", "ctrl-right")),   # 应用池
    (9.6, ("key", "down")),
    (10.0, ("key", "ret")),         # 启动选中的应用
    (14.0, ("key", "ctrl-down")),   # 设置
    (16.5, ("key", "ctrl-down")),
]

def send(s, cmd, wait=0.05):
    s.sendall((cmd + "\n").encode())
    time.sleep(wait)

def wait_stable(path, timeout=3.0):
    last = -1
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        try:
            sz = os.path.getsize(path)
        except OSError:
            time.sleep(0.01)
            continue
        if sz > 0 and sz == last:
            return True
        last = sz
        time.sleep(0.03)
    return os.path.exists(path)

def main():
    if os.path.isdir(FRAMES):
        shutil.rmtree(FRAMES)
    os.makedirs(FRAMES, exist_ok=True)
    for p in (MON,):
        if os.path.exists(p):
            os.remove(p)

    vars_dst = os.path.join(BUILD, "vars-rec.fd")
    shutil.copy("/usr/share/OVMF/OVMF_VARS_4M.fd", vars_dst)

    q = subprocess.Popen([
        "qemu-system-x86_64", "-machine", os.environ.get("MACHINE", "pc"),
        "-m", "256", "-smp", "1",
        "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd",
        "-drive", f"if=pflash,format=raw,unit=1,file={vars_dst}",
        "-drive", f"file={BUILD}/furmax.img,format=raw,if=ide",
    "-drive", f"file={BUILD}/furmax-data.img,format=raw,if=virtio",
        "-vnc", "127.0.0.1:7", "-monitor", f"unix:{MON},server,nowait",
        "-serial", "file:" + os.path.join(BUILD, "serial-rec.log"),
    ], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    t0 = time.monotonic()
    actions = list(ACTIONS)
    n = 0
    ok = 0
    action_base = None
    serial_path = os.path.join(BUILD, "serial-rec.log")

    try:
        time.sleep(1.0)
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(15)
        s.connect(MON)
        time.sleep(0.3)
        try:
            s.recv(65536)
        except socket.timeout:
            pass

        while True:
            now = time.monotonic() - t0
            if now >= DURATION:
                break

            if action_base is None:
                try:
                    with open(serial_path, "rb") as f:
                        if b"first frame rendered" in f.read():
                            action_base = time.monotonic()
                except OSError:
                    pass

            rel = (time.monotonic() - action_base) if action_base else 0
            if action_base and not actions and rel > 13.5:
                break
            while action_base and actions and rel >= actions[0][0]:
                _, act = actions.pop(0)
                if act[0] == "move":
                    send(s, f"mouse_move {act[1]} {act[2]}")
                elif act[0] == "button":
                    send(s, f"mouse_button {act[1]}")
                elif act[0] == "key":
                    send(s, f"sendkey {act[1]}", 0.1)

            shot = os.path.join(FRAMES, "f%05d.ppm" % n)
            send(s, f"screendump {shot}", 0.0)
            if wait_stable(shot):
                ok += 1
            n += 1

        send(s, "quit", 0.2)
        s.close()
    finally:
        try:
            q.wait(timeout=8)
        except subprocess.TimeoutExpired:
            q.kill()

    elapsed = time.monotonic() - t0
    fps = max(4, round(ok / elapsed, 2))
    print(f"captured {ok}/{n} frames in {elapsed:.1f}s -> {fps} fps")

    # 统一帧尺寸：固件前期 640x480，内核切模式后 1280x800
    from PIL import Image
    TW, TH = 1280, 800
    norm = os.path.join(BUILD, "frames_norm")
    if os.path.isdir(norm):
        shutil.rmtree(norm)
    os.makedirs(norm, exist_ok=True)
    for name in sorted(os.listdir(FRAMES)):
        if not name.endswith(".ppm"):
            continue
        path = os.path.join(FRAMES, name)
        try:
            im = Image.open(path).convert("RGB")
        except Exception:
            continue
        if im.size != (TW, TH):
            canvas = Image.new("RGB", (TW, TH), (0, 0, 0))
            x = (TW - im.size[0]) // 2
            y = (TH - im.size[1]) // 2
            canvas.paste(im, (x, y))
            im = canvas
        im.save(os.path.join(norm, name.replace(".ppm", ".png")))
    frames_dir = norm

    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(fps),
                    "-i", os.path.join(frames_dir, "f%05d.png"),
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20",
                    "-movflags", "+faststart", OUT_MP4], check=True)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(fps),
                    "-i", os.path.join(frames_dir, "f%05d.png"),
                    "-vf", "scale=720:-1:flags=lanczos,split[a][b];[a]palettegen[p];[b][p]paletteuse",
                    "-loop", "0", OUT_GIF], check=True)
    if not os.environ.get("KEEP_FRAMES"):
        shutil.rmtree(FRAMES, ignore_errors=True)
    print("saved", OUT_MP4)
    print("saved", OUT_GIF)

if __name__ == "__main__":
    main()
