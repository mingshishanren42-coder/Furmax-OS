#!/usr/bin/env python3
"""键盘输入测试：无头启动后注入按键，截图验证文本进入窗口。"""
import os, socket, subprocess, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
MON = "/tmp/furmax-type.sock"
SHOT = "/tmp/furmax-type.ppm"

for p in (MON, SHOT):
    if os.path.exists(p): os.remove(p)
subprocess.run(["cp", "/usr/share/OVMF/OVMF_VARS_4M.fd", BUILD + "/vars-type.fd"], check=True)

q = subprocess.Popen([
    "qemu-system-x86_64", "-machine", "pc", "-m", "256", "-smp", "1",
    "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd",
    "-drive", f"if=pflash,format=raw,unit=1,file={BUILD}/vars-type.fd",
    "-drive", f"file={BUILD}/furmax.img,format=raw,if=ide",
    "-vnc", "127.0.0.1:8", "-monitor", f"unix:{MON},server,nowait",
    "-serial", "file:" + BUILD + "/serial-type.log",
], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

try:
    time.sleep(20)
    s = socket.socket(socket.AF_UNIX); s.settimeout(10); s.connect(MON); time.sleep(0.3)
    try: s.recv(65536)
    except Exception: pass
    for k in ["f", "u", "r", "m", "a", "x", "spc", "o", "s"]:
        s.sendall(("sendkey %s\n" % k).encode()); time.sleep(0.25)
    time.sleep(1.0)
    s.sendall(("screendump %s\n" % SHOT).encode()); time.sleep(1.2)
    s.sendall(b"quit\n"); time.sleep(0.3)
    s.close()
finally:
    try: q.wait(timeout=8)
    except subprocess.TimeoutExpired: q.kill()

subprocess.run(["/usr/bin/python3", os.path.join(ROOT, "scripts", "ppm2png.py"),
                SHOT, os.path.join(BUILD, "screenshots", "typed.png")], check=True)
print("done")
