#!/usr/bin/env python3
"""无头交互测试：启动 QEMU，用鼠标注入拖动窗口，并在关键时刻截图。"""
import os, socket, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
MON = "/tmp/furmax-mon.sock"
SHOTS = os.path.join(BUILD, "screenshots")

def mon_send(s, cmd):
    s.sendall((cmd + "\n").encode())
    time.sleep(0.25)

def shot(s, name):
    path = os.path.join(SHOTS, name + ".ppm")
    mon_send(s, "screendump " + path)
    time.sleep(1.2)
    subprocess.run(["/usr/bin/python3", os.path.join(ROOT, "scripts", "ppm2png.py"),
                    path, os.path.join(SHOTS, name + ".png")], check=True)

os.makedirs(SHOTS, exist_ok=True)
for p in (MON,):
    if os.path.exists(p): os.remove(p)
vars_dst = os.path.join(BUILD, "vars.fd")
subprocess.run(["cp", "/usr/share/OVMF/OVMF_VARS_4M.fd", vars_dst], check=True)

q = subprocess.Popen([
    "qemu-system-x86_64", "-machine", os.environ.get("MACHINE", "pc"), "-m", "256", "-smp", "1",
    "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd",
    "-drive", f"if=pflash,format=raw,unit=1,file={vars_dst}",
    "-drive", f"file={BUILD}/furmax.img,format=raw,if=ide",
    "-drive", f"file={BUILD}/furmax-data.img,format=raw,if=virtio",
    "-display", "none", "-monitor", f"unix:{MON},server,nowait",
    "-serial", "file:" + os.path.join(BUILD, "serial.log"),
], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

try:
    time.sleep(28)     # 固件 + 开机画面 + 进入桌面
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(10)
    s.connect(MON); time.sleep(0.4); s.recv(65536)

    shot(s, "wm-start")

    # 光标初始在屏幕中心 (640,400)，移到前窗口灰条左侧(300,300)
    mon_send(s, "mouse_move -340 -100")
    time.sleep(0.6)
    shot(s, "wm-hover-bar")

    # 按住并拖动窗口右下
    mon_send(s, "mouse_button 1")
    time.sleep(0.4)
    mon_send(s, "mouse_move 180 120")
    time.sleep(0.8)
    mon_send(s, "mouse_button 0")
    time.sleep(0.8)
    shot(s, "wm-dragged")

    mon_send(s, "quit")
    time.sleep(0.5)
    s.close()
finally:
    try:
        q.wait(timeout=10)
    except subprocess.TimeoutExpired:
        q.kill()
    err = q.stderr.read().decode() if q.stderr else ""
    if err.strip():
        print("qemu stderr:", err[-500:])
print("done")
