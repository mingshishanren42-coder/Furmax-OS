#!/usr/bin/env bash
# Furmax OS 构建：编译 → 链接成 EFI 应用 → 装进 FAT 镜像
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build"
CC=x86_64-linux-gnu-gcc
LD=x86_64-linux-gnu-ld

CFLAGS=(-ffreestanding -fno-stack-protector -fno-pic -fno-pie
        -mno-red-zone -mno-stack-arg-probe -maccumulate-outgoing-args -mcmodel=large -fno-ident -fno-asynchronous-unwind-tables
        -O2 -Wall -Wextra -std=c11 -fno-zero-initialized-in-bss -DFMS_ENABLE ${EXTRA_CFLAGS:-})

mkdir -p "$OUT/efi/EFI/BOOT"

mkdir -p "$OUT"
nasm -f bin -o "$OUT/hello.bin" "$ROOT/src/user/hello.asm"
nasm -f bin -o "$OUT/greet.bin" "$ROOT/src/user/greet.asm"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/hello.bin" "$OUT/hello.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/greet.bin" "$OUT/greet.fx"
nasm -f bin -o "$OUT/ticker.bin" "$ROOT/src/user/ticker.asm"
nasm -f bin -o "$OUT/copy.bin" "$ROOT/src/user/copy.asm"
nasm -f bin -o "$OUT/ui.bin" "$ROOT/src/user/ui.asm"
nasm -f bin -o "$OUT/click.bin" "$ROOT/src/user/click.asm"
nasm -f bin -o "$OUT/notepad.bin" "$ROOT/src/user/notepad.asm"
nasm -f bin -o "$OUT/img.bin" "$ROOT/src/user/img.asm"
nasm -f bin -o "$OUT/crash.bin" "$ROOT/src/user/crash.asm"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/ticker.bin" "$OUT/ticker.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/copy.bin" "$OUT/copy.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/ui.bin" "$OUT/ui.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/click.bin" "$OUT/click.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/notepad.bin" "$OUT/notepad.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/img.bin" "$OUT/img.fx"
/usr/bin/python3 "$ROOT/tools/mkfx.py" "$OUT/crash.bin" "$OUT/crash.fx"
/usr/bin/python3 "$ROOT/tools/bin2c9.py" "$OUT/hello.fx" "$OUT/greet.fx" "$OUT/ticker.fx" "$OUT/copy.fx" "$OUT/ui.fx" "$OUT/click.fx" "$OUT/notepad.fx" "$OUT/img.fx" "$OUT/crash.fx" "$ROOT/src/kernel/apps_blob.h"

echo "[1/3] compile"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/boot" -I"$ROOT/src/kernel" -c "$ROOT/src/boot/main.c" -o "$OUT/main.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/boot" -c "$ROOT/src/boot/gfx.c" -o "$OUT/gfx.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/boot" -I"$ROOT/src/kernel" -c "$ROOT/src/boot/wm.c" -o "$OUT/wm.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/boot" -I"$ROOT/src/kernel" -c "$ROOT/src/boot/ps2.c" -o "$OUT/ps2.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/idt.c" -o "$OUT/idt.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/klog.c" -o "$OUT/klog.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/kmem.c" -o "$OUT/kmem.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -I"$ROOT/src/boot" -c "$ROOT/src/kernel/kbd.c" -o "$OUT/kbd.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/ata.c" -o "$OUT/ata.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/virtio.c" -o "$OUT/virtio.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/paging.c" -o "$OUT/paging.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/mfs.c" -o "$OUT/mfs.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/fsops.c" -o "$OUT/fsops.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/rtc.c" -o "$OUT/rtc.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/sha256.c" -o "$OUT/sha256.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/update.c" -o "$OUT/update.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/gdt.c" -o "$OUT/gdt.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/fms64.c" -o "$OUT/fms64.o"
nasm -f win64 -o "$OUT/isr.o" "$ROOT/src/kernel/isr.asm"
nasm -f win64 -o "$OUT/um.o" "$ROOT/src/kernel/um.asm"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -c "$ROOT/src/kernel/usermode.c" -o "$OUT/usermode.o"
"$CC" "${CFLAGS[@]}" -I"$ROOT/src/kernel" -I"$ROOT/src/boot" -c "$ROOT/src/kernel/sched.c" -o "$OUT/sched.o"

echo "[2/3] link -> PE/EFI"
"$LD" -m i386pep -nostdlib --subsystem 10 -e efi_main \
      -o "$OUT/efi/EFI/BOOT/BOOTX64.EFI" "$OUT/main.o" "$OUT/gfx.o" "$OUT/wm.o" "$OUT/ps2.o" "$OUT/idt.o" "$OUT/isr.o" "$OUT/klog.o" "$OUT/kmem.o" "$OUT/kbd.o" "$OUT/ata.o" "$OUT/virtio.o" "$OUT/fms64.o" "$OUT/paging.o" "$OUT/mfs.o" "$OUT/fsops.o" "$OUT/rtc.o" "$OUT/sha256.o" "$OUT/update.o" "$OUT/gdt.o" "$OUT/um.o" "$OUT/usermode.o" "$OUT/sched.o"

echo "[3/3] pack FAT image"
rm -f "$OUT/furmax.img"
dd if=/dev/zero of="$OUT/furmax.img" bs=1M count=64 status=none
mkfs.vfat -F 32 -n FURMAX "$OUT/furmax.img" >/dev/null
mcopy -i "$OUT/furmax.img" -s "$OUT/efi/EFI" "::/"

ls -l "$OUT/efi/EFI/BOOT/BOOTX64.EFI" "$OUT/furmax.img"
echo "done."
