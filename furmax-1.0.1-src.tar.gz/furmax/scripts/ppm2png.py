#!/usr/bin/env python3
"""PPM(P6) -> PNG，只依赖标准库。"""
import sys, zlib, struct

def main(src, dst, scale=1):
    data = open(src, 'rb').read()
    # 解析 P6 头
    parts, i = [], 0
    while len(parts) < 4:
        while data[i:i+1].isspace(): i += 1
        if data[i:i+1] == b'#':
            while data[i:i+1] != b'\n': i += 1
            continue
        j = i
        while not data[j:j+1].isspace(): j += 1
        parts.append(data[i:j]); i = j
    i += 1
    magic, w, h, maxv = parts[0], int(parts[1]), int(parts[2]), int(parts[3])
    assert magic == b'P6', magic
    px = data[i:i+w*h*3]
    if scale != 1:
        nw, nh = w*scale, h*scale
        out = bytearray()
        for y in range(h):
            row = bytearray()
            for x in range(w):
                o = (y*w+x)*3
                row += px[o:o+3] * scale
            out += row * scale
        px, w, h = bytes(out), nw, nh
    raw = b''.join(b'\x00' + px[y*w*3:(y+1)*w*3] for y in range(h))
    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n'
           + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(raw, 9))
           + chunk(b'IEND', b''))
    open(dst, 'wb').write(png)
    print(f'{dst} {w}x{h}')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 1)
