/* Furmax OS PS/2 鼠标驱动（轮询方式）
 * i8042: 0x64 状态/命令，0x60 数据。
 */
#include "ps2.h"
#include "kbd.h"

static inline void outb(unsigned short port, unsigned char v)
{
    __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(port));
}
static inline unsigned char inb(unsigned short port)
{
    unsigned char v;
    __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}

static int wait_write(void)
{
    for (int i = 0; i < 100000; i++)
        if (!(inb(0x64) & 0x02)) return 1;
    return 0;
}

static int wait_read(void)
{
    for (int i = 0; i < 100000; i++)
        if (inb(0x64) & 0x01) return 1;
    return 0;
}

static void flush_input(void)
{
    for (int i = 0; i < 64 && (inb(0x64) & 0x01); i++) (void)inb(0x60);
}

static void delay(unsigned n) { for (volatile unsigned i = 0; i < n; i++) ; }

/* 向鼠标发送一个字节 */
static int mouse_cmd(unsigned char c)
{
    for (int i = 0; i < 10000; i++) if (!(inb(0x64) & 0x02)) break;
    outb(0x64, 0xD4);
    for (int i = 0; i < 10000; i++) if (!(inb(0x64) & 0x02)) break;
    outb(0x60, c);
    return 1;
}

int ps2_mouse_init(void)
{
    flush_input();

    outb(0x64, 0xA8);          /* 打开辅助端口 */
    delay(1000);

    outb(0x64, 0x20);          /* 读配置字节 */
    delay(1000);
    unsigned char cfg = inb(0x60);
    cfg &= (unsigned char)~0x20;   /* 启用 aux 时钟 */
    cfg |= 0x02;                   /* 允许 aux 中断（鼠标 IRQ12） */
    outb(0x64, 0x60);
    delay(1000);
    outb(0x60, cfg);
    delay(1000);

    mouse_cmd(0xF6);           /* 默认参数 */
    delay(20000);
    flush_input();

    mouse_cmd(0xF4);           /* 开启数据上报 */
    delay(20000);

    for (int i = 0; i < 200000; i++) {
        if (inb(0x64) & 0x01) {
            unsigned char b = inb(0x60);
            if (b == 0xFA) return 1;
        }
    }
    return 19;
}

void ps2_mouse_flush(void)
{
    flush_input();
}

/* 解析鼠标字节流，累积成待取用的位移 */
static unsigned char mbuf[3];
static int mn;
static int pend_dx, pend_dy, pend_btn, has_pending;

void ps2_mouse_feed(unsigned char b)
{
    if (mn == 0 && !(b & 0x08)) return;   /* 首字节 bit3 必须为 1 */

    mbuf[mn++] = b;
    if (mn < 3) return;
    mn = 0;

    int x = (int)mbuf[1];
    int y = (int)mbuf[2];
    if (mbuf[0] & 0x10) x -= 256;
    if (mbuf[0] & 0x20) y -= 256;
    if (mbuf[0] & 0x40) x = 0;
    if (mbuf[0] & 0x80) y = 0;

    pend_dx += x;
    pend_dy += -y;
    pend_btn = mbuf[0] & 0x07;
    has_pending = 1;
}

/* 读出并清空累积位移 */
int ps2_mouse_poll(int *dx, int *dy, int *buttons)
{
    if (!has_pending) return 0;
    *dx = pend_dx;
    *dy = pend_dy;
    *buttons = pend_btn;
    pend_dx = pend_dy = 0;
    has_pending = 0;
    return 1;
}

/* 排空 i8042：键盘字节给键盘驱动，鼠标字节给解析器 */
void ps2_kbd_drain(void)
{
    unsigned long long flags;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(flags) :: "memory");
    for (int guard = 0; guard < 64; guard++) {
        unsigned char st = inb(0x64);
        if (!(st & 0x01)) break;
        unsigned char b = inb(0x60);
        if (st & 0x20) ps2_mouse_feed(b);
        else kbd_feed(b);
    }
    if (flags & 0x200) __asm__ volatile("sti" ::: "memory");
}

void ps2_drain(void)
{
    ps2_kbd_drain();
}
