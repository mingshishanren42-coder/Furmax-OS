/* Furmax OS 窗口管理器 + 四向面板 + FMS64 文件池
 * 运行在 ExitBootServices 之后的内核态。 */
#include "wm.h"
#include "klog.h"
#include "kbd.h"
#include "kmem.h"
#include "idt.h"
#include "gdt.h"
#include "ata.h"
#include "virtio.h"
#include "fms64.h"
#include "mfs.h"
#include "usermode.h"
#include "sched.h"
#include "apps_blob.h"
#include "fsops.h"
#include "rtc.h"
#include "update.h"

#define FURMAX_VERSION "1.0.1"
#include "ps2.h"

#define MAXW 9
#define BAR_H 44
#define BAR_INSET 14

typedef struct {
    int x, y, w, h;
    int alpha;
    int open;
    int minimized;
    const char *title;
    int sx, sy, sw, sh;
    int has_saved;
    char text[80];
    int tlen;
    char fname[48];
    int app_slot;
    int view;          /* 0 文本 1 表格 2 文档 3 幻灯片 */
    int term;
} Win;

static Win wins[MAXW] = {
    { 150, 260, 700, 400, 255, 1, 0, "桌面", 0,0,0,0, 0, {0}, 0, {0}, -1, 0, 0 },
    { 380, 150, 640, 380, 230, 1, 0, "记事本",    0,0,0,0, 0, {0}, 0, {0}, -1, 0, 0 },
    { 660, 330, 560, 360, 235, 1, 0, "TMI终端",       0,0,0,0, 0, {0}, 0, {0}, -1, 0, 1 },
    { 120, 300, 520, 300, 230, 0, 0, "", 0,0,0,0, 0, {0}, 0, {0}, 0, 0, 0 },
    { 420, 220, 520, 300, 230, 0, 0, "", 0,0,0,0, 0, {0}, 0, {0}, 1, 0, 0 },
    { 700, 330, 520, 300, 230, 0, 0, "", 0,0,0,0, 0, {0}, 0, {0}, 2, 0, 0 },
    { 240, 380, 520, 300, 230, 0, 0, "", 0,0,0,0, 0, {0}, 0, {0}, 3, 0, 0 },
    { 480, 380, 520, 300, 230, 0, 0, "", 0,0,0,0, 0, {0}, 0, {0}, 4, 0, 0 },
    { 720, 380, 520, 300, 230, 0, 0, "", 0,0,0,0, 0, {0}, 0, {0}, 5, 0, 0 },
};

static int zorder[MAXW] = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };
static int zcount = MAXW;
static int focus = 0;

static int mx, my, mprev_btn;
static int drag = -1, drag_dx, drag_dy;

static Fb *g_screen;
static Fb back;
static unsigned char *back_mem;
static unsigned char *wall_mem;
static int dirty = 1;

/* 四向面板 */
#define PANEL_NONE 0
#define PANEL_FILES 1
#define PANEL_ISLAND 2
#define PANEL_APPS 3
#define PANEL_SETTINGS 4

static int panel;
static unsigned long long panel_t0;

/* FMS64 */
static MfsEntry files[32];
static int file_count;
static int fs_ok;
static int file_sel;
static MfsEntry apps[16];
static int app_count, app_sel;
static char viewbuf[4096];
static unsigned int viewlen;
static int sheet_row, sheet_col, slide_idx, doc_scroll;

#define TERM_LINES 14
static char term_lines[TERM_LINES][72];
static int term_count;
static char term_hist[16][80];
static int term_hist_n;
static int term_hist_pos;
static char term_last[80];

#define GRID_ROWS 12
#define GRID_COLS 8
#define CELL_MAX 24
static char grid[GRID_ROWS][GRID_COLS][CELL_MAX];
static int grid_rows, grid_cols;
static int editing;
static char editbuf[CELL_MAX];
static int editlen;
static int disk_ok;
static unsigned long long disk_boot;

static int mouse_ok = 4;
static int ps2_stage;

static int str_len(const char *s) { int n = 0; while (s[n]) n++; return n; }

static void fs_write_through(const char *name, const void *data, unsigned int len)
{
    fs_persist_write(name, data, len);
}

static void fs_remove_both(const char *name)
{
    fs_persist_remove(name);
}

static int list_visible(void)
{
    MfsEntry all[64];
    int n = mfs_list(all, 32);
    file_count = 0;
    for (int i = 0; i < n && file_count < 32; i++) {
        if (all[i].name[0] == '.') continue;
        files[file_count++] = all[i];
    }
    return file_count;
}

static void term_hist_push(const char *cmd)
{
    if (!cmd[0]) return;
    int slot = term_hist_n % 16;
    int n = 0;
    while (cmd[n] && n < 79) { term_hist[slot][n] = cmd[n]; n++; }
    term_hist[slot][n] = 0;
    term_hist_n++;
    term_hist_pos = term_hist_n;
}

static void term_hist_recall(int dir, Win *w)
{
    if (term_hist_n == 0) return;
    if (dir < 0) {
        if (term_hist_pos > 0) term_hist_pos--;
    } else {
        if (term_hist_pos < term_hist_n) term_hist_pos++;
    }
    if (term_hist_pos >= term_hist_n) { w->tlen = 0; return; }
    const char *h = term_hist[term_hist_pos % 16];
    int k = 0;
    while (h[k] && k < 79) { w->text[k] = h[k]; k++; }
    w->tlen = k;
}

static void term_complete(Win *w)
{
    char pre[80];
    int k = 0;
    while (k < w->tlen && k < 79) { pre[k] = w->text[k]; k++; }
    pre[k] = 0;

    for (int i = 0; i < file_count; i++) {
        int ok = 1;
        for (int j = 0; pre[j]; j++) {
            char a = files[i].name[j], b = pre[j];
            if (a >= 'a' && a <= 'z') a -= 32;
            if (b >= 'a' && b <= 'z') b -= 32;
            if (!a || a != b) { ok = 0; break; }
        }
        if (!ok) continue;

        k = 0;
        while (files[i].name[k] && k < 79) { w->text[k] = files[i].name[k]; k++; }
        w->tlen = k;
        return;
    }
}

static void raise_to_front(int idx);
static void focus_window(int idx);
static void ps2_pump(void)
{
    ps2_drain();
}
static void u2s(unsigned long long v, char *out);
static void cat(char *dst, int *n, const char *src);
static void refresh_apps(void);
static int list_visible(void);

static int ci_eq(const char *a, const char *b)
{
    while (*a && *b) {
        char ca = *a++, cb = *b++;
        if (ca >= 'a' && ca <= 'z') ca -= 32;
        if (cb >= 'a' && cb <= 'z') cb -= 32;
        if (ca != cb) return 0;
    }
    return *a == *b;
}

static int term_wrap = 40;

static void term_push_line(const char *s)
{
    if (term_count >= TERM_LINES) {
        for (int i = 1; i < TERM_LINES; i++)
            for (int k = 0; k < 72; k++) term_lines[i-1][k] = term_lines[i][k];
        term_count = TERM_LINES - 1;
    }
    int n = 0;
    while (s[n] && n < 71) { term_lines[term_count][n] = s[n]; n++; }
    term_lines[term_count][n] = 0;
    term_count++;
}

static inline void outb_p(unsigned short port, unsigned char v)
{
    __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(port));
}

static inline void outw_p(unsigned short port, unsigned short v)
{
    __asm__ volatile("outw %0, %1" :: "a"(v), "Nd"(port));
}

static int fault_active;
static int fault_vec;
static unsigned long long fault_err, fault_rip;
static char fault_task[32];

void wm_show_fault(int vec, unsigned long long err, unsigned long long rip, const char *task)
{
    fault_active = 1;
    fault_vec = vec;
    fault_err = err;
    fault_rip = rip;
    int i = 0;
    if (task) { while (task[i] && i < 31) { fault_task[i] = task[i]; i++; } }
    fault_task[i] = 0;

    /* 直接画到屏幕上：内核崩溃时也需要可见 */
    Fb *fb = g_screen;
    if (!fb) return;
    int w = 620, h = 130;
    int x = ((int)fb->width - w) / 2;
    int y = 120;
    gfx_clip_off();
    gfx_round_rect(fb, x, y, w, h, 12, RGB(90, 20, 24), 245);
    gfx_round_rect(fb, x, y, w, h, 12, RGB(255, 120, 120), 60);
    gfx_text(fb, x + 22, y + 18, 3, RGB(255, 220, 220), 250, "SYSTEM FAULT");
    gfx_text(fb, x + 22, y + 56, 2, RGB(255, 235, 235), 240, "EXCEPTION");
    char buf[64];
    int n = 0;
    cat(buf, &n, "EXCEPTION ");
    char num[24];
    u2s((unsigned long long)vec, num);
    cat(buf, &n, num);
    cat(buf, &n, "  ERR ");
    u2s(err & 0xFFFF, num);
    cat(buf, &n, num);
    gfx_text(fb, x + 170, y + 56, 2, RGB(255, 235, 235), 240, buf);
    gfx_text(fb, x + 22, y + 86, 2, RGB(255, 210, 210), 235, "TASK");
    gfx_text(fb, x + 100, y + 86, 2, RGB(255, 235, 235), 240, fault_task[0] ? fault_task : "(KERNEL)");
}

static void term_print(const char *text)
{
    char line[72];
    int n = 0;
    for (int i = 0; text[i]; i++) {
        line[n++] = text[i];
        if (n >= term_wrap || !text[i+1]) {
            line[n] = 0;
            term_push_line(line);
            n = 0;
        }
    }
    if (!text[0]) term_push_line("");
}

static void open_task_window(int slot, int alpha)
{
    if (slot < 0) return;
    Win *aw = &wins[3 + slot];
    aw->open = 1;
    aw->title = sched_name(slot);
    aw->alpha = alpha;
    aw->view = 0;
    /* 3 列 × 2 行网格，避免窗口互相叠住 */
    {
        int W = (int)back.width, H = (int)back.height;
        int gap = 14, top = 104, bottom = 74;
        int cellw = (W - gap * 4) / 3;
        int cellh = (H - top - bottom - gap * 3) / 2;
        int col = slot % 3, row = slot / 3;
        aw->x = gap + col * (cellw + gap);
        aw->y = top + gap + row * (cellh + gap);
        aw->w = cellw;
        aw->h = cellh;
    }
    focus_window(3 + slot);
    raise_to_front(3 + slot);
}

/* ---------- 目录（基于路径化文件名的轻量实现） ---------- */
static char cwd[40] = "";        /* "" 表示根目录，否则形如 "DOC" */

static void path_resolve(const char *arg, char *out)
{
    int k = 0;
    if (arg[0] == '/') {
        const char *p = arg;
        while (*p == '/') p++;
        while (*p && k < 38) out[k++] = *p++;
        out[k] = 0;
        return;
    }
    for (int i = 0; cwd[i] && k < 38; i++) out[k++] = cwd[i];
    if (cwd[0] && k < 38) out[k++] = '/';
    for (int i = 0; arg[i] && k < 38; i++) out[k++] = arg[i];
    out[k] = 0;
}

/* 判断某路径是否是目录：存在 "path/..." 形式的文件即视为目录 */
static int dir_exists(const char *path)
{
    MfsEntry all[64];
    int n = mfs_list(all, 32);
    int len = str_len(path);
    if (len == 0) return 1;
    for (int i = 0; i < n; i++) {
        if (all[i].name[0] == '.') continue;
        int ok = 1;
        for (int j = 0; j < len; j++)
            if (all[i].name[j] != path[j]) { ok = 0; break; }
        if (ok && all[i].name[len] == '/') return 1;
    }
    return 0;
}

static void dir_list(const char *path)
{
    MfsEntry all[64];
    int n = mfs_list(all, 32);
    int len = str_len(path);
    char shown[8][24];
    int shown_n = 0;

    for (int i = 0; i < n; i++) {
        if (all[i].name[0] == '.') continue;

        int ok = 1;
        for (int j = 0; j < len; j++)
            if (all[i].name[j] != path[j]) { ok = 0; break; }
        if (!ok) continue;

        const char *rest = all[i].name + len;
        if (len && *rest == '/') rest++;

        if (*rest == '.') continue;      /* 隐藏 .dir 标记等系统项 */

        char item[24];
        int k = 0, isdir = 0;
        while (*rest && k < 22) {
            if (*rest == '/') { isdir = 1; break; }
            item[k++] = *rest++;
        }
        if (k == 0) continue;
        item[k] = 0;
        if (isdir) { item[k++] = '/'; item[k] = 0; }

        int dup = 0;
        for (int j = 0; j < shown_n; j++) {
            int same = 1;
            for (int m = 0; shown[j][m] || item[m]; m++)
                if (shown[j][m] != item[m]) { same = 0; break; }
            if (same) { dup = 1; break; }
        }
        if (dup) continue;
        if (shown_n < 8) {
            for (int m = 0; m <= k; m++) shown[shown_n][m] = item[m];
            shown_n++;
        }
        term_print(item);
    }
    if (shown_n == 0) term_print("(空)");
}

static void term_exec(const char *cmd)
{
    char line[80];
    int n = 0;
    while (*cmd && n < 79) line[n++] = *cmd++;
    line[n] = 0;

    char *p = line;
    while (*p == ' ') p++;
    char *verb = p;
    while (*p && *p != ' ') p++;
    if (*p) *p++ = 0;
    while (*p == ' ') p++;
    char *arg = p;

    char echo[80];
    int k = 0;
    echo[k++] = '>';
    echo[k++] = ' ';
    for (int i = 0; line[i] && k < 70; i++) echo[k++] = line[i];
    if (arg[0]) { echo[k++] = ' '; for (int i = 0; arg[i] && k < 70; i++) echo[k++] = arg[i]; }
    echo[k] = 0;
    term_print(echo);

    if (!verb[0]) return;

    if (ci_eq(verb, "shutdown") || ci_eq(verb, "poweroff")) {
        term_print("POWER OFF");
        outw_p(0x604, 0x2000);     /* QEMU ACPI PM1a_CNT */
        outw_p(0xB004, 0x2000);    /* 旧式 ACPI 端口 */
        for (;;) __asm__ volatile("cli; hlt");
    }

    if (ci_eq(verb, "reboot")) {
        term_print("REBOOTING");
        outb_p(0x64, 0xFE);        /* 键盘控制器复位 */
        for (;;) __asm__ volatile("cli; hlt");
    }

    if (ci_eq(verb, "update")) {
        int st = update_state();
        if (st == 0) { term_print("无更新包 (UPDATE.PKG)"); return; }
        char line[48];
        int k = 0;
        cat(line, &k, st == 1 ? "更新包有效 版本 " : "更新包无效：");
        if (st == 1) {
            char num[16];
            u2s(update_version() >> 16, num); cat(line, &k, num); cat(line, &k, ".");
            u2s((update_version() >> 8) & 0xFF, num); cat(line, &k, num); cat(line, &k, ".");
            u2s(update_version() & 0xFF, num); cat(line, &k, num);
        }
        line[k] = 0;
        term_print(line);
        term_print(update_message());
        return;
    }

    if (ci_eq(verb, "lic") || ci_eq(verb, "licenses")) {
        term_print("FURMAX OS (C) 2026 DEEPBLUE NETWORK - APACHE-2.0");
        term_print("FONT: NOTO SANS CJK, SIL OFL 1.1");
        term_print("TOOLS: GCC/BINUTILS GPL, NASM BSD");
        term_print("TEST: QEMU GPLV2, OVMF BSD (NOT SHIPPED)");
        return;
    }

    if (ci_eq(verb, "date") || ci_eq(verb, "time")) {
        RtcTime rt;
        rtc_read(&rt);
        char b[48];
        int k = 0;
        char tmp[8];
        u2s((unsigned long long)rt.year, tmp);
        cat(b, &k, tmp);
        cat(b, &k, "-");
        if (rt.month < 10) b[k++] = '0';
        u2s((unsigned long long)rt.month, tmp); cat(b, &k, tmp);
        cat(b, &k, "-");
        if (rt.day < 10) b[k++] = '0';
        u2s((unsigned long long)rt.day, tmp); cat(b, &k, tmp);
        cat(b, &k, "  ");
        if (rt.hour < 10) b[k++] = '0';
        u2s((unsigned long long)rt.hour, tmp); cat(b, &k, tmp);
        b[k++] = ':';
        if (rt.minute < 10) b[k++] = '0';
        u2s((unsigned long long)rt.minute, tmp); cat(b, &k, tmp);
        b[k++] = ':';
        if (rt.second < 10) b[k++] = '0';
        u2s((unsigned long long)rt.second, tmp); cat(b, &k, tmp);
        b[k] = 0;
        term_print(b);
        return;
    }

    if (ci_eq(verb, "ver") || ci_eq(verb, "version")) {
        term_print("FURMAX OS " FURMAX_VERSION " (TEST BUILD)");
        term_print("(C) 2026 DEEPBLUE NETWORK - ALL RIGHTS RESERVED");
        return;
    }

    if (ci_eq(verb, "help")) {
        term_print("COMMANDS: LS CAT RM RUN CLEAR");
        return;
    }
    if (ci_eq(verb, "clear")) { term_count = 0; return; }

    if (ci_eq(verb, "pwd")) {
        char b[48];
        int k = 0;
        b[k++] = '/';
        for (int i = 0; cwd[i] && k < 46; i++) b[k++] = cwd[i];
        b[k] = 0;
        term_print(b);
        return;
    }

    if (ci_eq(verb, "cd")) {
        char path[40];
        if (!arg[0]) { cwd[0] = 0; return; }
        path_resolve(arg, path);
        if (!dir_exists(path)) { term_print("目录不存在"); return; }
        int k = 0;
        while (path[k] && k < 38) { cwd[k] = path[k]; k++; }
        cwd[k] = 0;
        return;
    }

    if (ci_eq(verb, "mkdir")) {
        if (!arg[0]) { term_print("用法：mkdir 目录名"); return; }
        char path[40], mk[48];
        path_resolve(arg, path);
        int k = 0;
        for (int i = 0; path[i] && k < 40; i++) mk[k++] = path[i];
        mk[k++] = '/'; mk[k++] = '.'; mk[k++] = 'd'; mk[k++] = 'i'; mk[k++] = 'r';
        mk[k] = 0;
        int rc = -1;
        if (disk_ok) rc = fms_mkdir(path);
        if (rc != 0) {
            mfs_write(mk, "1", 1, 0);      /* 无磁盘时退回标记文件 */
            fs_write_through(mk, "1", 1);
        }
        if (rc == -2) { term_print("目录已存在"); return; }
        term_print("已创建");
        file_count = list_visible();
        refresh_apps();
        return;
    }

    if (ci_eq(verb, "ls")) {
        char path[40];
        if (arg[0]) path_resolve(arg, path);
        else { int k = 0; while (cwd[k] && k < 38) { path[k] = cwd[k]; k++; } path[k] = 0; }

        if (disk_ok) {
            FmsEntry de[16];
            int n = fms_readdir(path, de, 16);
            if (n < 0) { term_print("目录不存在"); return; }
            if (n == 0) { term_print("（空）"); return; }
            for (int i = 0; i < n; i++) {
                char line[40];
                int k = 0;
                for (int j = 0; de[i].name[j] && k < 30; j++) line[k++] = de[i].name[j];
                line[k] = 0;
                term_print(line);
            }
            return;
        }
        dir_list(path);
        return;
    }

    if (ci_eq(verb, "cat")) {
        if (!arg[0]) { term_print("USAGE: CAT NAME"); return; }
        static char tmp[512];
        unsigned int sz = 0;
        char path[40];
        path_resolve(arg, path);
        if (mfs_read(path, tmp, sizeof(tmp) - 1, &sz) != 0) { term_print("文件不存在"); return; }
        tmp[sz < sizeof(tmp) ? sz : sizeof(tmp) - 1] = 0;
        char l[72];
        int m = 0;
        for (unsigned int i = 0; i < sz && m < 71; i++) {
            char ch = tmp[i];
            if (ch == '\n') { l[m] = 0; term_print(l); m = 0; continue; }
            l[m++] = (ch >= 32 && ch < 127) ? ch : ' ';
        }
        l[m] = 0;
        if (m) term_print(l);
        return;
    }

    if (ci_eq(verb, "rm")) {
        if (!arg[0]) { term_print("USAGE: RM NAME"); return; }
        fs_remove_both(arg);
        mfs_remove(arg);
        file_count = list_visible();
        refresh_apps();
        term_print("REMOVED");
        return;
    }

    if (ci_eq(verb, "kill")) {
        if (!arg[0]) { term_print("USAGE: KILL NAME"); return; }
        for (int i = 0; i < 3; i++) {
            if (sched_running(i) && ci_eq(sched_name(i), arg)) {
                sched_kill(i);
                for (int wi = 0; wi < MAXW; wi++)
                    if (wins[wi].app_slot == i) wins[wi].open = 0;
                term_print("KILLED");
                return;
            }
        }
        char b[48];
        int k = 0;
        cat(b, &k, "NO TASK ");
        for (int j = 0; arg[j] && k < 40; j++) b[k++] = arg[j];
        b[k] = 0;
        term_print(b);
        return;
    }

    if (ci_eq(verb, "run")) {
        if (!arg[0]) { term_print("USAGE: RUN NAME"); return; }
        char appname[48];
        int k2 = 0;
        char *q2 = arg;
        while (*q2 && *q2 != ' ' && k2 < 47) appname[k2++] = *q2++;
        appname[k2] = 0;
        while (*q2 == ' ') q2++;
        int slot = sched_spawn_args(appname, q2);
        if (slot < 0) { term_print("CANNOT RUN"); return; }
        open_task_window(slot, 235);
        term_print("STARTED");
        return;
    }

    if (ci_eq(verb, "echo")) { term_print(arg); return; }

    if (ci_eq(verb, "uptime")) {
        char b[40];
        int k = 0;
        cat(b, &k, "UPTIME ");
        char num[16];
        u2s(kernel_ticks / 100, num);
        cat(b, &k, num);
        cat(b, &k, " S");
        term_print(b);
        return;
    }

    if (ci_eq(verb, "df")) {
        char b[40];
        int k = 0;
        cat(b, &k, "FREE ");
        char num[16];
        u2s((unsigned long long)fs_free_blocks() / 2 / 1024, num);
        cat(b, &k, num);
        cat(b, &k, " MB");
        term_print(b);
        return;
    }

    if (ci_eq(verb, "ps")) {
        int any = 0;
        for (int i = 0; i < 3; i++) {
            if (!sched_used(i)) continue;
            char b[48];
            int k = 0;
            cat(b, &k, sched_name(i));
            cat(b, &k, sched_running(i) ? "  RUN" : "  DONE");
            term_print(b);
            any = 1;
        }
        if (!any) term_print("NO TASKS");
        return;
    }

    if (ci_eq(verb, "cp") || ci_eq(verb, "mv")) {
        char a1[48], a2[48];
        int k = 0;
        char *q = arg;
        while (*q == ' ') q++;
        while (*q && *q != ' ' && k < 47) a1[k++] = *q++;
        a1[k] = 0;
        while (*q == ' ') q++;
        k = 0;
        while (*q && *q != ' ' && k < 47) a2[k++] = *q++;
        a2[k] = 0;

        if (!a1[0] || !a2[0]) { term_print("USAGE: CP SRC DST"); return; }

        static char buf[1024];
        unsigned int sz = 0;
        if (mfs_read(a1, buf, sizeof(buf), &sz) != 0) { term_print("NO SUCH FILE"); return; }
        mfs_write(a2, buf, sz, 0);
        fs_write_through(a2, buf, sz);
        if (ci_eq(verb, "mv")) {
            fs_remove_both(a1);
            mfs_remove(a1);
        }
        file_count = list_visible();
        refresh_apps();
        term_print("OK");
        return;
    }

    term_print("UNKNOWN COMMAND");
}

static void refresh_apps(void)
{
    MfsEntry all[64];
    int n = mfs_list(all, 32);
    app_count = 0;
    for (int i = 0; i < n && app_count < 16; i++) {
        if (all[i].name[0] == '.') continue;
        int len = str_len(all[i].name);
        if (len > 3 && all[i].name[len-3] == '.' &&
            (all[i].name[len-2] == 'f' || all[i].name[len-2] == 'F') &&
            (all[i].name[len-1] == 'x' || all[i].name[len-1] == 'X')) {
            apps[app_count++] = all[i];
        }
    }
    if (app_sel >= app_count) app_sel = app_count > 0 ? app_count - 1 : 0;
}


static void u2s(unsigned long long v, char *out)
{
    char d[24]; int k = 0;
    if (!v) d[k++] = '0';
    while (v) { d[k++] = (char)('0' + v % 10); v /= 10; }
    int n = 0;
    while (k) out[n++] = d[--k];
    out[n] = 0;
}

static int ease(int t)
{
    if (t >= 100) return 100;
    if (t <= 0) return 0;
    return t * t * (300 - 2 * t) / 10000;
}

static int panel_progress(void)
{
    if (!panel) return 0;
    unsigned long long dt = kernel_ticks - panel_t0;
    if (dt >= 14) return 100;
    return (int)(dt * 100 / 14);
}

static void cat(char *dst, int *n, const char *src)
{
    for (int i = 0; src[i]; i++) dst[(*n)++] = src[i];
    dst[*n] = 0;
}

/* ---------- 窗口绘制 ---------- */

static void draw_bar(Fb *fb, Win *w)
{
    int bx = w->x + BAR_INSET, by = w->y + BAR_INSET;
    int bw = w->w - BAR_INSET * 2;

    gfx_round_rect(fb, bx, by, bw, BAR_H, BAR_H / 2, RGB(150, 152, 160), 96);
    gfx_round_rect(fb, bx, by, bw, BAR_H, BAR_H / 2, RGB(255, 255, 255), 20);

    gfx_text_cn(fb, bx + 22, by + BAR_H / 2 - 7, 2, RGB(255, 255, 255), 235, w->title);

    static const Rgb colors[3] = {   /* i=0 最右 */
        { 232, 96, 92 },               /* 红：关闭 */
        { 122, 196, 108 },             /* 绿：最大化 */
        { 240, 196, 96 }               /* 橙：最小化 */
    };
    int r = 8, cy = by + BAR_H / 2, cx = bx + bw - 26;
    for (int i = 0; i < 3; i++) {
        int px = cx - i * 25;
        gfx_round_rect(fb, px - r, cy - r, r * 2, r * 2, r, colors[i], 240);
        gfx_round_rect(fb, px - r + 3, cy - r + 3, r * 2 - 6, r * 2 - 6, r,
                       RGB(255, 255, 255), 40);
    }
}

static void csv_load(void)
{
    grid_rows = grid_cols = 0;
    for (int r = 0; r < GRID_ROWS; r++)
        for (int c = 0; c < GRID_COLS; c++) grid[r][c][0] = 0;

    const char *p = viewbuf;
    int r = 0;
    while (*p && r < GRID_ROWS) {
        int c = 0;
        while (*p && *p != '\n' && c < GRID_COLS) {
            int n = 0;
            while (*p && *p != ',' && *p != '\n' && n < CELL_MAX - 1) grid[r][c][n++] = *p++;
            grid[r][c][n] = 0;
            if (*p == ',') p++;
            if (n > 0 && c + 1 > grid_cols) grid_cols = c + 1;
            c++;
        }
        if (*p == '\n') p++;
        r++;
    }
    grid_rows = r;
    if (grid_cols < 4) grid_cols = 4;
}

static int csv_save(Win *w)
{
    int n = 0;
    for (int r = 0; r < grid_rows; r++) {
        for (int c = 0; c < grid_cols; c++) {
            if (c) viewbuf[n++] = ',';
            for (int i = 0; grid[r][c][i] && n < (int)sizeof(viewbuf) - 2; i++)
                viewbuf[n++] = grid[r][c][i];
        }
        viewbuf[n++] = '\n';
    }
    viewbuf[n] = 0;
    viewlen = (unsigned int)n;

    mfs_write(w->fname, viewbuf, viewlen, 0);
    fs_write_through(w->fname, viewbuf, viewlen);
    file_count = list_visible();
    return 0;
}

static int ends_with(const char *name, const char *ext)
{
    int n = str_len(name), e = str_len(ext);
    if (n < e) return 0;
    for (int i = 0; i < e; i++) {
        char a = name[n - e + i], b = ext[i];
        if (a >= 'a' && a <= 'z') a -= 32;
        if (b >= 'a' && b <= 'z') b -= 32;
        if (a != b) return 0;
    }
    return 1;
}

static void draw_toolbar(Fb *fb, int x, int y, int w, const char *title, Rgb accent)
{
    gfx_rect(fb, x, y, w, 34, RGB(244, 247, 251), 255);
    gfx_rect(fb, x, y + 34, w, 1, RGB(210, 220, 232), 255);
    gfx_text(fb, x + 14, y + 11, 2, accent, 235, title);

    for (int i = 0; i < 3; i++) {
        int bx = x + w - 26 - i * 26;
        gfx_round_rect(fb, bx - 6, y + 11, 12, 12, 6, RGB(190, 200, 215), 255);
    }
}

static void draw_sheet_view(Fb *fb, Win *w)
{
    int x = w->x + 1, y = w->y + 72, wd = w->w - 2, ht = w->h - 74;
    draw_toolbar(fb, x, y, wd, "SHEET", RGB(60, 110, 60));

    int grid_y = y + 80, grid_h = ht - 80 - 30;
    int cw = 104, rh = 26, rowhdr = 44, colhdr = 24;
    int cols = (wd - 40) / cw;
    if (cols > 8) cols = 8;
    if (cols < 1) cols = 1;

    gfx_rect(fb, x + 16, grid_y - colhdr, cols * cw + rowhdr + 2, colhdr + grid_h + 2,
             RGB(255, 255, 255), 255);
    gfx_rect(fb, x + 16, grid_y - colhdr, cols * cw + rowhdr + 2, colhdr, RGB(236, 241, 247), 255);

    for (int c = 0; c < cols; c++) {
        char lab[4];
        lab[0] = (char)('A' + c);
        lab[1] = 0;
        gfx_text(fb, x + 16 + rowhdr + c * cw + 12, grid_y - colhdr + 6, 2,
                 RGB(110, 125, 145), 240, lab);
    }

    for (int row = 0; row < grid_rows && row < (grid_h / rh) && row < GRID_ROWS; row++) {
        int ry = grid_y + row * rh;
        char rl[4];
        u2s((unsigned long long)(row + 1), rl);
        gfx_text(fb, x + 28, ry + 6, 2, RGB(110, 125, 145), 240, rl);
        gfx_rect(fb, x + 16, ry + rh - 1, cols * cw + rowhdr, 1, RGB(228, 234, 242), 255);

        for (int col = 0; col < grid_cols && col < cols; col++) {
            const char *cell = grid[row][col];
            if (editing && row == sheet_row && col == sheet_col) cell = editbuf;

            Rgb tc = (row == 0) ? RGB(70, 95, 125) : RGB(55, 65, 80);
            gfx_text(fb, x + 16 + rowhdr + col * cw + 10, ry + 6, 2, tc, 235, cell);
            gfx_rect(fb, x + 16 + rowhdr + col * cw, ry, 1, rh, RGB(232, 237, 244), 255);
        }
    }

    char ref[8];
    int k = 0;
    ref[k++] = (char)('A' + sheet_col);
    u2s((unsigned long long)(sheet_row + 1), ref + k);
    k = 1 + str_len(ref + 1);

    int sx = x + 16 + rowhdr + sheet_col * cw;
    int sy = grid_y + sheet_row * rh;
    gfx_rect(fb, sx, sy, cw, 2, RGB(59, 130, 246), 255);
    gfx_rect(fb, sx, sy + rh - 2, cw, 2, RGB(59, 130, 246), 255);
    gfx_rect(fb, sx, sy, 2, rh, RGB(59, 130, 246), 255);
    gfx_rect(fb, sx + cw - 2, sy, 2, rh, RGB(59, 130, 246), 255);

    gfx_rect(fb, x, y + ht - 28, wd, 28, RGB(244, 247, 251), 255);
    gfx_text(fb, x + 14, y + ht - 20, 2, RGB(60, 110, 60), 235, "SHEET1");
    gfx_text(fb, x + 120, y + ht - 20, 2, RGB(120, 130, 145), 220, ref);
}

static void draw_doc_view(Fb *fb, Win *w)
{
    int x = w->x + 1, y = w->y + 72, wd = w->w - 2, ht = w->h - 74;
    draw_toolbar(fb, x, y, wd, "DOCUMENT", RGB(40, 80, 140));

    int px = x + 26, py = y + 48, pw = wd - 52, ph = ht - 48 - 16;
    gfx_round_rect(fb, px + 3, py + 4, pw, ph, 4, RGB(0, 0, 0), 30);
    gfx_rect(fb, px, py, pw, ph, RGB(255, 255, 255), 255);

    const char *p = viewbuf;
    int maxchars = (pw - 60) / 12;
    if (maxchars < 8) maxchars = 8;

    int ty = py + 28 - doc_scroll * 24;
    int first = 1;

    while (*p && ty < py + ph - 24) {
        char buf[80];
        int n = 0;
        while (*p && *p != '\n' && n < maxchars && n < 76) buf[n++] = *p++;
        buf[n] = 0;
        if (*p == '\n') p++;
        if (n == 0) { ty += first ? 20 : 12; if (first) first = 0; continue; }

        if (first) {
            gfx_text(fb, px + 30, ty, 3, RGB(30, 40, 55), 255, buf);
            ty += 52;
            first = 0;
        } else {
            gfx_text(fb, px + 30, ty, 2, RGB(70, 80, 95), 245, buf);
            ty += 24;
        }
    }
}

static void draw_slide_view(Fb *fb, Win *w)
{
    int x = w->x + 1, y = w->y + 72, wd = w->w - 2, ht = w->h - 74;
    draw_toolbar(fb, x, y, wd, "SLIDES", RGB(150, 80, 40));

    int rail = 96;
    gfx_rect(fb, x, y + 36, rail, ht - 36, RGB(240, 244, 249), 255);
    gfx_rect(fb, x + rail, y + 36, 1, ht - 36, RGB(215, 222, 232), 255);

    int total = 1;
    for (int i = 0; viewbuf[i]; i++)
        if (viewbuf[i] == '-' && viewbuf[i+1] == '-' && viewbuf[i+2] == '-') total++;

    for (int i = 0; i < total && i < 4; i++) {
        int ty = y + 50 + i * 62;
        gfx_round_rect(fb, x + 14, ty, 68, 44, 3,
                       i == slide_idx ? RGB(255, 255, 255) : RGB(228, 234, 242), 255);
        gfx_round_rect(fb, x + 14, ty, 68, 44, 3,
                       i == slide_idx ? RGB(200, 120, 40) : RGB(200, 210, 222), 255);
        char num[4];
        u2s((unsigned long long)(i + 1), num);
        gfx_text(fb, x + 22, ty + 16, 2, RGB(120, 130, 145), 220, num);
    }

    int sx = x + rail + 26, sy = y + 52;
    int sw = wd - rail - 52, sh = sw * 9 / 16;
    int maxh = ht - 52 - 40;
    if (sh > maxh) { sh = maxh; sw = sh * 16 / 9; }
    gfx_round_rect(fb, sx + 3, sy + 4, sw, sh, 4, RGB(0, 0, 0), 30);
    gfx_rect(fb, sx, sy, sw, sh, RGB(255, 255, 255), 255);

    const char *p = viewbuf;
    int page = 0;
    while (*p && page < slide_idx) {
        if (p[0] == '-' && p[1] == '-' && p[2] == '-') { page++; p += 3; }
        else p++;
    }

    int line = 0;
    while (*p && line < 5) {
        if (p[0] == '-' && p[1] == '-' && p[2] == '-') break;
        char buf[60];
        int n = 0;
        while (*p && *p != '\n' && n < 50) buf[n++] = *p++;
        buf[n] = 0;
        if (*p == '\n') p++;

        int ty = sy + 34 + line * 34;
        if (line == 0)
            gfx_text(fb, sx + 28, ty, 3, RGB(35, 45, 60), 255, buf);
        else if (n > 0)
            gfx_text(fb, sx + 28, ty, 2, RGB(90, 100, 118), 240, buf);
        line++;
    }

    char info[24];
    int k = 0;
    cat(info, &k, "SLIDE ");
    char num[8];
    u2s((unsigned long long)(slide_idx + 1), num);
    cat(info, &k, num);
    cat(info, &k, "/");
    u2s((unsigned long long)total, num);
    cat(info, &k, num);
    gfx_text(fb, x + wd - 150, y + ht - 22, 2, RGB(140, 150, 165), 220, info);
}

static void draw_view(Fb *fb, Win *w)
{
    if (w->view == 1) draw_sheet_view(fb, w);
    else if (w->view == 2) draw_doc_view(fb, w);
    else if (w->view == 3) draw_slide_view(fb, w);
}

static void draw_win(Fb *fb, Win *w, int focused)
{
    int h = w->minimized ? (BAR_INSET * 2 + BAR_H) : w->h;

    gfx_round_rect(fb, w->x - 6, w->y + 8, w->w + 12, h + 6, 20, RGB(0, 0, 0), 70);
    gfx_round_rect(fb, w->x, w->y, w->w, h, 16, RGB(26, 30, 40), w->alpha);
    gfx_round_rect(fb, w->x, w->y, w->w, h, 16, RGB(255, 255, 255), 14);
    draw_bar(fb, w);

    if (w->minimized) return;

    if (w->view) {
        gfx_rect(fb, w->x + 1, w->y + 60, w->w - 2, w->h - 61, RGB(233, 238, 245), 255);
        draw_view(fb, w);
        return;
    }

    int cx = w->x + 40, cy = w->y + 108;
    if (!w->term && w->app_slot < 0)
        gfx_text_cn(fb, cx, cy, 2, RGB(255, 255, 255), 235, w->title);

    if (w->term) {
        int visible = (w->h - 130) / 22;
        if (visible < 1) visible = 1;
        int start = term_count > visible ? term_count - visible : 0;
        int ty = w->y + 76;
        for (int i = start; i < term_count; i++) {
            gfx_text_cn(fb, cx, ty, 2, RGB(150, 210, 170), 230, term_lines[i]);
            ty += 22;
        }
        gfx_text(fb, cx, ty, 2, RGB(120, 200, 255), 235, ">");
        if (w->tlen > 0) {
            char line[80];
            int k = w->tlen > 52 ? 52 : w->tlen;
            for (int i = 0; i < k; i++) {
                char ch = w->text[w->tlen - k + i];
                line[i] = (ch >= 32 && ch < 127) ? ch : ' ';
            }
            line[k] = 0;
            gfx_text(fb, cx + 18, ty, 2, RGB(255, 255, 255), 240, line);
        }
        if (focused)
            gfx_text(fb, cx + 18 + 12 * (w->tlen > 52 ? 52 : w->tlen), ty, 2,
                     RGB(120, 200, 255), 230, (kernel_ticks / 50) % 2 ? "_" : " ");
        return;
    }

    if (w->app_slot >= 0) {
        int cnt = 0;
        const UiOp *uops = ui_ops(w->app_slot, &cnt);
        if (cnt > 0) {
            int ox = w->x + 16, oy = w->y + 76;
            for (int i = 0; i < cnt; i++) {
                const UiOp *u = &uops[i];
                Rgb c = RGB((u->color >> 16) & 0xFF, (u->color >> 8) & 0xFF, u->color & 0xFF);
                if (u->type == 3) {
                    int iw = 0, ih = 0;
                    const unsigned char *px = ui_image_data(w->app_slot, &iw, &ih);
                    if (px && iw > 0 && ih > 0) {
                        for (int yy = 0; yy < u->h && yy < ih; yy++) {
                            for (int xx = 0; xx < u->w && xx < iw; xx++) {
                                const unsigned char *p4 = px + (yy * iw + xx) * 4;
                                Rgb col = RGB(p4[0], p4[1], p4[2]);
                                gfx_rect(fb, ox + u->x + xx, oy + u->y + yy, 1, 1, col, 255);
                            }
                        }
                    }
                } else if (u->type == 2) {
                    gfx_rect(fb, ox + u->x, oy + u->y, u->w, u->h, c, 255);
                } else if (u->type == 1) {
                    gfx_text(fb, ox + u->x, oy + u->y, 2, c, 245, u->text);
                }
            }
            return;
        }

        const char *o = sched_output(w->app_slot);
        int row = 0;
        char line[26];
        for (int i = 0; o[i] && row < 4; row++) {
            int n = 0;
            while (o[i] && n < 24 && o[i] != '\n') {
                char ch = o[i++];
                line[n++] = (ch >= 32 && ch < 127) ? ch : ' ';
            }
            if (o[i] == '\n') i++;
            line[n] = 0;
            gfx_text(fb, cx, cy + 30 + row * 26, 2, RGB(140, 230, 170), 230, line);
        }
        if (!o[0])
            gfx_text(fb, cx, cy + 30, 2, RGB(140, 170, 210), 190, "RUNNING...");
        return;
    }


    char abuf[16] = "ALPHA   ";
    char pct[8];
    u2s((unsigned long long)((w->alpha * 100 + 127) / 255), pct);
    int n = 8;
    cat(abuf, &n, pct);
    abuf[n++] = '%'; abuf[n] = 0;
    gfx_text(fb, cx, cy + 30, 2, RGB(150, 170, 200), 210, abuf);

    if (w->fname[0]) {
        char fl[56];
        int n = 0;
        cat(fl, &n, "FILE  ");
        for (int i = 0; w->fname[i] && n < 54; i++) fl[n++] = w->fname[i];
        fl[n] = 0;
        gfx_text(fb, cx, cy + 60, 2, RGB(120, 200, 255), 220, fl);
    } else {
        gfx_text_cn(fb, cx, cy + 60, 2, RGB(150, 170, 200), 210, "请先点击此窗口获取焦点后，再打字");
    }

    if (w->tlen > 0) {
        char line[84];
        int k = w->tlen > 60 ? 60 : w->tlen;
        for (int i = 0; i < k; i++) {
            char ch = w->text[w->tlen - k + i];
            line[i] = (ch >= 32 && ch < 127) ? ch : ' ';
        }
        line[k] = 0;
        gfx_text(fb, cx, cy + 96, 2, RGB(255, 255, 255), 235, line);
    }
    if (focused)
        gfx_text(fb, cx, cy + 96 + (w->tlen > 0 ? 26 : 0), 2, RGB(120, 200, 255), 230,
                 (kernel_ticks / 50) % 2 ? "_" : " ");

    if (w->fname[0])
        gfx_text(fb, cx, cy + 160, 2, RGB(140, 170, 210), 190, "CTRL+S SAVE");
    else if (w == &wins[2])
        gfx_text(fb, cx, cy + 96, 2, RGB(120, 200, 255), 210, "F2 RUN 3 RING3 APPS");
}

static void draw_cursor(Fb *fb)
{
    static const char *cur[16] = {
        "X...........", "XX..........", "X.X.........", "X..X........",
        "X...X.......", "X....X......", "X.....X.....", "X......X....",
        "X.......X...", "X........X..", "X.....XXXX..", "X..X..X.....",
        "X..X..X.....", "...X..X.....", "...X..X.....", "......X.....",
    };
    for (int pass = 0; pass < 2; pass++) {
        Rgb c = pass ? RGB(255, 255, 255) : RGB(0, 0, 0);
        int off = pass ? 0 : 1;
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 12; x++) {
                if (cur[y][x] != 'X') continue;
                int px = mx + x + off, py = my + y + off;
                if (px < 0 || py < 0 || px >= (int)fb->width || py >= (int)fb->height) continue;
                unsigned char *p = fb->base + py * fb->pitch + px * 4;
                if (fb->format) { p[0] = c.b; p[1] = c.g; p[2] = c.r; }
                else            { p[0] = c.r; p[1] = c.g; p[2] = c.b; }
            }
        }
    }
}

static void present_rect(int x0, int y0, int x1, int y1);
static int cur_x = -1000, cur_y = -1000;

/* 鼠标移动：只恢复旧光标区 + 画新光标，不重绘整屏 */
static void cursor_update(void)
{
    if (mx == cur_x && my == cur_y) return;
    if (cur_x > -500)
        present_rect(cur_x - 2, cur_y - 2, cur_x + 18, cur_y + 22);
    draw_cursor(g_screen);
    cur_x = mx;
    cur_y = my;
}

static void present_rect(int x0, int y0, int x1, int y1)
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int)back.width) x1 = (int)back.width;
    if (y1 > (int)back.height) y1 = (int)back.height;
    if (x1 <= x0 || y1 <= y0) return;

    for (int y = y0; y < y1; y++) {
        unsigned int *dst = (unsigned int *)(g_screen->base + (unsigned)y * g_screen->pitch) + x0;
        const unsigned int *src = (const unsigned int *)(back.base + (unsigned)y * back.pitch) + x0;
        for (int x = x0; x < x1; x++) *dst++ = *src++;
    }
}

static void present(void)
{
    unsigned n = back.width;   /* 每行像素数 */
    for (unsigned y = 0; y < back.height; y++) {
        unsigned long long *dst = (unsigned long long *)(g_screen->base + y * g_screen->pitch);
        const unsigned long long *src = (const unsigned long long *)(back.base + y * back.pitch);
        unsigned words = n / 2;
        for (unsigned i = 0; i < words; i++) dst[i] = src[i];
        if (n & 1) ((unsigned int *)dst)[n - 1] = ((const unsigned int *)src)[n - 1];
    }
    draw_cursor(g_screen);
    cur_x = mx; cur_y = my;
}

/* ---------- 面板 ---------- */

static void panel_header(Fb *fb, int x, int y, int w, const char *title)
{
    gfx_text_cn(fb, x + 24, y + 22, 2, RGB(255, 255, 255), 235, title);
    gfx_rect(fb, x + 24, y + 46, w - 48, 1, RGB(255, 255, 255), 40);
}

static void panel_rows(Fb *fb, int x, int y, int w, const char **rows, int n)
{
    for (int i = 0; i < n; i++) {
        int ry = y + 62 + i * 34;
        gfx_text_cn(fb, x + 24, ry, 2, RGB(215, 225, 245), 225, rows[i]);
        gfx_rect(fb, x + 24, ry + 20, w - 48, 1, RGB(255, 255, 255), 18);
    }
}

static void draw_files_panel(Fb *fb, int t)
{
    int H = (int)fb->height;
    int x = -(420 - 420 * t / 100);

    gfx_round_rect(fb, x, 100, 400, H - 200, 18, RGB(16, 20, 30), 240);
    gfx_round_rect(fb, x, 100, 400, H - 200, 18, RGB(255, 255, 255), 16);
    panel_header(fb, x, 100, 400, "文件系统（MFS）");

    for (int i = 0; i < file_count && i < 9; i++) {
        int ry = 158 + i * 34;
        if (i == file_sel)
            gfx_round_rect(fb, x + 14, ry - 6, 372, 30, 8, RGB(120, 200, 255), 45);

        gfx_text(fb, x + 24, ry, 2, RGB(215, 225, 245), 235, files[i].name);

        char kb[24], sz[24];
        int n = 0;
        if (files[i].size < 1024) {
            u2s(files[i].size, kb);
            while (kb[n]) { sz[n] = kb[n]; n++; }
            sz[n++] = 'B';
        } else {
            u2s((files[i].size + 1023) / 1024, kb);
            while (kb[n]) { sz[n] = kb[n]; n++; }
            sz[n++] = 'K';
        }
        sz[n] = 0;
        gfx_text(fb, x + 300, ry, 2, RGB(140, 170, 210), 210, sz);
    }

    char line[48];
    int n = 0;
    cat(line, &n, "已用 ");
    char num[16];
    u2s((mfs_used_bytes() + 1023) / 1024, num);
    cat(line, &n, num);
    cat(line, &n, " K   文件 ");
    u2s((unsigned long long)file_count, num);
    cat(line, &n, num);
    gfx_text_cn(fb, x + 24, H - 236, 2, RGB(120, 200, 255), 220, line);

    if (file_count > 0 && file_sel < file_count) {
        char pv[48];
        unsigned int sz2 = 0;
        mfs_read(files[file_sel].name, pv, 40, &sz2);
        int m = 0;
        for (unsigned int i = 0; i < sz2 && m < 40; i++) {
            unsigned char ch = (unsigned char)pv[i];
            if (ch < 32 || ch > 126) ch = ' ';
            pv[m++] = (char)ch;
        }
        pv[m] = 0;
        gfx_text_cn(fb, x + 24, H - 204, 2, RGB(190, 210, 230), 210, "预览");
        gfx_text(fb, x + 24, H - 180, 2, RGB(255, 255, 255), 225, pv);
    }

    gfx_text_cn(fb, x + 24, H - 130, 2, RGB(140, 170, 210), 200, "（N）新建   （X）删除");
    gfx_text_cn(fb, x + 24, H - 106, 2, RGB(140, 170, 210), 200, "输入内容会追加");
}

static void draw_island_panel(Fb *fb, int t)
{
    int W = (int)fb->width;
    int w = 520, h = 168;
    int x = (W - w) / 2;
    int y = -h + (h + 16) * t / 100;

    gfx_round_rect(fb, x, y, w, h, 26, RGB(14, 18, 28), 245);
    gfx_round_rect(fb, x, y, w, h, 26, RGB(255, 255, 255), 22);

    char line[48];
    int n = 0;
    cat(line, &n, "UPTIME ");
    char num[16];
    u2s(kernel_ticks / 100, num);
    cat(line, &n, num);
    cat(line, &n, " S   TASKS ");
    u2s((unsigned long long)sched_alive(), num);
    cat(line, &n, num);
    gfx_text(fb, x + 28, y + 24, 2, RGB(255, 255, 255), 235, line);

    int shown = 0;
    for (int i = 0; i < 3 && shown < 3; i++) {
        if (!sched_used(i)) continue;
        int ry = y + 56 + shown * 26;
        gfx_text(fb, x + 28, ry, 2, RGB(190, 215, 240), 220, sched_name(i));

        const char *st = sched_running(i) ? "RUN" : "DONE";
        Rgb c = sched_running(i) ? RGB(120, 230, 160) : RGB(150, 160, 180);
        gfx_text(fb, x + w - 90, ry, 2, c, 230, st);

        char kb[16];
        u2s((unsigned long long)sched_out_len(i), kb);
        gfx_text(fb, x + w - 190, ry, 2, RGB(140, 170, 210), 200, kb);
        shown++;
    }

    if (shown == 0)
        gfx_text(fb, x + 28, y + 56, 2, RGB(150, 170, 190), 200, "NO USER TASKS");

    gfx_round_rect(fb, x + w - 120, y + 24, 92, 8, 4, RGB(120, 200, 255), 200);
}

static void draw_apps_panel(Fb *fb, int t)
{
    int W = (int)fb->width, H = (int)fb->height;
    int w = 380;
    int x = W - w * t / 100;

    gfx_round_rect(fb, x, 100, w, H - 200, 18, RGB(16, 20, 30), 240);
    gfx_round_rect(fb, x, 100, w, H - 200, 18, RGB(255, 255, 255), 16);
    panel_header(fb, x, 100, w, disk_ok ? "应用（磁盘 .fx）" : "应用（内存 .fx）");

    for (int i = 0; i < app_count && i < 8; i++) {
        int ry = 158 + i * 34;
        if (i == app_sel)
            gfx_round_rect(fb, x + 14, ry - 6, w - 28, 30, 8, RGB(120, 200, 255), 45);
        gfx_text(fb, x + 24, ry, 2, RGB(215, 225, 245), 235, apps[i].name);
        if (i == app_sel)
            gfx_text(fb, x + w - 96, ry, 2, RGB(120, 200, 255), 220, "ENTER");
    }

    if (app_count == 0)
        gfx_text(fb, x + 24, 158, 2, RGB(200, 120, 120), 200, "NO .FX APPS");

    gfx_text(fb, x + 24, H - 132, 2, RGB(120, 150, 190), 200, "ENTER RUN   X DELETE");
}

static void draw_settings_panel(Fb *fb, int t)
{
    static const char *rows[] = {
        "显示        深色", "声音        40%", "网络        开", "账户        1 位用户",
        "版本        1.0.1", "构建        测试版", "版权        Deepblue Network",
        "开源        Noto CJK (OFL)",
        "许可        Apache-2.0",
    };
    int W = (int)fb->width, H = (int)fb->height;
    int h = 430;
    int y = H - h * t / 100;

    gfx_round_rect(fb, 220, y, W - 440, h, 20, RGB(14, 18, 28), 242);
    gfx_round_rect(fb, 220, y, W - 440, h, 20, RGB(255, 255, 255), 16);
    panel_header(fb, 220, y, W - 440, "设置");
    panel_rows(fb, 220, y, W - 440, rows, 9);
    gfx_text(fb, 244, y + h - 44, 2, RGB(120, 150, 190), 200, "CTRL+DOWN TOGGLE");
}

static void draw_panels(Fb *fb)
{
    if (!panel) return;
    int t = ease(panel_progress());

    if (panel == PANEL_FILES) draw_files_panel(fb, t);
    else if (panel == PANEL_ISLAND) draw_island_panel(fb, t);
    else if (panel == PANEL_APPS) draw_apps_panel(fb, t);
    else if (panel == PANEL_SETTINGS) draw_settings_panel(fb, t);
}

/* ---------- 交互 ---------- */

static int hit_bar(Win *w, int x, int y)
{
    int bx = w->x + BAR_INSET, by = w->y + BAR_INSET;
    int bw = w->w - BAR_INSET * 2;
    return x >= bx && x < bx + bw && y >= by && y < by + BAR_H;
}

static int hit_win(Win *w, int x, int y)
{
    int h = w->minimized ? (BAR_INSET * 2 + BAR_H) : w->h;
    return x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + h;
}

static void raise_to_front(int idx)
{
    int pos = 0;
    for (int i = 0; i < zcount; i++) if (zorder[i] == idx) pos = i;
    for (int i = pos; i < zcount - 1; i++) zorder[i] = zorder[i + 1];
    zorder[zcount - 1] = idx;
}

static void focus_window(int idx)
{
    if (idx == focus) return;
    int t = wins[idx].alpha;
    wins[idx].alpha = wins[focus].alpha;
    wins[focus].alpha = t;
    focus = idx;
}

static void toggle_max(Win *w)
{
    if (!w->has_saved) {
        w->sx = w->x; w->sy = w->y; w->sw = w->w; w->sh = w->h;
        w->has_saved = 1;
        /* 留出边距与底部托盘区域 */
        w->x = 8;
        w->y = 8;
        w->w = (int)back.width - 16;
        w->h = (int)back.height - 64;
    } else {
        w->x = w->sx; w->y = w->sy; w->w = w->sw; w->h = w->sh;
        w->has_saved = 0;
    }
}

static void click_at(int x, int y)
{
    if (panel) { panel = PANEL_NONE; dirty = 1; }

    for (int z = zcount - 1; z >= 0; z--) {
        Win *w = &wins[zorder[z]];
        if (!w->open || !hit_win(w, x, y)) continue;

        int idx = zorder[z];
        if (hit_bar(w, x, y)) {
            int bx = w->x + BAR_INSET, bw = w->w - BAR_INSET * 2;
            int cy = w->y + BAR_INSET + BAR_H / 2;
            int r = 8, cx = bx + bw - 26;
            for (int i = 0; i < 3; i++) {
                int px = cx - i * 25;
                int dx = x - px, dy = y - cy;
                if (dx * dx + dy * dy <= (r + 2) * (r + 2)) {
                    raise_to_front(idx);
                    if (i == 0) {          /* 红：关闭 */
                        if (w->app_slot >= 0) sched_kill(w->app_slot);
                        w->open = 0;
                        ui_clear(w->app_slot >= 0 ? w->app_slot : 0);
                    } else if (i == 1) {   /* 绿：最大化/还原 */
                        toggle_max(w);
                    } else {               /* 橙：最小化 */
                        w->minimized = !w->minimized;
                    }
                    dirty = 1;
                    return;
                }
            }
            focus_window(idx);
            raise_to_front(idx);
            drag = idx;
            drag_dx = x - w->x;
            drag_dy = y - w->y;
            dirty = 1;
            return;
        }

        if (w->app_slot >= 0)
            ui_push_event(w->app_slot, 1, x - (w->x + 16), y - (w->y + 76), 0);

        focus_window(idx);
        raise_to_front(idx);
        dirty = 1;
        return;
    }
}

static void build_wallpaper(void)
{
    Fb w = back;
    w.base = wall_mem;
    gfx_vgrad(&w, RGB(10, 14, 26), RGB(30, 46, 78));
    gfx_rect(&w, 0, (int)w.height - 64, (int)w.width, 64, RGB(8, 10, 18), 130);
    gfx_text_cn(&w, 40, (int)w.height - 42, 2, RGB(190, 200, 220), 200,
                "CTRL+左 文件   CTRL+上 动效   CTRL+右 应用   CTRL+下 设置");
}

static int dm_x0, dm_y0, dm_x1, dm_y1, dm_none = 1;

static void dmg_all(void)
{
    dm_x0 = 0; dm_y0 = 0;
    dm_x1 = (int)back.width; dm_y1 = (int)back.height;
    dm_none = 0;
}

static void dmg_add(int x, int y, int w, int h)
{
    if (w <= 0 || h <= 0) return;
    if (dm_none) {
        dm_x0 = x; dm_y0 = y; dm_x1 = x + w; dm_y1 = y + h;
        dm_none = 0;
        return;
    }
    if (x < dm_x0) dm_x0 = x;
    if (y < dm_y0) dm_y0 = y;
    if (x + w > dm_x1) dm_x1 = x + w;
    if (y + h > dm_y1) dm_y1 = y + h;
}

static unsigned long long perf_frames, perf_ticks, perf_start;
static int perf_on;

static void perf_mark(void)
{
    if (!perf_on) return;
    perf_frames++;
    if (perf_frames % 20 == 0) {
        unsigned long long now = kernel_ticks;
        unsigned long long dt = now - perf_start;
        klog("[perf] 20 frames / ");
        klog_dec((long long)dt);
        klog(" ticks = avg ");
        klog_dec((long long)(dt * 10 / 20));
        klog(" ms/frame\r\n");
        perf_start = now;
    }
}

static void render(void)
{
    perf_on = 1;
    if (!perf_start) perf_start = kernel_ticks;
    if (dm_none) return;

    int cx0 = dm_x0 < 0 ? 0 : dm_x0;
    int cy0 = dm_y0 < 0 ? 0 : dm_y0;
    int cx1 = dm_x1 > (int)back.width ? (int)back.width : dm_x1;
    int cy1 = dm_y1 > (int)back.height ? (int)back.height : dm_y1;
    dm_none = 1;
    if (cx1 <= cx0 || cy1 <= cy0) return;

    /* 只在脏区恢复壁纸 */
    for (int y = cy0; y < cy1; y++) {
        unsigned long long *dst = (unsigned long long *)(back.base + (unsigned)y * back.pitch);
        const unsigned long long *src = (const unsigned long long *)wall_mem;
        unsigned base = (unsigned)y * (back.pitch / 4);
        for (int x = cx0; x < cx1; x++) ((unsigned int *)dst)[x] = ((const unsigned int *)src)[base + x];
    }

    gfx_clip(cx0, cy0, cx1 - cx0, cy1 - cy0);

    for (int z = 0; z < zcount; z++) {
        Win *w = &wins[zorder[z]];
        if (w->open) draw_win(&back, w, zorder[z] == focus ? 1 : 0);
    }

    draw_panels(&back);

    gfx_text_cn(&back, 40, 20, 2, RGB(120, 220, 160), 235, "内核模式");
    gfx_text_cn(&back, 40, 42, 2, RGB(120, 160, 200), 190, "已退出启动服务");

    char buf[48];
    int n = 0;
    cat(buf, &n, "内存 ");
    char num[16];
    u2s(kmem_free_bytes() >> 20, num);
    cat(buf, &n, num);
    cat(buf, &n, " MB 可用");
    gfx_text_cn(&back, 40, 64, 2, RGB(120, 160, 200), 190, buf);

    n = 0;
    cat(buf, &n, "计时 ");
    u2s(kernel_ticks, num);
    cat(buf, &n, num);
    gfx_text_cn(&back, (int)back.width - n * 12 - 40, 20, 2, RGB(150, 200, 240), 230, buf);

    if (fs_ok)
        gfx_text_cn(&back, 40, 86, 2, RGB(120, 200, 255), 190, "文件系统：MFS（内存）");

    gfx_text(&back, (int)back.width - 470, 42, 2, RGB(110, 130, 165), 200,
             "FURMAX OS " FURMAX_VERSION "  TEST BUILD");

    {
        RtcTime rt;
        rtc_read(&rt);
        char clk[24];
        int k = 0;
        cat(clk, &k, "时间 ");
        if (rt.hour < 10) clk[k++] = '0';
        char tmp[8];
        u2s((unsigned long long)rt.hour, tmp);
        cat(clk, &k, tmp);
        clk[k++] = ':';
        if (rt.minute < 10) clk[k++] = '0';
        u2s((unsigned long long)rt.minute, tmp);
        cat(clk, &k, tmp);
        clk[k] = 0;
        gfx_text_cn(&back, (int)back.width - 470, 64, 2, RGB(110, 130, 165), 200, clk);
    }

    if (disk_ok) {
        char dl[40];
        int k = 0;
        cat(dl, &k, "DISK FMS64 (VIRTIO)  BOOT #");
        char num[16];
        u2s(disk_boot, num);
        cat(dl, &k, num);
        gfx_text(&back, (int)back.width - 470, (int)back.height - 96, 2, RGB(160, 220, 180), 210, dl);
    }

    if (fault_active) {
        int w = 620, h = 130;
        int x = ((int)back.width - w) / 2, y = 120;
        gfx_round_rect(&back, x, y, w, h, 12, RGB(90, 20, 24), 245);
        gfx_round_rect(&back, x, y, w, h, 12, RGB(255, 120, 120), 60);
        gfx_text(&back, x + 22, y + 18, 3, RGB(255, 220, 220), 250, "SYSTEM FAULT");
        char fb2[48];
        int n2 = 0;
        cat(fb2, &n2, "VEC ");
        char num2[16];
        u2s((unsigned long long)fault_vec, num2);
        cat(fb2, &n2, num2);
        cat(fb2, &n2, "  TASK ");
        for (int i = 0; fault_task[i] && n2 < 46; i++) fb2[n2++] = fault_task[i];
        fb2[n2] = 0;
        gfx_text(&back, x + 22, y + 60, 2, RGB(255, 235, 235), 240, fb2);
        gfx_text(&back, x + 22, y + 92, 2, RGB(200, 150, 150), 220, "ESC CLEARS  SEE SERIAL LOG");
    }

    gfx_clip_off();
    present_rect(cx0, cy0, cx1, cy1);
    draw_cursor(g_screen);
    cur_x = mx;
    cur_y = my;
    perf_mark();
}

/* ---------- 主入口 ---------- */

void wm_start(Fb *screen, void *back_buf, void *wall_buf)
{
    gfx_pump = 0;          /* 渲染期排空不可靠（8042 重复字节），保持关闭 */
    g_screen = screen;
    back_mem = back_buf;
    wall_mem = wall_buf;

    back = *screen;
    back.base = back_mem;
    back.pitch = screen->width * 4;

    build_wallpaper();
    dmg_all();

    mx = (int)screen->width / 2;
    my = (int)screen->height / 2;

    mouse_ok = 0;
    ps2_stage = ps2_mouse_init();
    if (ps2_stage == 1) mouse_ok = 1;

    klog_init();
    gdt_init();
    kernel_init_interrupts();
    kbd_init();

    mfs_init();
    mfs_write("README.TXT", "FURMAX OS IN-MEMORY FILESYSTEM\n", 33, 0);
    mfs_write("NOTES.TXT", "TYPE TO APPEND\n", 15, 0);
    fs_ok = 1;
    file_count = list_visible();
    if (file_count < 0) file_count = 0;
    file_sel = 0;
#ifndef FMS_ENABLE
    mfs_write("HELLO.FX", hello_fx, HELLO_FX_LEN, 0);
    mfs_write("GREET.FX", greet_fx, GREET_FX_LEN, 0);
    mfs_write("TICKER.FX", ticker_fx, TICKER_FX_LEN, 0);
#endif

    refresh_apps();

    /* 磁盘（virtio-blk）：挂载 FMS64 并更新启动计数，验证持久化 */
    if (vio_init()) {
        fms_set_driver(1);
        if (fms_mount()) {
            disk_ok = 1;
            fs_set_disk_ready(1);
            fms_mkroot();
            fms_fsck();
            update_selftest();
            update_check();
            char dbuf[32];
            unsigned int dsz = 0;
            if (fms_read("BOOTCNT.TXT", dbuf, sizeof(dbuf) - 1, &dsz) == 0) {
                dbuf[dsz] = 0;
                unsigned long long v = 0;
                for (unsigned int i = 0; i < dsz && dbuf[i] >= '0' && dbuf[i] <= '9'; i++)
                    v = v * 10 + (unsigned)(dbuf[i] - '0');
                disk_boot = v;
            }
            disk_boot++;
            char num[24];
            u2s(disk_boot, num);
            int wr = fms_write("BOOTCNT.TXT", num, (unsigned int)str_len(num));
            klog("[disk] virtio+FMS64 boot=");
            klog_dec((long long)disk_boot);
            klog(" write=");
            klog_dec(wr);
            klog("\r\n");

            /* 磁盘文件导入内存文件系统（磁盘优先） */
            FmsEntry de[64];
            int dn = fms_list_all(de, 64);
            for (int i = 0; i < dn; i++) {
                static unsigned char dbuf2[8192];
                unsigned int dsz2 = 0;
                if (fms_read(de[i].name, dbuf2, sizeof(dbuf2), &dsz2) == 0 && dsz2 <= sizeof(dbuf2))
                    mfs_write(de[i].name, dbuf2, dsz2, 0);
            }
            {
                static const struct { const char *n; const char *d; } docs[] = {
                    { "SHEET.CVP",
                      "PROJECT,FILES,STATUS,OWNER\n"
                      "FURMAX,12,ACTIVE,CORE\n"
                      "KERNEL,48,ACTIVE,CORE\n"
                      "UI,26,REVIEW,TEAM\n"
                      "DOCS,9,PLANNED,TEAM\n" },
                    { "DOC.PVC",
                      "FURMAX OS\nPRODUCT BRIEF\n"
                      "FURMAX IS A GRAPHICAL OPERATING SYSTEM\n"
                      "BUILT FROM SCRATCH.\n"
                      "OWN KERNEL, COMPOSITOR AND FILESYSTEM.\n"
                      "THIS IS A SAMPLE .PVC DOCUMENT.\n" },
                    { "DECK.VPC",
                      "FURMAX OS\nA NEW GRAPHICAL SYSTEM\n"
                      "---\n"
                      "ARCHITECTURE\nOWN KERNEL\nOWN COMPOSITOR\nOWN FILESYSTEM\n"
                      "---\n"
                      "STATUS\nBOOT TO DESKTOP\nUSER MODE APPS\nDISK PERSISTENCE\n" },
                };
                for (unsigned i = 0; i < sizeof(docs) / sizeof(docs[0]); i++) {
                    unsigned int ex = 0;
                    if (mfs_read(docs[i].n, 0, 0, &ex) != 0) {
                        int L = str_len(docs[i].d);
                        mfs_write(docs[i].n, docs[i].d, (unsigned int)L, 0);
                        fs_write_through(docs[i].n, docs[i].d, (unsigned int)L);
                    }
                }
            }

            file_count = list_visible();
            if (file_count < 0) file_count = 0;
            refresh_apps();

            /* 预装只在首次（无标记文件）发生，之后删除的应用不会再回来 */
            {
                unsigned int msz = 0;
                if (fms_read(".SEEDED", 0, 0, &msz) != 0) {
                    static const struct { const char *n; const unsigned char *d; unsigned int l; } apps_seed[] = {
                        { "HELLO.FX", hello_fx, HELLO_FX_LEN },
                        { "GREET.FX", greet_fx, GREET_FX_LEN },
                        { "TICKER.FX", ticker_fx, TICKER_FX_LEN },
                        { "COPY.FX", copy_fx, COPY_FX_LEN },
                        { "UI.FX", ui_fx, UI_FX_LEN },
                        { "CLICK.FX", click_fx, CLICK_FX_LEN },
                        { "NOTEPAD.FX", notepad_fx, NOTEPAD_FX_LEN },
                        { "IMG.FX", img_fx, IMG_FX_LEN },
                        { "CRASH.FX", crash_fx, CRASH_FX_LEN },
                    };
                    for (unsigned i = 0; i < sizeof(apps_seed) / sizeof(apps_seed[0]); i++)
                        fms_write(apps_seed[i].n, apps_seed[i].d, apps_seed[i].l);
                    static const char sheet[] =
                        "PROJECT,FILES,STATUS,OWNER\n"
                        "FURMAX,12,ACTIVE,CORE\n"
                        "KERNEL,48,ACTIVE,CORE\n"
                        "UI,26,REVIEW,TEAM\n"
                        "DOCS,9,PLANNED,TEAM\n";
                    static const char doc[] =
                        "FURMAX OS\nPRODUCT BRIEF\n"
                        "FURMAX IS A GRAPHICAL OPERATING SYSTEM\n"
                        "BUILT FROM SCRATCH.\n"
                        "OWN KERNEL, COMPOSITOR AND FILESYSTEM.\n"
                        "THIS IS A SAMPLE .PVC DOCUMENT.\n";
                    static const char deck[] =
                        "FURMAX OS\nA NEW GRAPHICAL SYSTEM\n"
                        "---\n"
                        "ARCHITECTURE\nOWN KERNEL\nOWN COMPOSITOR\nOWN FILESYSTEM\n"
                        "---\n"
                        "STATUS\nBOOT TO DESKTOP\nUSER MODE APPS\nDISK PERSISTENCE\n";
                    fms_write("SHEET.CVP", sheet, (unsigned int)(sizeof(sheet) - 1));
                    fms_write("DOC.PVC", doc, (unsigned int)(sizeof(doc) - 1));
                    fms_write("DECK.VPC", deck, (unsigned int)(sizeof(deck) - 1));
                    fms_write(".SEEDED", "1", 1);
                }
            }
        }
    }


    render();
    klog("[kernel] sb addr: ");
    klog_hex((unsigned long long)&wins[0]);
    klog("\r\n");
    klog("[kernel] first frame rendered\r\n");

    unsigned long long last_render = 0;
    for (;;) {
        int changed = 0;

        if (mouse_ok) {
            int dx = 0, dy = 0, btn = 0;
            if (ps2_mouse_poll(&dx, &dy, &btn)) {
                mx += dx; my += dy;
                if (mx < 0) mx = 0;
                if (my < 0) my = 0;
                if (mx > (int)screen->width - 1) mx = (int)screen->width - 1;
                if (my > (int)screen->height - 1) my = (int)screen->height - 1;
                changed = 1;

                btn = (btn & 1);
                if (btn && !mprev_btn) click_at(mx, my);
                mprev_btn = btn;
                if (btn && drag >= 0) {
                    Win *w = &wins[drag];
                    if (w->x != mx - drag_dx || w->y != my - drag_dy) {
                        /* 旧位置与新位置都标脏，局部重绘即可 */
                        dmg_add(w->x - 24, w->y - 24, w->w + 48, w->h + 48);
                        w->x = mx - drag_dx;
                        w->y = my - drag_dy;
                        dmg_add(w->x - 24, w->y - 24, w->w + 48, w->h + 48);
                        raise_to_front(drag);
                    }
                }
                if (!btn) drag = -1;
            }
        }

        ps2_drain();

        int c;
        while ((c = kbd_getkey()) >= 0) {
            int ctrl = (c & KEY_CTRL) != 0;
            c &= 0x1FF;

            if (c == KEY_LEFT && ctrl) {
                panel = (panel == PANEL_FILES) ? PANEL_NONE : PANEL_FILES;
                panel_t0 = kernel_ticks; dirty = changed = 1; continue;
            }
            if (c == KEY_RIGHT && ctrl) {
                panel = (panel == PANEL_APPS) ? PANEL_NONE : PANEL_APPS;
                panel_t0 = kernel_ticks; dirty = changed = 1; continue;
            }
            if (c == KEY_UP && ctrl) {
                panel = (panel == PANEL_ISLAND) ? PANEL_NONE : PANEL_ISLAND;
                panel_t0 = kernel_ticks; dirty = changed = 1; continue;
            }
            if (c == KEY_DOWN && ctrl) {
                panel = (panel == PANEL_SETTINGS) ? PANEL_NONE : PANEL_SETTINGS;
                panel_t0 = kernel_ticks; dirty = changed = 1; continue;
            }
            if (c == KEY_ESC) { panel = PANEL_NONE; dirty = changed = 1; continue; }
            if (c == KEY_ESC && fault_active) {
                fault_active = 0;
                dirty = 1;
                continue;
            }

            if (c == KEY_F3) {
                focus_window(2);
                raise_to_front(2);
                dirty = changed = 1;
                continue;
            }
            if (c == KEY_F5) {
                int slots[3];
                slots[0] = sched_spawn("TICKER.FX");
                slots[1] = sched_spawn("HELLO.FX");
                slots[2] = sched_spawn("GREET.FX");
                for (int i = 0; i < 3; i++)
                    open_task_window(slots[i], 230 - i * 25);
                dirty = 1;
                dirty = changed = 1;
                continue;
            }
            if (panel == PANEL_APPS) {
                if (c == KEY_UP) { if (app_sel > 0) app_sel--; dirty = changed = 1; continue; }
                if (c == KEY_DOWN) { if (app_sel < app_count - 1) app_sel++; dirty = changed = 1; continue; }
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                    static char last_app_jump;
                    char want = (char)c;
                    if (want >= 'a' && want <= 'z') want -= 32;
                    int start = (want == last_app_jump) ? app_sel + 1 : 0;
                    last_app_jump = want;
                    for (int k = 0; k < app_count; k++) {
                        int i = (start + k) % app_count;
                        char ch = apps[i].name[0];
                        if (ch >= 'a' && ch <= 'z') ch -= 32;
                        if (ch == want) { app_sel = i; break; }
                    }
                    dirty = changed = 1;
                    continue;
                }
                if (c == 'x' || c == 'X') {
                    if (app_count > 0) {
                        char nm[48];
                        int k = 0;
                        for (; apps[app_sel].name[k] && k < 47; k++) nm[k] = apps[app_sel].name[k];
                        nm[k] = 0;
                        fs_remove_both(nm);
                        mfs_remove(nm);
                        refresh_apps();
                        dirty = changed = 1;
                    }
                    continue;
                }
                if (c == '\n' && app_count > 0) {
                    char nm[48];
                    int k = 0;
                    for (; apps[app_sel].name[k] && k < 47; k++) nm[k] = apps[app_sel].name[k];
                    nm[k] = 0;
                    panel = PANEL_NONE;
                    klog("[apps] launch ");
                    klog(nm);
                    klog("\r\n");
                    int slot = sched_spawn(nm);
                    klog("[apps] slot=");
                    klog_dec(slot);
                    klog("\r\n");
                    open_task_window(slot, 235);
                    dirty = changed = 1; continue;
                }
                continue;
            }

            if (panel == PANEL_FILES) {
                if (c == KEY_UP) {
                    if (file_sel > 0) file_sel--;
                    dirty = changed = 1; continue;
                }
                if (c == KEY_DOWN) {
                    if (file_sel < file_count - 1) file_sel++;
                    dirty = changed = 1; continue;
                }
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                    static char last_jump;
                    char want = (char)c;
                    if (want >= 'a' && want <= 'z') want -= 32;
                    int start = (want == last_jump) ? file_sel + 1 : 0;
                    last_jump = want;
                    for (int k = 0; k < file_count; k++) {
                        int i = (start + k) % file_count;
                        char ch = files[i].name[0];
                        if (ch >= 'a' && ch <= 'z') ch -= 32;
                        if (ch == want) { file_sel = i; break; }
                    }
                    dirty = changed = 1;
                    continue;
                }
                if (c == 'n' || c == 'N') {
                    char nm[24];
                    int k = 0;
                    const char *pre = "NOTE";
                    while (*pre) nm[k++] = *pre++;
                    char num[8];
                    u2s((unsigned long long)(file_count + 1), num);
                    for (int i = 0; num[i]; i++) nm[k++] = num[i];
                    nm[k++] = '.'; nm[k++] = 'T'; nm[k++] = 'X'; nm[k++] = 'T';
                    nm[k] = 0;
                    mfs_write(nm, "", 0, 0);
                    fs_write_through(nm, "", 0);
                    file_count = list_visible();
                    file_sel = file_count - 1;
                    dirty = changed = 1; continue;
                }
                if (c == '\n') {
                    if (file_count > 0 && file_sel < file_count) {
                        Win *ew = &wins[1];
                        int k = 0;
                        for (; files[file_sel].name[k] && k < 47; k++) ew->fname[k] = files[file_sel].name[k];
                        ew->fname[k] = 0;

                        viewlen = 0;
                        viewbuf[0] = 0;
                        mfs_read(files[file_sel].name, viewbuf, sizeof(viewbuf) - 1, &viewlen);
                        viewbuf[viewlen < sizeof(viewbuf) ? viewlen : sizeof(viewbuf) - 1] = 0;

                        if (files[file_sel].size == 0) { }
                        if (ends_with(ew->fname, ".cvp")) { ew->view = 1; sheet_row = sheet_col = 0; csv_load(); editing = 0; }
                        else if (ends_with(ew->fname, ".pvc")) { ew->view = 2; doc_scroll = 0; }
                        else if (ends_with(ew->fname, ".vpc")) { ew->view = 3; slide_idx = 0; }
                        else {
                            ew->view = 0;
                            unsigned int sz = viewlen;
                            ew->tlen = (int)(sz < sizeof(ew->text) - 1 ? sz : sizeof(ew->text) - 1);
                            for (int i = 0; i < ew->tlen; i++) ew->text[i] = viewbuf[i];
                        }

                        if (ew->view) {
                            ew->x = 220; ew->y = 110; ew->w = 880; ew->h = 580;
                            ew->has_saved = 0;
                        }
                        focus_window(1);
                        raise_to_front(1);
                        panel = PANEL_NONE;
                    }
                    dirty = changed = 1; continue;
                }
                if (c == 'x' || c == 'X') {
                    if (file_count > 0) {
                        fs_remove_both(files[file_sel].name);
                        mfs_remove(files[file_sel].name);
                        file_count = list_visible();
                        if (file_sel >= file_count) file_sel = file_count > 0 ? file_count - 1 : 0;
                    }
                    dirty = changed = 1; continue;
                }
                if (c >= 32 && c < 127 && file_count > 0) {
                    char ch = (char)c;
                    mfs_write(files[file_sel].name, &ch, 1, 1);
                    {
                        static unsigned char wb[4096];
                        unsigned int ws = 0;
                        if (mfs_read(files[file_sel].name, wb, sizeof(wb), &ws) == 0)
                            fs_write_through(files[file_sel].name, wb, ws);
                    }
                    file_count = list_visible();
                    dirty = changed = 1; continue;
                }
                continue;
            }

            if (panel != PANEL_NONE) continue;

            Win *w = &wins[focus];
            if (!w->open) continue;

            int cc = c & ~KEY_CTRL;   /* 忽略锁存的 Ctrl 修饰，避免丢字 */

            if (w->app_slot >= 0 && panel == PANEL_NONE &&
                ((cc >= 32 && cc < 127) || cc == '\b' || cc == KEY_ESC || cc == KEY_F2)) {
                ui_push_event(w->app_slot, 2, 0, 0, cc);
                dirty = changed = 1;
                continue;
            }

            if (w->view) {
                if (c == KEY_ESC) { w->view = 0; dirty = changed = 1; continue; }
                if (w->view == 1) {
                    if (editing) {
                        if (c == '\n') {
                            int n = editlen < CELL_MAX - 1 ? editlen : CELL_MAX - 1;
                            for (int i = 0; i < n; i++) grid[sheet_row][sheet_col][i] = editbuf[i];
                            grid[sheet_row][sheet_col][n] = 0;
                            editing = 0;
                            csv_save(w);
                        } else if (c == '\b') {
                            if (editlen > 0) editlen--;
                            editbuf[editlen] = 0;
                        } else if (c == KEY_ESC) {
                            editing = 0;
                        } else if (c >= 32 && c < 127 && editlen < CELL_MAX - 1) {
                            editbuf[editlen++] = (char)c;
                            editbuf[editlen] = 0;
                        }
                        dirty = changed = 1;
                        continue;
                    }

                    if (c == KEY_LEFT && sheet_col > 0) sheet_col--;
                    else if (c == KEY_RIGHT && sheet_col < GRID_COLS - 1) sheet_col++;
                    else if (c == KEY_UP && sheet_row > 0) sheet_row--;
                    else if (c == KEY_DOWN && sheet_row < GRID_ROWS - 1) sheet_row++;
                    else if (c == '\n') {
                        int n = 0;
                        while (grid[sheet_row][sheet_col][n] && n < CELL_MAX - 1) {
                            editbuf[n] = grid[sheet_row][sheet_col][n];
                            n++;
                        }
                        editlen = n;
                        editbuf[n] = 0;
                        editing = 1;
                    } else if (c >= 32 && c < 127) {
                        editbuf[0] = (char)c;
                        editbuf[1] = 0;
                        editlen = 1;
                        editing = 1;
                    }
                    dirty = changed = 1;
                    continue;
                } else if (w->view == 2) {
                    if (c == KEY_UP && doc_scroll > 0) doc_scroll--;
                    if (c == KEY_DOWN && doc_scroll < 40) doc_scroll++;
                } else if (w->view == 3) {
                    if ((c == KEY_LEFT || c == KEY_UP) && slide_idx > 0) slide_idx--;
                    if (c == KEY_RIGHT || c == KEY_DOWN) slide_idx++;
                }
                dirty = changed = 1;
                continue;
            }

            if ((c == 's' || c == 'S') && ctrl && w->fname[0]) {
                mfs_write(w->fname, w->text, (unsigned int)w->tlen, 0);
                fs_write_through(w->fname, w->text, (unsigned int)w->tlen);
                file_count = list_visible();
                dirty = changed = 1;
                continue;
            }
            if (w->term && panel == PANEL_NONE) {
                if (c == KEY_UP) { term_hist_recall(-1, w); dirty = changed = 1; continue; }
                if (c == KEY_DOWN) { term_hist_recall(1, w); dirty = changed = 1; continue; }
                if (c == '\t') { term_complete(w); dirty = changed = 1; continue; }
            }

            if (cc == '\n' && w->term) {
                char cmd[80];
                int k = w->tlen > 70 ? 70 : w->tlen;
                for (int i = 0; i < k; i++) cmd[i] = w->text[i];
                cmd[k] = 0;
                w->tlen = 0;
                term_hist_push(cmd);
                term_exec(cmd);
                dirty = changed = 1;
                continue;
            }
            if (cc == '\b') {
                if (w->tlen > 0) w->tlen--;
            } else if (cc >= 32 && cc < 127) {
                if (w->tlen < (int)sizeof(w->text) - 1) {
                    w->text[w->tlen++] = (char)cc;
                }
            }
            changed = 1;
        }

        if (sched_alive()) sched_run_slice(25);

        if (panel && panel_progress() < 100) dirty = 1;
        cursor_update();

        if (dirty) dmg_all();
        else if (changed) {
            Win *fw = &wins[focus];
            dmg_add(fw->x - 20, fw->y - 20, fw->w + 40, fw->h + 40);
        }
        if (panel && panel_progress() < 100) dmg_all();
        if (kernel_ticks >= last_render + 30) dmg_all();

        if (!dm_none) {
            render();
            dirty = 0;
            changed = 0;
            last_render = kernel_ticks;
        }
    }
}
