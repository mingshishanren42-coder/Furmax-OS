#ifndef FURMAX_GFX_H
#define FURMAX_GFX_H

#include "efi.h"

typedef struct {
    unsigned char *base;
    unsigned int   width, height, pitch;   /* pitch = 每行字节数 */
    unsigned int   format;                 /* 0=RGBR 1=BGRR */
} Fb;

typedef struct { unsigned char r, g, b; } Rgb;

#define RGB(r, g, b) ((Rgb){ (unsigned char)(r), (unsigned char)(g), (unsigned char)(b) })

int  gfx_open(Fb *fb, EFI_GRAPHICS_OUTPUT_PROTOCOL *gop);
/* 主动选择最接近目标分辨率的模式（优先 32bpp） */
void gfx_choose_mode(EFI_GRAPHICS_OUTPUT_PROTOCOL *gop, EFI_BOOT_SERVICES *bs,
                     unsigned want_w, unsigned want_h);
void gfx_fill(Fb *fb, Rgb c);
void gfx_clip(int x, int y, int w, int h);
void gfx_clip_off(void);
extern void (*gfx_pump)(void);   /* 绘制过程中的周期性回调（用于排空 PS/2） */
void gfx_vgrad(Fb *fb, Rgb top, Rgb bottom);
void gfx_rect(Fb *fb, int x, int y, int w, int h, Rgb c, int alpha);
void gfx_round_rect(Fb *fb, int x, int y, int w, int h, int r, Rgb c, int alpha);
void gfx_text(Fb *fb, int x, int y, int scale, Rgb c, int alpha, const char *s);
int  gfx_text_cn(Fb *fb, int x, int y, int scale, Rgb c, int alpha, const char *s);
int  gfx_text_w(const char *s, int scale);
/* 4bpp 灰度遮罩按整数倍放大绘制 */
void gfx_blit_a4(Fb *fb, int x, int y, int w, int h,
                 const unsigned char *bits, int rowbytes,
                 Rgb c, int scale);

#endif
