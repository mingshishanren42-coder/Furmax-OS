#ifndef FURMAX_PS2_H
#define FURMAX_PS2_H

/* Furmax 自有 PS/2 鼠标驱动：轮询 i8042，不依赖固件。 */
int  ps2_mouse_init(void);
int  ps2_mouse_poll(int *dx, int *dy, int *buttons);
void ps2_mouse_flush(void);
void ps2_drain(void);
void ps2_kbd_drain(void);
void ps2_mouse_feed(unsigned char b);

#endif
