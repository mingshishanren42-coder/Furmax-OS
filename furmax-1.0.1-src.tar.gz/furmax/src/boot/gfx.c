/* Furmax OS 图形基座：直接写 GOP 帧缓冲，软件混合。 */
#include "gfx.h"
#include "font5x7.h"
#include "cjk_font.h"

void gfx_choose_mode(EFI_GRAPHICS_OUTPUT_PROTOCOL *gop, EFI_BOOT_SERVICES *bs,
                     unsigned want_w, unsigned want_h)
{
    if (!gop || !gop->Mode) return;

    unsigned best = gop->Mode->Mode;
    long best_score = -1;

    for (UINT32 i = 0; i < gop->Mode->MaxMode; i++) {
        UINTN size = 0;
        EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *info = 0;
        if (EFI_ERROR(gop->QueryMode(gop, i, &size, &info)) || !info) continue;

        if (info->PixelFormat == PixelBltOnly) {
            if (bs && bs->FreePool) bs->FreePool(info);
            continue;
        }

        long dw = (long)info->HorizontalResolution - (long)want_w;
        long dh = (long)info->VerticalResolution - (long)want_h;
        if (dw < 0) dw = -dw;
        if (dh < 0) dh = -dh;
        long score = 2000 - (dw * 2 + dh * 3);

        if (score > best_score) {
            best_score = score;
            best = i;
        }
        if (bs && bs->FreePool) bs->FreePool(info);
    }

    gop->SetMode(gop, best);
}

int gfx_open(Fb *fb, EFI_GRAPHICS_OUTPUT_PROTOCOL *gop)
{
    if (!gop || !gop->Mode) return 0;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *info = gop->Mode->Info;
    if (!info) return 0;
    if (info->PixelFormat == PixelBltOnly) return 0;

    fb->base   = (unsigned char *)gop->Mode->FrameBufferBase;
    fb->width  = info->HorizontalResolution;
    fb->height = info->VerticalResolution;
    fb->pitch  = info->PixelsPerScanLine * 4;
    fb->format = (info->PixelFormat == PixelBlueGreenRedReserved8BitPerColor) ? 1 : 0;
    return fb->base != 0;
}

static inline unsigned int rgb_pack(Fb *fb, Rgb c)
{
    if (fb->format == 1)
        return ((unsigned int)c.r << 16) | ((unsigned int)c.g << 8) | c.b;
    return ((unsigned int)c.b << 16) | ((unsigned int)c.g << 8) | c.r;
}

static int clip_x0, clip_y0, clip_x1 = 1 << 30, clip_y1 = 1 << 30;
static int clip_on;

void gfx_clip(int x, int y, int w, int h)
{
    clip_x0 = x < 0 ? 0 : x;
    clip_y0 = y < 0 ? 0 : y;
    clip_x1 = x + w;
    clip_y1 = y + h;
    clip_on = 1;
}

void gfx_clip_off(void)
{
    clip_x0 = clip_y0 = 0;
    clip_x1 = clip_y1 = 1 << 30;
    clip_on = 0;
}

static inline int in_clip(int x, int y)
{
    if (!clip_on) return 1;
    return x >= clip_x0 && x < clip_x1 && y >= clip_y0 && y < clip_y1;
}

static inline void px(Fb *fb, int x, int y, Rgb c)
{
    if (x < 0 || y < 0 || (unsigned)x >= fb->width || (unsigned)y >= fb->height) return;
    if (!in_clip(x, y)) return;
    *(unsigned int *)(fb->base + (unsigned)y * fb->pitch + (unsigned)x * 4) = rgb_pack(fb, c);
}

static inline void blend_px(Fb *fb, int x, int y, Rgb c, int a)
{
    if (a >= 255) { px(fb, x, y, c); return; }
    if (a <= 0) return;
    if (x < 0 || y < 0 || (unsigned)x >= fb->width || (unsigned)y >= fb->height) return;
    if (!in_clip(x, y)) return;
    unsigned char *p = fb->base + (unsigned)y * fb->pitch + (unsigned)x * 4;
    int dr, dg, db, sr, sg, sb;
    if (fb->format == 1) { db = p[0]; dg = p[1]; dr = p[2]; }
    else                 { dr = p[0]; dg = p[1]; db = p[2]; }
    sr = c.r; sg = c.g; sb = c.b;
    dr = (sr * a + dr * (255 - a)) / 255;
    dg = (sg * a + dg * (255 - a)) / 255;
    db = (sb * a + db * (255 - a)) / 255;
    Rgb out;
    out.r = (unsigned char)dr; out.g = (unsigned char)dg; out.b = (unsigned char)db;
    *(unsigned int *)p = rgb_pack(fb, out);
}

void gfx_fill(Fb *fb, Rgb c)
{
    gfx_rect(fb, 0, 0, (int)fb->width, (int)fb->height, c, 255);
}

void (*gfx_pump)(void);

static inline void pump_tick(void);
static int pump_counter;

static inline void pump_tick(void)
{
    if (gfx_pump && ++pump_counter >= 20000) {
        pump_counter = 0;
        gfx_pump();
    }
}

void gfx_vgrad(Fb *fb, Rgb top, Rgb bottom)
{
    for (int y = 0; y < (int)fb->height; y++) {
        int t = y * 255 / (int)(fb->height ? fb->height - 1 : 1);
        Rgb c = { (unsigned char)(top.r + (bottom.r - top.r) * t / 255),
                  (unsigned char)(top.g + (bottom.g - top.g) * t / 255),
                  (unsigned char)(top.b + (bottom.b - top.b) * t / 255) };
        for (int x = 0; x < (int)fb->width; x++) { px(fb, x, y, c); pump_tick(); }
    }
}

void gfx_rect(Fb *fb, int x, int y, int w, int h, Rgb c, int alpha)
{
    if (w <= 0 || h <= 0) return;

    if (alpha >= 255) {
        unsigned int v = rgb_pack(fb, c);
        for (int j = 0; j < h; j++) {
            int yy = y + j;
            if (yy < 0 || (unsigned)yy >= fb->height) continue;
            int x0 = x < 0 ? 0 : x;
            int x1 = x + w;
            if (x1 > (int)fb->width) x1 = (int)fb->width;
            if (x1 <= x0) continue;
            unsigned int *p = (unsigned int *)(fb->base + (unsigned)yy * fb->pitch) + x0;
            for (int i = x0; i < x1; i++) *p++ = v;
            pump_tick();
        }
        return;
    }

    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++) {
            blend_px(fb, x + i, y + j, c, alpha);
        }
}

/* 圆角矩形：四角按到圆心距离裁剪 */
void gfx_round_rect(Fb *fb, int x, int y, int w, int h, int r, Rgb c, int alpha)
{
    if (w <= 0 || h <= 0) return;
    if (r * 2 > w) r = w / 2;
    if (r * 2 > h) r = h / 2;
    for (int j = 0; j < h; j++) {
        for (int i = 0; i < w; i++) {
            int cx = -1, cy = -1;
            if (i < r) cx = r; else if (i >= w - r) cx = w - r - 1;
            if (j < r) cy = r; else if (j >= h - r) cy = h - r - 1;
            if (cx >= 0 && cy >= 0) {
                int dx = i - cx, dy = j - cy;
                if (dx * dx + dy * dy > r * r) continue;
            }
            blend_px(fb, x + i, y + j, c, alpha);
        }
    }
}

static const unsigned char *cjk_lookup(unsigned int cp)
{
    for (int i = 0; i < CJK_COUNT; i++)
        if (cjk_glyphs[i].cp == cp) return cjk_glyphs[i].bits;
    return 0;
}

/* 逐字符解码：ASCII 走 5x7（按 scale），中文走 14x14 点阵（1:1） */
int gfx_text_cn(Fb *fb, int x, int y, int scale, Rgb c, int alpha, const char *s)
{
    int cx = x;
    const unsigned char *p = (const unsigned char *)s;

    while (*p) {
        unsigned int cp = *p;
        if (cp < 0x80) p++;
        else if ((cp & 0xE0) == 0xC0) { cp = ((cp & 0x1F) << 6) | (p[1] & 0x3F); p += 2; }
        else if ((cp & 0xF0) == 0xE0) { cp = ((cp & 0x0F) << 12) | ((p[1] & 0x3F) << 6) | (p[2] & 0x3F); p += 3; }
        else { cp = ((cp & 0x07) << 18) | ((p[1] & 0x3F) << 12) | ((p[2] & 0x3F) << 6) | (p[3] & 0x3F); p += 4; }

        if (cp < 0x80) {
            char one[2] = { (char)cp, 0 };
            gfx_text(fb, cx, y, scale, c, alpha, one);
            cx += 6 * scale;
        } else {
            const unsigned char *bits = cjk_lookup(cp);
            if (bits) {
                for (int row = 0; row < CJK_H; row++) {
                    for (int col = 0; col < CJK_W; col++) {
                        int bit = row * CJK_W + col;
                        if (bits[bit >> 3] & (0x80 >> (bit & 7)))
                            blend_px(fb, cx + col, y + row, c, alpha);
                    }
                }
            }
            cx += CJK_W + 2;
        }
    }
    return cx - x;
}

void gfx_text(Fb *fb, int x, int y, int scale, Rgb c, int alpha, const char *s)
{
    int cx = x;
    for (const char *p = s; *p; p++) {
        unsigned char ch = (unsigned char)*p;
        if (ch < 32 || ch > 126) ch = '?';
        if (ch >= 'a' && ch <= 'z') ch -= 32;
        const unsigned char *g = FONT5X7[ch - 32];
        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 5; col++) {
                if (g[row] & (0x10 >> col)) {
                    for (int dy = 0; dy < scale; dy++)
                        for (int dx = 0; dx < scale; dx++)
                            blend_px(fb, cx + col * scale + dx, y + row * scale + dy, c, alpha);
                }
            }
        }
        cx += 6 * scale;
    }
}

int gfx_text_w(const char *s, int scale)
{
    int n = 0;
    while (s[n]) n++;
    return n * 6 * scale;
}

void gfx_blit_a4(Fb *fb, int x, int y, int w, int h,
                 const unsigned char *bits, int rowbytes,
                 Rgb c, int scale)
{
    for (int j = 0; j < h * scale; j++) {
        int sy = j / scale;
        for (int i = 0; i < w * scale; i++) {
            int sx = i / scale;
            unsigned char byte = bits[sy * rowbytes + (sx >> 1)];
            int v = (sx & 1) ? (byte & 0x0F) : (byte >> 4);
            if (v) blend_px(fb, x + i, y + j, c, v * 17);
        }
    }
}
