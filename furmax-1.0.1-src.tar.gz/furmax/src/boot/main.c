/* Furmax OS：开机画面 + 桌面与窗口演示（M1 图形基座）。 */
#include "efi.h"
#include "gfx.h"
#include "logo.h"
#include "wm.h"
#include "klog.h"
#include "kmem.h"
#include "fms64.h"
#include "paging.h"

/* UEFI 引导服务交给内核后，不能再调用任何 BootServices 函数。 */
static void *fms_bmp_mem = 0, *fms_ino_mem = 0;
static unsigned char mmap[65536];
static UINTN mmap_size = sizeof(mmap), mmap_desc = 0;

static EFI_STATUS hand_over_to_kernel(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    UINTN size = sizeof(mmap), key = 0, desc_size = 0;
    UINT32 desc_ver = 0;

    for (int attempt = 0; attempt < 8; attempt++) {
        size = sizeof(mmap);
        EFI_STATUS s = st->BootServices->GetMemoryMap(&size, mmap, &key, &desc_size, &desc_ver);
        if (EFI_ERROR(s)) {
            klog("[boot] GetMemoryMap failed\r\n");
            continue;
        }
        s = st->BootServices->ExitBootServices(image, key);
        if (!EFI_ERROR(s)) {
            mmap_size = size;
            mmap_desc = desc_size;
            return EFI_SUCCESS;
        }
        klog("[boot] ExitBootServices retry\r\n");
    }
    return 1;
}

static EFI_GUID gop_guid = {
    0x9042a9de, 0x23dc, 0x4a38,
    { 0x96, 0xfb, 0x7a, 0xde, 0xd0, 0x80, 0x51, 0x6a }
};

static EFI_SYSTEM_TABLE *g_st;

static void boot_text(EFI_SYSTEM_TABLE *st)
{
    st->ConOut->Reset(st->ConOut, 1);
    st->ConOut->ClearScreen(st->ConOut);
    st->ConOut->SetAttribute(st->ConOut, 0x0F);
    st->ConOut->OutputString(st->ConOut, u"\r\n  Furmax OS\r\n  GOP unavailable, text mode.\r\n");
}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    (void)image;
    g_st = st;

    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = 0;
    EFI_STATUS s = st->BootServices->LocateProtocol(&gop_guid, 0, (void **)&gop);
    Fb fb;

    if (!EFI_ERROR(s) && gop) gfx_choose_mode(gop, st->BootServices, 1280, 800);

    if (EFI_ERROR(s) || !gop || !gfx_open(&fb, gop)) {
        boot_text(st);
        for (;;) __asm__ volatile("hlt");
    }

    /* 开机画面 */
    klog("[boot] framebuffer base: ");
    klog_hex((unsigned long long)gop->Mode->FrameBufferBase);
    klog(" size ");
    klog_dec((long long)gop->Mode->FrameBufferSize);
    klog("\r\n");

    gfx_fill(&fb, RGB(0, 0, 0));
    int scale = (int)(fb.width - 120) / LOGO_W;
    if (scale < 1) scale = 1;
    int lw = LOGO_W * scale, lh = LOGO_H * scale;
    int lx = ((int)fb.width - lw) / 2;
    int ly = ((int)fb.height - lh) / 2 - 20;
    gfx_blit_a4(&fb, lx, ly, LOGO_W, LOGO_H, LOGO_BITS,
                (LOGO_W + 1) / 2, RGB(255, 255, 255), scale);

    int bar_w = lw / 2, bar_x = ((int)fb.width - bar_w) / 2, bar_y = ly + lh + 56;
    gfx_round_rect(&fb, bar_x, bar_y, bar_w, 4, 2, RGB(255, 255, 255), 40);
    gfx_round_rect(&fb, bar_x, bar_y, bar_w * 3 / 4, 4, 2, RGB(255, 255, 255), 230);

    /* 版权行 */
    {
        const char *cr = "(C) 2026 DEEPBLUE NETWORK  ALL RIGHTS RESERVED";
        int cw = 0;
        for (int i = 0; cr[i]; i++) cw += 6 * 2;
        gfx_text(&fb, ((int)fb.width - cw) / 2, (int)fb.height - 56, 2,
                 RGB(150, 150, 160), 210, cr);
    }

    /* 停留约 2 秒后进入桌面演示 */
    st->BootServices->Stall(2000000);
#ifdef HOLD_SPLASH
    for (;;) __asm__ volatile("hlt");
#endif

    klog_init();
    klog("[boot] handing over to kernel\r\n");

    UINTN bytes = (UINTN)fb.width * fb.height * 4;
    void *back_mem = 0, *wall_mem = 0;
    if (EFI_ERROR(st->BootServices->AllocatePool(2, bytes, &back_mem)) ||
        EFI_ERROR(st->BootServices->AllocatePool(2, bytes, &wall_mem)) ||
        EFI_ERROR(st->BootServices->AllocatePool(2, 16384, &fms_bmp_mem)) ||
        EFI_ERROR(st->BootServices->AllocatePool(2, 4096, &fms_ino_mem))) {
        boot_text(st);
        for (;;) __asm__ volatile("hlt");
    }

    if (EFI_ERROR(hand_over_to_kernel(image, st))) {
        boot_text(st);
        for (;;) __asm__ volatile("hlt");
    }

    klog("[boot] boot services exited\r\n");
    paging_init();

    kmem_init(mmap, mmap_size, mmap_desc);
    klog("[kernel] heap start: ");
    klog_hex(kmem_heap_start());
    klog("\r\n");
    klog("[kernel] free RAM bytes: ");
    klog_dec(kmem_free_bytes());
    klog("\r\n");
    klog("[boot] back=");
    klog_hex((unsigned long long)back_mem);
    klog(" wall=");
    klog_hex((unsigned long long)wall_mem);
    klog(" bmp=");
    klog_hex((unsigned long long)fms_bmp_mem);
    klog(" ino=");
    klog_hex((unsigned long long)fms_ino_mem);
    klog("\r\n");
    fms_set_buffers(fms_bmp_mem, fms_ino_mem);
    wm_start(&fb, back_mem, wall_mem);

    for (;;) __asm__ volatile("hlt");
    return EFI_SUCCESS;
}
