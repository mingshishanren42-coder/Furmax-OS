#ifndef FURMAX_WM_H
#define FURMAX_WM_H

#include "efi.h"
#include "gfx.h"

/* 进入交互式桌面：鼠标拖动、点选、灰条按钮、透明度层叠。不返回。 */
void wm_start(Fb *screen, void *back_mem, void *wall_mem);

#endif
