#ifndef FURMAX_FSOPS_H
#define FURMAX_FSOPS_H

/* 内存文件系统 + 磁盘写穿，供内核与系统调用共用 */
void fs_persist_write(const char *name, const void *data, unsigned int len);
void fs_persist_remove(const char *name);
int  fs_disk_ready(void);
void fs_set_disk_ready(int ready);
unsigned int fs_free_blocks(void);

#endif
