/* Furmax OS 用户态：.fx 加载、用户页映射、ring3 进入/退出、系统调用 */
#include "usermode.h"
#include "gdt.h"
#include "kmem.h"
#include "klog.h"
#include "paging.h"
#include "mfs.h"
#include "sched.h"
#include "fsops.h"

typedef unsigned long long u64;

static int exited;

int um_exited(void) { return exited; }

static unsigned int rd32(const unsigned char *p)
{
    return (unsigned int)p[0] | ((unsigned int)p[1] << 8) |
           ((unsigned int)p[2] << 16) | ((unsigned int)p[3] << 24);
}

/* 0=系统文件（应用只读），N=任务私有文件（仅属主可读写） */
static int acl_check(const char *name, int write)
{
    int owner = fms_get_owner(name);
    if (owner < 0) return 1;            /* 文件不存在：允许创建 */
    if (owner == 0) return write ? 0 : 1;
    return owner == (int)(sched_current() + 1);
}

static int up_ok(u64 a)
{
    u64 base = sched_user_base();
    return a >= base && a < base + 0x200000;
}

static int up_str(char *dst, int max, u64 uaddr)
{
    if (!up_ok(uaddr)) return -1;
    const char *s = (const char *)uaddr;
    int n = 0;
    while (n < max - 1 && s[n] && n < 200) { dst[n] = s[n]; n++; }
    dst[n] = 0;
    return n;
}

void um_syscall(u64 *frame)
{
    u64 nr = frame[14];       /* rax */
    u64 a0 = frame[8];        /* rdi */
    u64 a1 = frame[9];        /* rsi */

    if (nr == 1) {            /* write(ptr, len) */
        if (a0 >= 0x400000 && a0 < 0xA00000 && a1 < 200) {
            sched_write_out((const char *)a0, (unsigned int)a1);
            frame[14] = a1;
        } else {
            frame[14] = (u64)-1;
        }
        return;
    }

    if (nr == 3) {            /* read_file(name, buf, max) */
        char name[64];
        if (up_str(name, sizeof(name), a0) < 0 || !up_ok(a1)) { frame[14] = (u64)-1; return; }
        u64 max = frame[12];  /* rdx */
        if (max > 4096) max = 4096;
        if (a1 + max > sched_user_base() + 0x200000) { frame[14] = (u64)-1; return; }
        unsigned char tmp[4096];
        unsigned int sz = 0;
        if (!acl_check(name, 0)) { frame[14] = (u64)-1; return; }
        if (mfs_read(name, tmp, (unsigned int)max, &sz) != 0) { frame[14] = (u64)-1; return; }
        unsigned int n = sz < max ? sz : (unsigned int)max;
        unsigned char *dst = (unsigned char *)a1;
        for (unsigned int i = 0; i < n; i++) dst[i] = tmp[i];
        frame[14] = n;
        return;
    }

    if (nr == 4) {            /* write_file(name, buf, len) */
        char name[64];
        if (up_str(name, sizeof(name), a0) < 0 || !up_ok(a1)) { frame[14] = (u64)-1; return; }
        u64 len = frame[12];  /* rdx */
        if (len > 4096) len = 4096;
        /* 用户缓冲区必须完整落在该任务的 2MB 用户区内 */
        if (a1 + len > sched_user_base() + 0x200000) { frame[14] = (u64)-1; return; }
        const unsigned char *src = (const unsigned char *)a1;
        unsigned char tmp[4096];
        for (u64 i = 0; i < len; i++) tmp[i] = src[i];
        if (!acl_check(name, 1)) { frame[14] = (u64)-2; return; }
        int wr = mfs_write(name, tmp, (unsigned int)len, 0);
        if (wr == 0 && fms_get_owner(name) < 0) fms_set_owner(name, (unsigned)(sched_current() + 1));
        else if (wr == 0 && fms_get_owner(name) == 0) fms_set_owner(name, (unsigned)(sched_current() + 1));
        if (wr == 0) fs_persist_write(name, tmp, (unsigned int)len);
        frame[14] = (wr == 0) ? 0 : (u64)-1;
        return;
    }

    if (nr == 5) {            /* ui_clear(color) */
        ui_clear(sched_current());
        frame[14] = 0;
        return;
    }

    if (nr == 6) {            /* ui_text(x, y, color, ptr) */
        int x = (int)frame[8], y = (int)frame[9];
        u64 color = frame[12];
        u64 ptr = frame[13];
        if (!up_ok(ptr)) { frame[14] = (u64)-1; return; }
        const char *txt = (const char *)ptr;
        char buf[40];
        int n = 0;
        while (n < 39 && txt[n] && n < 200) { buf[n] = txt[n]; n++; }
        buf[n] = 0;
        ui_text(sched_current(), x, y, (unsigned int)color, buf);
        frame[14] = 0;
        return;
    }

    if (nr == 7) {            /* ui_rect(x, y, w, h, color) */
        int x = (int)frame[8], y = (int)frame[9];
        int w = (int)frame[12], h = (int)frame[13];
        u64 color = frame[7];   /* r8 */
        ui_rect(sched_current(), x, y, w, h, (unsigned int)color);
        frame[14] = 0;
        return;
    }

    if (nr == 10) {           /* get_arg(buf, max) -> 长度 */
        u64 ptr = frame[8];
        u64 max = frame[9];
        if (!up_ok(ptr)) { frame[14] = (u64)-1; return; }
        if (max > 63) max = 63;
        const char *a = sched_args(sched_current());
        unsigned int n = 0;
        while (n < max && a[n]) { ((char *)ptr)[n] = a[n]; n++; }
        if (n < max) ((char *)ptr)[n] = 0;
        frame[14] = n;
        return;
    }

    if (nr == 9) {            /* ui_image(x, y, w, h, ptr) */
        int x = (int)frame[8], y = (int)frame[9];
        int w = (int)frame[12], h = (int)frame[13];
        u64 ptr = frame[7];
        if (!up_ok(ptr) || w <= 0 || h <= 0 || w > 64 || h > 64) { frame[14] = (u64)-1; return; }
        if (ptr + (u64)(w * h * 4) > sched_user_base() + 0x200000) { frame[14] = (u64)-1; return; }
        ui_image(sched_current(), x, y, w, h, (const void *)ptr);
        frame[14] = 0;
        return;
    }

    if (nr == 8) {            /* ui_poll(event_ptr) */
        u64 ptr = frame[8];
        if (!up_ok(ptr)) { frame[14] = (u64)-1; return; }
        UiEvent ev;
        if (ui_pop_event(sched_current(), &ev)) {
            int *out = (int *)ptr;
            out[0] = ev.type;
            out[1] = ev.x;
            out[2] = ev.y;
            out[3] = ev.key;
            frame[14] = 1;
        } else {
            frame[14] = 0;
        }
        return;
    }

    if (nr == 2) {            /* exit */
        exited = 1;
        frame[14] = 0;
        sched_on_exit(frame);
        return;
    }

    frame[14] = (u64)-1;
}
