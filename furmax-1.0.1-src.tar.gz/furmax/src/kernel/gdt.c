/* Furmax OS：自有 GDT + TSS
 * 用户态需要 DPL3 的代码/数据段，以及从 ring3 进中断时用的内核栈（TSS.rsp0）。 */
#include "gdt.h"
#include "klog.h"

typedef unsigned long long u64;

typedef struct {
    unsigned int  reserved1;
    u64 rsp0;
    u64 rsp1;
    u64 rsp2;
    u64 reserved2;
    u64 ist[7];
    u64 reserved3;
    unsigned short reserved4;
    unsigned short iomap_base;
} __attribute__((packed)) Tss;

static u64 gdt[8];
static Tss tss;
static unsigned char kstack[16384] __attribute__((aligned(16)));

static void set_desc(int i, u64 v) { gdt[i] = v; }

void gdt_set_kernel_stack(unsigned long long rsp0)
{
    tss.rsp0 = rsp0;
    tss.rsp1 = rsp0;
    tss.rsp2 = rsp0;
}

unsigned long long gdt_kernel_stack_top(void)
{
    return (unsigned long long)kstack + sizeof(kstack);
}

void gdt_init(void)
{
    /* 段描述符：base=0 limit=0xFFFFF，G=1 D/B=1 L=1(64位) */
    set_desc(0, 0);
    set_desc(1, 0x00AF9A000000FFFFULL);   /* ring0 code */
    set_desc(2, 0x00AF92000000FFFFULL);   /* ring0 data */
    set_desc(3, 0x00AFFA000000FFFFULL);   /* ring3 code */
    set_desc(4, 0x00AFF2000000FFFFULL);   /* ring3 data */

    unsigned char *tp = (unsigned char *)&tss;
    for (unsigned int i = 0; i < sizeof(tss); i++) tp[i] = 0;
    tss.rsp0 = gdt_kernel_stack_top();
    tss.rsp1 = tss.rsp0;
    tss.rsp2 = tss.rsp0;
    tss.iomap_base = (unsigned short)sizeof(tss);

    u64 base = (u64)&tss;
    u64 limit = sizeof(tss) - 1;
    /* TSS 描述符（16 字节，占两个槽） */
    gdt[5] = (limit & 0xFFFF) | ((base & 0xFFFFFF) << 16) |
             (0x89ULL << 40) | (((limit >> 16) & 0xF) << 48) |
             (((base >> 24) & 0xFF) << 56);
    gdt[6] = (base >> 32) & 0xFFFFFFFF;

    struct { unsigned short limit; u64 base; } __attribute__((packed)) gdtr = {
        (unsigned short)(sizeof(gdt) - 1), (u64)gdt
    };
    __asm__ volatile("lgdt %0" :: "m"(gdtr));

    /* 重新加载代码段：压入 0x08 + 返回地址，retfq */
    __asm__ volatile(
        "pushq %0\n"
        "leaq 1f(%%rip), %%rax\n"
        "pushq %%rax\n"
        "retfq\n"
        "1:\n"
        :
        : "i"(SEL_KCODE)
        : "rax", "memory");

    __asm__ volatile(
        "mov %0, %%ds\n"
        "mov %0, %%es\n"
        "mov %0, %%ss\n"
        "mov %0, %%fs\n"
        "mov %0, %%gs\n"
        :: "r"((unsigned short)SEL_KDATA));

    unsigned short tr = SEL_TSS;
    __asm__ volatile("ltr %0" :: "r"(tr));

    klog("[gdt] loaded, tss rsp0=");
    klog_hex(gdt_kernel_stack_top());
    klog("\r\n");
}
