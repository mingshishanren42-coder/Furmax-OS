#ifndef FURMAX_ATA_H
#define FURMAX_ATA_H

#define ATA_SECTOR 512

int  ata_init(int drive);                                   /* drive: 0 主盘, 1 从盘 */
int  ata_read(int drive, unsigned int lba, void *buf, int count);
int  ata_write(int drive, unsigned int lba, const void *buf, int count);

#endif
