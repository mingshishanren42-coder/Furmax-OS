#ifndef FURMAX_VIRTIO_H
#define FURMAX_VIRTIO_H

int  vio_init(void);
int  vio_read(unsigned long long lba, void *buf, int count);
int  vio_write(unsigned long long lba, const void *buf, int count);
unsigned long long vio_capacity(void);

#endif
