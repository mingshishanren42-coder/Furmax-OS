#ifndef FURMAX_RTC_H
#define FURMAX_RTC_H

typedef struct {
    int year, month, day;
    int hour, minute, second;
} RtcTime;

void rtc_read(RtcTime *t);

#endif
