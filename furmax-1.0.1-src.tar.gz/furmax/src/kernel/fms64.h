#ifndef FURMAX_FMS64_H
#define FURMAX_FMS64_H

#define FMS_NAME_MAX 48

typedef struct {
    char name[FMS_NAME_MAX];
    unsigned int size;
} FmsEntry;

void fms_set_buffers(void *bitmap, void *inodes);
void fms_set_driver(int virtio);
int  fms_mount(void);
int  fms_list(FmsEntry *out, int max);
int  fms_read(const char *name, void *buf, unsigned int max, unsigned int *out_size);
int  fms_write(const char *name, const void *buf, unsigned int size);
int  fms_remove(const char *name);
unsigned int fms_free_blocks(void);

/* v2 目录 */
int fms_lookup(const char *path);
int fms_mkdir(const char *path);
int fms_readdir(const char *path, FmsEntry *out, int max);
void fms_mkroot(void);
int  fms_list_all(FmsEntry *out, int max);
int  fms_rmdir(const char *path);
int  fms_rename(const char *from, const char *to);
int  fms_fsck(void);
int  fms_get_owner(const char *path);
int  fms_set_owner(const char *path, unsigned int owner);

#endif
