/* Furmax 内核串口日志（COM1），用于无显示调试 */
#include "klog.h"

static inline void outb(unsigned short p, unsigned char v)
{
    __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(p));
}
static inline unsigned char inb(unsigned short p)
{
    unsigned char v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v;
}

void klog_init(void)
{
    outb(0x3F8 + 1, 0x00);
    outb(0x3F8 + 3, 0x80);
    outb(0x3F8 + 0, 0x01);
    outb(0x3F8 + 1, 0x00);
    outb(0x3F8 + 3, 0x03);
    outb(0x3F8 + 2, 0xC7);
    outb(0x3F8 + 4, 0x0B);
}

static void putc_(char c)
{
    for (int i = 0; i < 100000; i++) if (inb(0x3F8 + 5) & 0x20) break;
    outb(0x3F8, (unsigned char)c);
}

void klog(const char *s)
{
    while (*s) putc_(*s++);
}

void klog_hex(unsigned long long v)
{
    const char *h = "0123456789abcdef";
    klog("0x");
    for (int i = 60; i >= 0; i -= 4) putc_(h[(v >> i) & 0xF]);
}

void klog_dec(unsigned long long v)
{
    char b[24]; int n = 0;
    if (!v) { putc_('0'); return; }
    while (v) { b[n++] = (char)('0' + v % 10); v /= 10; }
    while (n) putc_(b[--n]);
}
