/* Furmax OS 内存文件系统（MFS）
 * 用于在磁盘驱动完善前，先跑通"建文件 / 写内容 / 读回 / 删除 / 列举"。 */
#include "mfs.h"
#include "kmem.h"
#include "klog.h"

typedef struct {
    char name[MFS_NAME_MAX];
    unsigned int size;
    unsigned int cap;
    unsigned char *data;
} MFile;

#define MFS_MAX 64
static MFile files[MFS_MAX];
static int nfiles;
static int inited;
static unsigned long long used;

static int same(const char *a, const char *b)
{
    while (*a && *b) {
        char ca = *a++, cb = *b++;
        if (ca >= 'a' && ca <= 'z') ca -= 32;
        if (cb >= 'a' && cb <= 'z') cb -= 32;
        if (ca != cb) return 0;
    }
    return *a == *b;
}

static void copy_name(char *dst, const char *src)
{
    int i = 0;
    for (; src[i] && i < MFS_NAME_MAX - 1; i++) dst[i] = src[i];
    dst[i] = 0;
}

void mfs_init(void)
{
    nfiles = 0;
    used = 0;
    inited = 1;
}

static MFile *find(const char *name)
{
    for (int i = 0; i < nfiles; i++)
        if (same(files[i].name, name)) return &files[i];
    return 0;
}

int mfs_create(const char *name)
{
    if (!inited || !name || !name[0]) return -1;
    if (find(name)) return 0;
    if (nfiles >= MFS_MAX) return -2;

    MFile *f = &files[nfiles];
    copy_name(f->name, name);
    f->size = 0;
    f->cap = 0;
    f->data = 0;
    nfiles++;
    return 0;
}

static int grow(MFile *f, unsigned int need)
{
    if (need <= f->cap) return 0;
    unsigned int cap = f->cap ? f->cap : 1024;
    while (cap < need) cap *= 2;

    unsigned char *p = (unsigned char *)kmem_alloc(cap);
    if (!p) return -3;

    for (unsigned int i = 0; i < f->size; i++) p[i] = f->data[i];
    f->data = p;
    f->cap = cap;
    return 0;
}

int mfs_write(const char *name, const void *data, unsigned int len, int append)
{
    if (!inited) return -1;

    int r = mfs_create(name);
    if (r != 0) return r;
    MFile *f = find(name);
    if (!f) return -1;

    unsigned int base = append ? f->size : 0;
    if (grow(f, base + len) != 0) return -4;

    const unsigned char *src = (const unsigned char *)data;
    for (unsigned int i = 0; i < len; i++) f->data[base + i] = src[i];
    if (!append) used -= f->size;
    f->size = base + len;
    used += len;
    return 0;
}

int mfs_read(const char *name, void *buf, unsigned int max, unsigned int *out_size)
{
    MFile *f = find(name);
    if (!f) return -1;
    unsigned int n = f->size < max ? f->size : max;
    unsigned char *dst = (unsigned char *)buf;
    for (unsigned int i = 0; i < n; i++) dst[i] = f->data[i];
    if (out_size) *out_size = f->size;
    return 0;
}

int mfs_remove(const char *name)
{
    for (int i = 0; i < nfiles; i++) {
        if (!same(files[i].name, name)) continue;
        used -= files[i].size;
        for (int k = i; k < nfiles - 1; k++) files[k] = files[k + 1];
        nfiles--;
        return 0;
    }
    return -1;
}

int mfs_truncate(const char *name, unsigned int new_size)
{
    MFile *f = find(name);
    if (!f) return -1;
    if (new_size >= f->size) return 0;
    used -= (f->size - new_size);
    f->size = new_size;
    return 0;
}

int mfs_list(MfsEntry *out, int max)
{
    int n = 0;
    for (int i = 0; i < nfiles && n < max; i++) {
        copy_name(out[n].name, files[i].name);
        out[n].size = files[i].size;
        n++;
    }
    return n;
}

unsigned long long mfs_used_bytes(void) { return used; }
int mfs_count(void) { return nfiles; }
