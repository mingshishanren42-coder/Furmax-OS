/* Furmax OS 简单调度器：最多 3 个用户任务，时钟中断做轮转切换 */
#include "sched.h"
#include "gdt.h"
#include "kmem.h"
#include "klog.h"
#include "mfs.h"
#include "paging.h"
#include "idt.h"
const char *um_output_ptr(void);

extern void um_enter(u64 rip, u64 rsp);
extern void um_resume(u64 *frame);
extern void um_exit_stub(void);

static unsigned long long slice_end;

#define MAX_TASKS 6
#define USER_BASE(i) (0x400000ULL + (u64)(i) * 0x200000ULL)

#define P_PRESENT 1ULL
#define P_RW      2ULL
#define P_USER    4ULL

typedef struct {
    int used;
    int alive;
    char name[24];
    u64 regs[15];
    u64 rip, rflags, rsp;
} Task;

static Task tasks[MAX_TASKS];
static unsigned long long slot_pt[MAX_TASKS];
static unsigned long long slot_pages[MAX_TASKS][3];
static unsigned long long slot_stack[MAX_TASKS];

static void slot_release(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return;
    if (slot_pages[slot][0]) kmem_free((void *)slot_pages[slot][0]);
    if (slot_pages[slot][1]) kmem_free((void *)slot_pages[slot][1]);
    if (slot_pages[slot][2]) kmem_free((void *)slot_pages[slot][2]);
    if (slot_stack[slot]) kmem_free((void *)slot_stack[slot]);
    if (slot_pt[slot]) {
        /* 先摘掉页表映射，避免悬空指向已释放的内存 */
        u64 *pd0 = paging_pd0();
        pd0[(USER_BASE(slot) >> 21) & 511] = 0;
        u64 cr3;
        __asm__ volatile("mov %%cr3, %0" : "=r"(cr3));
        __asm__ volatile("mov %0, %%cr3" :: "r"(cr3) : "memory");
        kmem_free((void *)slot_pt[slot]);
    }
    slot_pages[slot][0] = slot_pages[slot][1] = slot_pages[slot][2] = 0;
    slot_stack[slot] = 0;
    slot_pt[slot] = 0;
}
static int cur = -1;

static char out[MAX_TASKS][256];
static int out_len[MAX_TASKS];
static char task_args[MAX_TASKS][64];

#define MAX_OPS 32
static UiOp ops[MAX_TASKS][MAX_OPS];
static int opn[MAX_TASKS];

#define IMG_MAX 64
static unsigned char img_buf[MAX_TASKS][IMG_MAX * IMG_MAX * 4];
static int img_w[MAX_TASKS], img_h[MAX_TASKS];



#define MAX_EVENTS 16
static UiEvent events[MAX_TASKS][MAX_EVENTS];
static int ev_head[MAX_TASKS], ev_tail[MAX_TASKS];



void ui_clear(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return;
    opn[slot] = 0;
    img_w[slot] = img_h[slot] = 0;
}

static UiOp *ui_new(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return 0;
    if (opn[slot] >= MAX_OPS) return 0;
    UiOp *o = &ops[slot][opn[slot]++];
    o->type = 0;
    o->text[0] = 0;
    return o;
}

void ui_text(int slot, int x, int y, unsigned int color, const char *text)
{
    UiOp *o = ui_new(slot);
    if (!o) return;
    o->type = 1;
    o->x = x; o->y = y;
    o->color = color;
    int n = 0;
    while (text[n] && n < 39) { o->text[n] = text[n]; n++; }
    o->text[n] = 0;
}

void ui_rect(int slot, int x, int y, int w, int h, unsigned int color)
{
    UiOp *o = ui_new(slot);
    if (!o) return;
    o->type = 2;
    o->x = x; o->y = y; o->w = w; o->h = h;
    o->color = color;
}

void ui_push_event(int slot, int type, int x, int y, int key)
{
    if (slot < 0 || slot >= MAX_TASKS) return;
    int n = (ev_head[slot] + 1) % MAX_EVENTS;
    if (n == ev_tail[slot]) return;
    events[slot][ev_head[slot]].type = type;
    events[slot][ev_head[slot]].x = x;
    events[slot][ev_head[slot]].y = y;
    events[slot][ev_head[slot]].key = key;
    ev_head[slot] = n;
}

int ui_pop_event(int slot, UiEvent *out)
{
    if (slot < 0 || slot >= MAX_TASKS) return 0;
    if (ev_tail[slot] == ev_head[slot]) return 0;
    *out = events[slot][ev_tail[slot]];
    ev_tail[slot] = (ev_tail[slot] + 1) % MAX_EVENTS;
    return 1;
}

void ui_image(int slot, int x, int y, int w, int h, const void *pixels)
{
    if (slot < 0 || slot >= MAX_TASKS) return;
    if (w <= 0 || h <= 0 || w > IMG_MAX || h > IMG_MAX) return;

    const unsigned char *src = (const unsigned char *)pixels;
    for (int i = 0; i < w * h * 4; i++) img_buf[slot][i] = src[i];
    img_w[slot] = w;
    img_h[slot] = h;

    UiOp *o = ui_new(slot);
    if (!o) return;
    o->type = 3;
    o->x = x; o->y = y; o->w = w; o->h = h;
}

const unsigned char *ui_image_data(int slot, int *w, int *h)
{
    if (slot < 0 || slot >= MAX_TASKS) return 0;
    *w = img_w[slot];
    *h = img_h[slot];
    return img_buf[slot];
}

const UiOp *ui_ops(int slot, int *count)
{
    if (slot < 0 || slot >= MAX_TASKS) { *count = 0; return 0; }
    *count = opn[slot];
    return ops[slot];
}

void sched_write_out(const char *buf, unsigned int len)
{
    int s = (cur >= 0) ? cur : 0;
    for (unsigned int i = 0; i < len; i++) {
        if (out_len[s] < (int)sizeof(out[s]) - 1) out[s][out_len[s]++] = buf[i];
    }
    out[s][out_len[s]] = 0;
}

const char *sched_output(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return "";
    return out[slot];
}

const char *sched_name(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return "";
    return tasks[slot].name;
}

int sched_used(int slot) { return (slot >= 0 && slot < MAX_TASKS) ? tasks[slot].used : 0; }
int sched_kill(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return -1;
    if (!tasks[slot].used) return -1;
    tasks[slot].alive = 0;
    if (cur != slot) {
        tasks[slot].used = 0;
        slot_release(slot);
        opn[slot] = 0;
        out_len[slot] = 0;
    }
    klog("[sched] killed ");
    klog(tasks[slot].name);
    klog("\r\n");
    return 0;
}

int sched_running(int slot) { return (slot >= 0 && slot < MAX_TASKS) ? tasks[slot].alive : 0; }
int sched_current(void) { return cur; }
unsigned long long sched_user_base(void)
{
    if (cur < 0) return USER_BASE(0);
    return USER_BASE(cur);
}

int sched_out_len(int slot) { return (slot >= 0 && slot < MAX_TASKS) ? out_len[slot] : 0; }

int sched_alive(void)
{
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++) if (tasks[i].alive) n++;
    return n;
}

int sched_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++) if (tasks[i].used) n++;
    return n;
}

static unsigned int rd32(const unsigned char *p)
{
    return (unsigned int)p[0] | ((unsigned int)p[1] << 8) |
           ((unsigned int)p[2] << 16) | ((unsigned int)p[3] << 24);
}

const char *sched_args(int slot)
{
    if (slot < 0 || slot >= MAX_TASKS) return "";
    return task_args[slot];
}

int sched_spawn_args(const char *name, const char *args)
{
    int slot = sched_spawn(name);
    if (slot >= 0) {
        int n = 0;
        while (args && args[n] && n < 63) { task_args[slot][n] = args[n]; n++; }
        task_args[slot][n] = 0;
        klog("[sched] args=");
        klog(task_args[slot]);
        klog("\r\n");
    }
    return slot;
}

int sched_spawn(const char *name)
{
    int slot = -1;
    for (int i = 0; i < MAX_TASKS; i++) if (!tasks[i].used) { slot = i; break; }
    if (slot < 0) {
        for (int i = 0; i < MAX_TASKS; i++) if (!tasks[i].alive) { slot = i; break; }
    }
    if (slot < 0) { klog("[sched] no free slot\r\n"); return -1; }

    static unsigned char file[4096];
    unsigned int fsz = 0;
    if (mfs_read(name, file, sizeof(file), &fsz) != 0) {
        klog("[sched] file not found\r\n");
        return -1;
    }
    if (fsz < 12 || file[0] != 'F' || file[1] != 'X' || file[2] != '0' || file[3] != '1') {
        klog("[sched] bad .fx\r\n");
        return -1;
    }

    unsigned int code_size = rd32(file + 4);
    unsigned int entry_off = rd32(file + 8);
    if (code_size == 0 || code_size > 3 * 4096 || 12 + code_size > fsz ||
        entry_off >= code_size) {
        klog("[sched] bad size\r\n");
        return -1;
    }

    u64 base = USER_BASE(slot);
    slot_release(slot);                 /* 复用槽位前先归还上一轮内存 */
    u64 *pt = (u64 *)kmem_alloc(4096);
    if (!pt) return -1;
    slot_pt[slot] = (unsigned long long)pt;
    slot_pages[slot][0] = slot_pages[slot][1] = slot_pages[slot][2] = 0;
    slot_stack[slot] = 0;
    for (int i = 0; i < 512; i++) pt[i] = 0;

    unsigned int pages = (code_size + 4095) / 4096;
    for (unsigned int pg = 0; pg < pages; pg++) {
        unsigned char *mem = (unsigned char *)kmem_alloc(4096);
        if (!mem) return -1;
        if (pg < 3) slot_pages[slot][pg] = (unsigned long long)mem;
        for (int i = 0; i < 4096; i++) mem[i] = 0;
        for (unsigned int i = 0; i < 4096; i++) {
            unsigned int src = pg * 4096 + i;
            if (src < code_size) mem[i] = file[12 + src];
        }
        pt[pg] = (u64)mem | P_PRESENT | P_RW | P_USER;
    }

    unsigned char *stack = (unsigned char *)kmem_alloc(4096);
    if (!stack) return -1;
    slot_stack[slot] = (unsigned long long)stack;
    for (int i = 0; i < 4096; i++) stack[i] = 0;
    pt[511] = (u64)stack | P_PRESENT | P_RW | P_USER;

    u64 *pd0 = paging_pd0();
    pd0[(base >> 21) & 511] = (u64)pt | P_PRESENT | P_RW | P_USER;

    u64 cr3;
    __asm__ volatile("mov %%cr3, %0" : "=r"(cr3));
    __asm__ volatile("mov %0, %%cr3" :: "r"(cr3) : "memory");

    out_len[slot] = 0;
    out[slot][0] = 0;
    task_args[slot][0] = 0;
    opn[slot] = 0;
    img_w[slot] = img_h[slot] = 0;

    Task *t = &tasks[slot];
    for (int i = 0; i < 15; i++) t->regs[i] = 0;
    t->rip = base + entry_off;
    t->rsp = base + 0x1FF000 + 0x1000 - 16;
    t->rflags = 0x202;
    t->used = 1;
    klog("[mem] used=");
    klog_dec((long long)(kmem_heap_used() >> 10));
    klog("KB free=");
    klog_dec((long long)(kmem_heap_free() >> 20));
    klog("MB\r\n");
    t->alive = 1;
    int k = 0;
    for (; name[k] && k < 23; k++) t->name[k] = name[k];
    t->name[k] = 0;

    klog("[sched] spawned ");
    klog(name);
    klog("\r\n");
    return slot;
}

static void load_into(u64 *frame, Task *t)
{
    for (int i = 0; i < 15; i++) frame[i] = t->regs[i];
    frame[17] = t->rip;
    frame[18] = SEL_UCODE;
    frame[19] = t->rflags;
    frame[20] = t->rsp;
    frame[21] = SEL_UDATA;
}

static void save_from(u64 *frame, Task *t)
{
    for (int i = 0; i < 15; i++) t->regs[i] = frame[i];
    t->rip = frame[17];
    t->rflags = frame[19];
    t->rsp = frame[20];
}

void sched_tick(u64 *frame)
{
    if (cur < 0) return;
    /* 只从 ring3 切；内核态不打断 */
    if ((frame[18] & 3) != 3) return;

    save_from(frame, &tasks[cur]);

    /* 时间片用完：交还内核，让界面刷新 */
    if (kernel_ticks >= slice_end) {
        frame[17] = (u64)um_exit_stub;
        frame[18] = SEL_KCODE;
        frame[19] = 0x202;
        frame[20] = gdt_kernel_stack_top();
        frame[21] = SEL_KDATA;
        return;
    }

    int next = -1;
    for (int k = 1; k <= MAX_TASKS; k++) {
        int i = (cur + k) % MAX_TASKS;
        if (tasks[i].alive) { next = i; break; }
    }
    if (next < 0 || next == cur) return;

    cur = next;
    load_into(frame, &tasks[cur]);
}

void sched_on_exit(u64 *frame)
{
    if (cur >= 0) tasks[cur].alive = 0;

    int next = -1;
    for (int k = 1; k <= MAX_TASKS; k++) {
        int i = ((cur < 0 ? 0 : cur) + k) % MAX_TASKS;
        if (tasks[i].alive) { next = i; break; }
    }

    if (next >= 0) {
        cur = next;
        load_into(frame, &tasks[cur]);
        klog("[sched] switch to ");
        klog(tasks[cur].name);
        klog("\r\n");
        return;
    }

    /* 没有任务了：回内核 */
    cur = -1;
    frame[17] = (u64)um_exit_stub;
    frame[18] = SEL_KCODE;
    frame[19] = 0x202;
    frame[20] = gdt_kernel_stack_top();
    frame[21] = SEL_KDATA;
    klog("[sched] all tasks done\r\n");
}

void sched_run_slice(unsigned int ms)
{
    int next = -1;
    for (int i = 0; i < MAX_TASKS; i++) if (tasks[i].alive) { next = i; break; }
    if (next < 0) { cur = -1; return; }

    if (cur < 0 || !tasks[cur].alive) cur = next;
    slice_end = kernel_ticks + (ms / 10) + 1;

    static u64 frame[22];
    for (int i = 0; i < 22; i++) frame[i] = 0;
    Task *t = &tasks[cur];
    for (int i = 0; i < 15; i++) frame[i] = t->regs[i];
    frame[17] = t->rip;
    frame[18] = SEL_UCODE;
    frame[19] = t->rflags;
    frame[20] = t->rsp;
    frame[21] = SEL_UDATA;

    gdt_set_kernel_stack(gdt_kernel_stack_top());
    um_resume(frame);
}
