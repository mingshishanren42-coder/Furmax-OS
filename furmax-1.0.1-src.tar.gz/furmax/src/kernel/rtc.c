/* Furmax OS：CMOS 实时时钟（RTC） */
#include "rtc.h"

/* 本地时区偏移（小时）：中国标准时间 UTC+8 */
#define TZ_OFFSET_HOURS 8

static inline void outb(unsigned short p, unsigned char v)
{
    __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(p));
}

static inline unsigned char inb(unsigned short p)
{
    unsigned char v;
    __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p));
    return v;
}

static unsigned char cmos(unsigned char reg)
{
    outb(0x70, reg);
    return inb(0x71);
}

static int bcd(int v)
{
    return (v & 0x0F) + ((v >> 4) * 10);
}

void rtc_read(RtcTime *t)
{
    while (cmos(0x0A) & 0x80) { }      /* 等待更新周期结束 */

    int sec = cmos(0x00);
    int min = cmos(0x02);
    int hour = cmos(0x04);
    int day = cmos(0x07);
    int mon = cmos(0x08);
    int year = cmos(0x09);
    int regb = cmos(0x0B);

    int binary = regb & 0x04;
    if (!binary) {
        sec = bcd(sec); min = bcd(min); hour = bcd(hour & 0x7F);
        day = bcd(day); mon = bcd(mon); year = bcd(year);
    }
    int pm = (hour & 0x80) && !(regb & 0x02);
    hour &= 0x7F;
    if (!(regb & 0x02) && pm && hour < 12) hour += 12;

    hour = (hour + TZ_OFFSET_HOURS) % 24;

    t->second = sec;
    t->minute = min;
    t->hour = hour % 24;
    t->day = day ? day : 1;
    t->month = mon ? mon : 1;
    t->year = 2000 + (year % 100);
}
