/* Furmax OS 物理内存：从 UEFI 内存映射里挑选可用的常规内存做堆 */
#include "kmem.h"
#include "klog.h"

typedef struct {
    UINT32 Type;
    UINT32 Pad;
    UINT64 PhysicalStart;
    UINT64 VirtualStart;
    UINT64 NumberOfPages;
    UINT64 Attribute;
} MemDesc;

#define EFI_CONVENTIONAL_MEMORY 7

static unsigned long long heap_start, heap_end, heap_ptr;
static unsigned long long total_free;

/* 单核自旋锁：保存并关闭中断，避免 IRQ 里重入分配器 */
static inline unsigned long long kmem_lock(void)
{
    unsigned long long flags;
    __asm__ volatile("pushfq; pop %0; cli" : "=r"(flags) :: "memory");
    return flags;
}

static inline void kmem_unlock(unsigned long long flags)
{
    if (flags & 0x200) __asm__ volatile("sti" ::: "memory");
}

void kmem_init(void *map, UINTN map_size, UINTN desc_size)
{
    unsigned char *p = (unsigned char *)map;
    unsigned long long best = 0, best_start = 0;
    total_free = 0;

    for (UINTN off = 0; off + sizeof(MemDesc) <= map_size; off += desc_size) {
        MemDesc *d = (MemDesc *)(p + off);
        if (d->Type != EFI_CONVENTIONAL_MEMORY) continue;
        unsigned long long bytes = d->NumberOfPages * 4096ULL;
        total_free += bytes;
        /* 只接受 1MB 以上、且足够大的连续块 */
        if (d->PhysicalStart < 0x100000ULL) continue;
        if (bytes > best) {
            best = bytes;
            best_start = d->PhysicalStart;
        }
    }

    /* 堆：最大连续块的后半部分，避开低端 2MB */
    if (best > (4ULL << 20)) {
        heap_start = best_start + (2ULL << 20);
        heap_end = best_start + best - (1ULL << 20);
        heap_ptr = heap_start;
    } else {
        heap_start = heap_end = heap_ptr = 0;
    }
}

unsigned long long kmem_free_bytes(void) { return total_free; }
unsigned long long kmem_heap_start(void) { return heap_start; }

unsigned long long kmem_heap_bytes(void)
{
    return heap_end > heap_start ? (heap_end - heap_start) : 0;
}

#define MAX_BLOCKS 192

typedef struct {
    unsigned long long addr;
    unsigned long long pages;
    int used;
} KBlock;

static KBlock blocks[MAX_BLOCKS];
static int nblocks;

static void block_insert(unsigned long long addr, unsigned long long pages, int used)
{
    if (nblocks >= MAX_BLOCKS) return;
    int i = nblocks++;
    while (i > 0 && blocks[i - 1].addr > addr) {
        blocks[i] = blocks[i - 1];
        i--;
    }
    blocks[i].addr = addr;
    blocks[i].pages = pages;
    blocks[i].used = used;
}

void *kmem_alloc(unsigned long long bytes)
{
    unsigned long long pages = (bytes + 0xFFF) >> 12;
    if (!pages) pages = 1;
    if (!heap_start) return 0;

    unsigned long long flags = kmem_lock();

    for (int i = 0; i < nblocks; i++) {
        if (blocks[i].used) continue;
        if (blocks[i].pages < pages) continue;
        unsigned long long addr = blocks[i].addr;
        if (blocks[i].pages > pages) {
            blocks[i].addr += pages << 12;
            blocks[i].pages -= pages;
            block_insert(addr, pages, 1);
        } else {
            blocks[i].used = 1;
        }
        kmem_unlock(flags);
        return (void *)addr;
    }

    unsigned long long need = pages << 12;
    if (heap_ptr + need > heap_end) {
        kmem_unlock(flags);
        return 0;
    }
    void *p = (void *)heap_ptr;
    heap_ptr += need;
    block_insert((unsigned long long)p, pages, 1);
    kmem_unlock(flags);
    return p;
}

void kmem_free(void *ptr)
{
    unsigned long long addr = (unsigned long long)ptr;
    if (!addr) return;

    unsigned long long flags = kmem_lock();

    for (int i = 0; i < nblocks; i++) {
        if (blocks[i].addr != addr || !blocks[i].used) continue;
        blocks[i].used = 0;

        if (i + 1 < nblocks && !blocks[i + 1].used &&
            blocks[i].addr + (blocks[i].pages << 12) == blocks[i + 1].addr) {
            blocks[i].pages += blocks[i + 1].pages;
            for (int j = i + 1; j < nblocks - 1; j++) blocks[j] = blocks[j + 1];
            nblocks--;
        }
        if (i > 0 && !blocks[i - 1].used &&
            blocks[i - 1].addr + (blocks[i - 1].pages << 12) == blocks[i].addr) {
            blocks[i - 1].pages += blocks[i].pages;
            for (int j = i; j < nblocks - 1; j++) blocks[j] = blocks[j + 1];
            nblocks--;
        }
        kmem_unlock(flags);
        return;
    }
    kmem_unlock(flags);
}

unsigned long long kmem_heap_used(void)
{
    unsigned long long used = 0;
    for (int i = 0; i < nblocks; i++)
        if (blocks[i].used) used += blocks[i].pages << 12;
    return used;
}

unsigned long long kmem_heap_free(void)
{
    unsigned long long freeb = 0;
    for (int i = 0; i < nblocks; i++)
        if (!blocks[i].used) freeb += blocks[i].pages << 12;
    if (heap_end > heap_ptr) freeb += heap_end - heap_ptr;
    return freeb;
}
