/* Furmax OS PS/2 键盘驱动：IRQ1，scancode set 1，环形缓冲存 16 位键码 */
#include "kbd.h"
#include "ps2.h"
#include "klog.h"

static inline unsigned char inb(unsigned short p)
{
    unsigned char v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v;
}

#define BUFSZ 128
static volatile unsigned short buf[BUFSZ];
static volatile int head, tail;
static int shift, ctrl, e0;

static const char kmap[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=', '\b','\t',
    'q','w','e','r','t','y','u','i','o','p','[',']','\n', 0,'a','s',
    'd','f','g','h','j','k','l',';','\'','`', 0,'\\','z','x','c','v',
    'b','n','m',',','.','/', 0,'*', 0,' ', 0, 0, 0, 0, 0, 0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

static const char smap[128] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')','_','+', '\b','\t',
    'Q','W','E','R','T','Y','U','I','O','P','{','}','\n', 0,'A','S',
    'D','F','G','H','J','K','L',':','"','~', 0,'|','Z','X','C','V',
    'B','N','M','<','>','?', 0,'*', 0,' ', 0, 0, 0, 0, 0, 0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

static void push(unsigned short c)
{
    if (ctrl) c |= KEY_CTRL;
    int n = (head + 1) % BUFSZ;
    if (n == tail) return;
    buf[head] = c;
    head = n;
}

void kbd_feed(unsigned char sc)
{
    if (sc == 0xE0) { e0 = 1; return; }

    if (e0) {
        e0 = 0;
        if (!(sc & 0x80)) {
            if (sc == 0x4B) push(KEY_LEFT);
            else if (sc == 0x4D) push(KEY_RIGHT);
            else if (sc == 0x48) push(KEY_UP);
            else if (sc == 0x50) push(KEY_DOWN);
            else if (sc == 0x1C) push('\n');
        }
        return;
    }

    if (sc == 0x3C) { push(KEY_F2); return; }
    if (sc == 0x3D) { push(KEY_F3); return; }
    if (sc == 0x3F) { push(KEY_F5); return; }
    if (sc == 0x1D) { ctrl = 1; return; }
    if (sc == 0x9D) { ctrl = 0; return; }
    if (sc == 0x2A || sc == 0x36) { shift = 1; return; }
    if (sc == 0xAA || sc == 0xB6) { shift = 0; return; }
    if (sc & 0x80) return;

    char c = shift ? smap[sc & 0x7F] : kmap[sc & 0x7F];
    if (c) push((unsigned short)(unsigned char)c);
}

int kbd_getkey(void)
{
    if (tail == head) return -1;
    int c = buf[tail];
    tail = (tail + 1) % BUFSZ;
    return c;
}

int kbd_ctrl_down(void) { return ctrl; }

void kbd_init(void)
{
    /* 打开键盘接口并允许 IRQ1 */
    for (int i = 0; i < 10000; i++) if (!(inb(0x64) & 2)) break;
    __asm__ volatile("outb %0, %1" :: "a"((unsigned char)0xAE), "Nd"((unsigned short)0x64));

    for (int i = 0; i < 10000; i++) if (!(inb(0x64) & 2)) break;
    __asm__ volatile("outb %0, %1" :: "a"((unsigned char)0x20), "Nd"((unsigned short)0x64));
    for (int i = 0; i < 10000; i++) if (inb(0x64) & 1) break;
    unsigned char cfg = inb(0x60);
    cfg |= 0x01;                  /* IRQ1 */
    cfg &= (unsigned char)~0x10;  /* 键盘时钟使能 */
    for (int i = 0; i < 10000; i++) if (!(inb(0x64) & 2)) break;
    __asm__ volatile("outb %0, %1" :: "a"((unsigned char)0x60), "Nd"((unsigned short)0x64));
    for (int i = 0; i < 10000; i++) if (!(inb(0x64) & 2)) break;
    __asm__ volatile("outb %0, %1" :: "a"(cfg), "Nd"((unsigned short)0x60));
}
