#ifndef FURMAX_UPDATE_H
#define FURMAX_UPDATE_H
/* 离线更新包状态（P1：只检测与校验，不写盘） */
int  update_check(void);
int  update_state(void);          /* 0=无包 1=有效 2=无效 */
unsigned int update_version(void);
const char *update_message(void);
void update_selftest(void);
#endif
