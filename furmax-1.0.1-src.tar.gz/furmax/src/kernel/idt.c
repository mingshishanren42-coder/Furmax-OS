/* Furmax OS：IDT、8259A 中断控制器、PIT 定时器
 * 说明：固件退出后中断经 8259 送达（不是 IOAPIC），因此统一走 PIC + PIC EOI。 */
#include "idt.h"
#include "klog.h"
#include "kbd.h"
#include "usermode.h"
#include "sched.h"
#include "../boot/ps2.h"

extern void *isr_stub_table[256];
extern void wm_show_fault(int vec, unsigned long long err, unsigned long long rip, const char *task);
extern void irq_dispatch(unsigned long long vec, unsigned long long *frame);

typedef struct {
    unsigned short off_lo;
    unsigned short sel;
    unsigned char  ist;
    unsigned char  type;
    unsigned short off_mid;
    unsigned int   off_hi;
    unsigned int   zero;
} __attribute__((packed)) IdtGate;

typedef struct {
    unsigned short limit;
    unsigned long long base;
} __attribute__((packed)) Idtr;

static IdtGate idt[256];
static unsigned short kernel_cs;
volatile unsigned long long kernel_ticks;
static const unsigned long long tick_hz = 100;

static inline void outb(unsigned short p, unsigned char v)
{
    __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(p));
}
static inline unsigned char inb(unsigned short p)
{
    unsigned char v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v;
}

void irq_dispatch(unsigned long long vec, unsigned long long *frame)
{
    (void)frame;
    if (vec == 0x80) { um_syscall(frame); return; }

    if (vec < 32) {                          /* CPU 异常 */
        unsigned long long err = frame[16];
        unsigned long long rip = frame[17];
        unsigned long long cs  = frame[18];
        klog("[fault] vec=");
        klog_dec((long long)vec);
        klog(" err=");
        klog_dec((long long)err);
        klog(" rip=");
        klog_dec((long long)(rip >> 32));
        klog(":");
        klog_dec((long long)(rip & 0xFFFFFFFF));
        klog("\r\n");

        wm_show_fault((int)vec, err, rip, sched_name(sched_current()));

        if ((cs & 3) == 3 && sched_alive()) {   /* 用户态出错：结束该任务，系统继续 */
            klog("[fault] killing user task\r\n");
            sched_on_exit(frame);
            return;
        }
        klog("[fault] kernel fault, halted\r\n");
        for (;;) __asm__ volatile("cli; hlt");
    }

    if (vec == 32) {
        kernel_ticks++;                     /* PIT */
        sched_tick(frame);
    }
    /* 键盘/鼠标由主循环统一排空，中断只做 EOI，避免同一字节被读两次 */

    if (vec >= 40) outb(0xA0, 0x20);        /* 从片 EOI */
    outb(0x20, 0x20);                       /* 主片 EOI */
}

static void idt_set_type(int vec, void *fn, unsigned char type)
{
    unsigned long long a = (unsigned long long)fn;
    idt[vec].off_lo  = (unsigned short)(a & 0xFFFF);
    idt[vec].sel     = kernel_cs;
    idt[vec].ist     = 0;
    idt[vec].type    = type;
    idt[vec].off_mid = (unsigned short)((a >> 16) & 0xFFFF);
    idt[vec].off_hi  = (unsigned int)((a >> 32) & 0xFFFFFFFF);
    idt[vec].zero    = 0;
}

static void idt_set(int vec, void *fn)
{
    idt_set_type(vec, fn, 0x8E);
}

static void pic_remap(void)
{
    outb(0x20, 0x11); outb(0xA0, 0x11);
    outb(0x21, 0x20); outb(0xA1, 0x28);
    outb(0x21, 0x04); outb(0xA1, 0x02);
    outb(0x21, 0x01); outb(0xA1, 0x01);

    outb(0x21, 0xF8);   /* 放行 IRQ0 定时器 / IRQ1 键盘 / IRQ2 级联 */
    outb(0xA1, 0xEF);   /* 放行 IRQ12 鼠标 */
    (void)inb(0x21);
}

static void pit_init(void)
{
    unsigned div = (unsigned)(1193182 / tick_hz);
    outb(0x43, 0x36);
    outb(0x40, (unsigned char)(div & 0xFF));
    outb(0x40, (unsigned char)((div >> 8) & 0xFF));
}

void kernel_init_interrupts(void)
{
    __asm__ volatile("mov %%cs, %0" : "=r"(kernel_cs));
    for (int i = 0; i < 256; i++) idt_set(i, isr_stub_table[i]);
    idt_set_type(0x80, isr_stub_table[0x80], 0xEE);   /* 系统调用门：DPL3 */

    Idtr r = { (unsigned short)(sizeof(idt) - 1), (unsigned long long)idt };
    __asm__ volatile("lidt %0" :: "m"(r));

    pic_remap();
    pit_init();
    kernel_ticks = 0;

    __asm__ volatile("sti");
}

void kernel_wait_ticks(unsigned long long n)
{
    unsigned long long end = kernel_ticks + n;
    while (kernel_ticks < end) __asm__ volatile("pause");
}

unsigned long long kernel_uptime_ms(void)
{
    return kernel_ticks * 1000 / tick_hz;
}
