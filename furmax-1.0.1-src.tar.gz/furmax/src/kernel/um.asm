; Furmax OS 用户态进入/退出
bits 64
section .text

global um_enter
global um_resume
global um_exit_stub

; void um_enter(u64 rip, u64 rsp)
um_enter:
    push rbx
    push rbp
    push r12
    push r13
    push r14
    push r15
    mov [rel saved_rsp], rsp

    push qword 0x23        ; SS (user data)
    push rsi               ; RSP
    push qword 0x202       ; RFLAGS (IF=1)
    push qword 0x1B        ; CS (user code)
    push rdi               ; RIP
    iretq

; void um_resume(u64 *frame)  frame[0..14]=r15..rax, [17]=rip,[19]=rflags,[20]=rsp
um_resume:
    push rbx
    push rbp
    push r12
    push r13
    push r14
    push r15
    mov [rel saved_rsp], rsp

    mov rbx, rdi
    push qword 0x23
    push qword [rbx + 160]
    push qword [rbx + 152]
    push qword 0x1B
    push qword [rbx + 136]

    mov r15, [rbx + 0]
    mov r14, [rbx + 8]
    mov r13, [rbx + 16]
    mov r12, [rbx + 24]
    mov r11, [rbx + 32]
    mov r10, [rbx + 40]
    mov r9,  [rbx + 48]
    mov r8,  [rbx + 56]
    mov rsi, [rbx + 72]
    mov rbp, [rbx + 80]
    mov rdx, [rbx + 96]
    mov rcx, [rbx + 104]
    mov rax, [rbx + 112]
    mov rdi, [rbx + 64]
    mov rbx, [rbx + 88]
    iretq

; 用户程序 exit 后回到这里（内核态）
um_exit_stub:
    mov rsp, [rel saved_rsp]
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbp
    pop rbx
    ret

section .data
saved_rsp: dq 0
