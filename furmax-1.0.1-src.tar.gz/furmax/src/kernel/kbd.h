#ifndef FURMAX_KBD_H
#define FURMAX_KBD_H

void kbd_init(void);
void kbd_irq(void);          /* IRQ1 由中断分发调用 */
int  kbd_getkey(void);       /* 无按键返回 -1；ASCII 或特殊键码 */
void kbd_feed(unsigned char scancode);
int  kbd_ctrl_down(void);

/* 特殊键：高于 0xFF 的值 */
#define KEY_LEFT   0x101
#define KEY_RIGHT  0x102
#define KEY_UP     0x103
#define KEY_DOWN   0x104
#define KEY_ESC    0x1B
#define KEY_F2     0x105
#define KEY_F3     0x106
#define KEY_F5     0x108
#define KEY_CTRL   0x200   /* 修饰位：入队时随按键记录 */

#endif
