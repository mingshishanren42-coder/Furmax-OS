#ifndef FURMAX_IDT_H
#define FURMAX_IDT_H

extern volatile unsigned long long kernel_ticks;

void kernel_init_interrupts(void);
void kernel_wait_ticks(unsigned long long n);
unsigned long long kernel_uptime_ms(void);

#endif
