/* Furmax OS：离线更新包检测（FXU1，P1 阶段只校验不写盘） */
#include "update.h"
#include "fms64.h"
#include "sha256.h"
#include "kmem.h"
#include "klog.h"

#define MAX_PKG (1024u * 1024u)

static int st;                    /* 0 无包 1 有效 2 无效 */
static unsigned int ver;
static const char *msg = "无更新包";
static unsigned char *buf;

static void hex32(const unsigned char *h, char *out)
{
    const char *d = "0123456789abcdef";
    for (int i = 0; i < 32; i++) {
        out[i * 2] = d[h[i] >> 4];
        out[i * 2 + 1] = d[h[i] & 15];
    }
    out[64] = 0;
}

void update_selftest(void)
{
    unsigned char h[32];
    char out[65];
    sha256("abc", 3, h);
    hex32(h, out);
    klog("[sha] abc=");
    klog(out);
    klog("\r\n");
}

int update_check(void)
{
    st = 0;
    msg = "无更新包";

    unsigned int sz = 0;
    unsigned int got = 0;
    if (!buf) buf = (unsigned char *)kmem_alloc(MAX_PKG);
    if (!buf) { st = 2; msg = "内存不足"; return -1; }

    if (fms_read("/UPDATE.PKG", buf, MAX_PKG, &sz) != 0) return 0;   /* 不存在 */
    if (sz < 56 || buf[0] != 'F' || buf[1] != 'X' || buf[2] != 'U' || buf[3] != '1') {
        st = 2; msg = "包头不合法 (FXU1)"; return -1;
    }

    unsigned int len = (unsigned int)buf[12] | ((unsigned int)buf[13] << 8) |
                       ((unsigned int)buf[14] << 16) | ((unsigned int)buf[15] << 24);
    ver = (unsigned int)buf[4] | ((unsigned int)buf[5] << 8) |
          ((unsigned int)buf[6] << 16) | ((unsigned int)buf[7] << 24);

    if (len == 0 || len > MAX_PKG - 56 || sz < 56 + len) { st = 2; msg = "载荷长度非法"; return -1; }
    (void)got;

    unsigned char h[32];
    sha256(buf + 56, len, h);
    for (int i = 0; i < 32; i++) {
        if (h[i] != buf[16 + i]) { st = 2; msg = "SHA-256 校验失败"; return -1; }
    }

    st = 1;
    msg = "更新包有效（P1 仅校验，不写盘）";
    return 0;
}

int update_state(void) { return st; }
unsigned int update_version(void) { return ver; }
const char *update_message(void) { return msg; }
