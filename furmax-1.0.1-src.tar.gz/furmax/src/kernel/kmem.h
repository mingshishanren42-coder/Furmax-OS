#ifndef FURMAX_KMEM_H
#define FURMAX_KMEM_H

#include "../boot/efi.h"

/* 用 UEFI 内存映射建立内核物理页堆（EfiConventionalMemory） */
void kmem_init(void *map, UINTN map_size, UINTN desc_size);
unsigned long long kmem_free_bytes(void);
unsigned long long kmem_heap_bytes(void);
void *kmem_alloc(unsigned long long bytes);   /* 4KB 对齐，可分块回收 */
void kmem_free(void *ptr);
unsigned long long kmem_heap_used(void);
unsigned long long kmem_heap_free(void);
unsigned long long kmem_heap_start(void);

#endif
