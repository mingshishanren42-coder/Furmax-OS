#ifndef FURMAX_USERMODE_H
#define FURMAX_USERMODE_H

void um_syscall(unsigned long long *frame);


int  um_exited(void);

#endif
