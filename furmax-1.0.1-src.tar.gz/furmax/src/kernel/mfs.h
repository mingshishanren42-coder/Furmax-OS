#ifndef FURMAX_MFS_H
#define FURMAX_MFS_H

#define MFS_NAME_MAX 48

typedef struct {
    char name[MFS_NAME_MAX];
    unsigned int size;
} MfsEntry;

void mfs_init(void);
int  mfs_create(const char *name);                                  /* 0 成功 */
int  mfs_write(const char *name, const void *data, unsigned int len, int append);
int  mfs_read(const char *name, void *buf, unsigned int max, unsigned int *out_size);
int  mfs_remove(const char *name);
int  mfs_truncate(const char *name, unsigned int new_size);
int  mfs_list(MfsEntry *out, int max);
unsigned long long mfs_used_bytes(void);
int  mfs_count(void);

#endif
