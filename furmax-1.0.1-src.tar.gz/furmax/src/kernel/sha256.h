#ifndef FURMAX_SHA256_H
#define FURMAX_SHA256_H
void sha256(const void *data, unsigned int len, unsigned char out[32]);
#endif
