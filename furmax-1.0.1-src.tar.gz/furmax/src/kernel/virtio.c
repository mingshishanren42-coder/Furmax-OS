/* Furmax OS virtio-blk 驱动（legacy PCI，轮询模式） */
#include "virtio.h"
#include "kmem.h"
#include "klog.h"

typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;
typedef unsigned long long u64;

static u16 io_base;
static int ready;
static u32 qsize;

typedef struct { u64 addr; u32 len; u16 flags; u16 next; } Desc;
typedef struct { u16 flags; u16 idx; u16 ring[256]; u16 used_event; } Avail;
typedef struct { u16 flags; u16 idx; struct { u32 id; u32 len; } ring[256]; u16 avail_event; } Used;
typedef struct { u32 type; u32 reserved; u64 sector; } ReqHdr;

static Desc *desc;
static Avail *avail;
static Used *used;
static ReqHdr hdr;
static u8 status;
static unsigned char *data_buf;
static u16 last_used;

static inline void outb(u16 p, u8 v) { __asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p)); }
static inline u8 inb(u16 p) { u8 v; __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p)); return v; }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0,%1"::"a"(v),"Nd"(p)); }
static inline u16 inw(u16 p) { u16 v; __asm__ volatile("inw %1,%0":"=a"(v):"Nd"(p)); return v; }
static inline void outl(u16 p, u32 v) { __asm__ volatile("outl %0,%1"::"a"(v),"Nd"(p)); }
static inline u32 inl(u16 p) { u32 v; __asm__ volatile("inl %1,%0":"=a"(v):"Nd"(p)); return v; }

static u32 pci_read(u8 bus, u8 dev, u8 fn, u8 off)
{
    u32 addr = 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) |
               ((u32)fn << 8) | (off & 0xFC);
    outl(0xCF8, addr);
    return inl(0xCFC);
}

static int find_virtio(void)
{
    for (int bus = 0; bus < 8; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            u32 id = pci_read((u8)bus, (u8)dev, 0, 0);
            if ((id & 0xFFFF) != 0x1AF4) continue;
            u16 devid = (u16)(id >> 16);
            if (devid != 0x1001 && devid != 0x1042) continue;
            u32 bar0 = pci_read((u8)bus, (u8)dev, 0, 0x10);
            if (!(bar0 & 1)) continue;
            io_base = (u16)(bar0 & 0xFFFC);

            u32 cmd = pci_read((u8)bus, (u8)dev, 0, 0x04);
            cmd |= 0x5;
            outl(0xCF8, 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | 0x04);
            outl(0xCFC, cmd);
            return 1;
        }
    }
    return 0;
}

int vio_init(void)
{
    if (!find_virtio()) { klog("[virtio] device not found\r\n"); return 0; }

    outb(io_base + 0x12, 0);
    outb(io_base + 0x12, 1);
    outb(io_base + 0x12, 3);

    (void)inl(io_base + 0x00);
    outl(io_base + 0x04, 0);

    outw(io_base + 0x0E, 0);
    qsize = inw(io_base + 0x0C);
    if (qsize == 0 || qsize > 256) { klog("[virtio] bad queue\r\n"); return 0; }

    unsigned char *page = (unsigned char *)kmem_alloc(12288);
    if (!page) return 0;
    for (int i = 0; i < 12288; i++) page[i] = 0;

    desc  = (Desc *)page;                 /* 16 * 256 = 4096 */
    avail = (Avail *)(page + 4096);       /* 紧随描述符表 */
    used  = (Used *)(page + 8192);        /* 必须 4KB 对齐 */

    data_buf = (unsigned char *)kmem_alloc(512);
    if (!data_buf) return 0;

    outl(io_base + 0x08, (u32)((u64)page >> 12));
    outb(io_base + 0x12, 7);
    ready = 1;
    last_used = 0;

    klog("[virtio] blk ready, queue=");
    klog_dec(qsize);
    klog("\r\n");
    return 1;
}

static int submit(int write, u64 sector, const void *src, void *dst)
{
    if (!ready) return -1;

    hdr.type = write ? 1u : 0u;
    hdr.reserved = 0;
    hdr.sector = sector;
    status = 0xFF;

    if (write) {
        const unsigned char *s = (const unsigned char *)src;
        for (int i = 0; i < 512; i++) data_buf[i] = s[i];
    }

    desc[0].addr = (u64)&hdr;
    desc[0].len = sizeof(hdr);
    desc[0].flags = 1;
    desc[0].next = 1;

    desc[1].addr = (u64)data_buf;
    desc[1].len = 512;
    desc[1].flags = (u16)(1 | (write ? 0 : 2));
    desc[1].next = 2;

    desc[2].addr = (u64)&status;
    desc[2].len = 1;
    desc[2].flags = 2;
    desc[2].next = 0;

    u16 start = used->idx;          /* 必须在提交前记录 */

    avail->ring[avail->idx % qsize] = 0;
    avail->idx++;

    __asm__ volatile("mfence" ::: "memory");
    outw(io_base + 0x10, 0);

    for (long spin = 0; spin < 20000000; spin++) {
        __asm__ volatile("mfence" ::: "memory");
        if (used->idx != start) break;
        __asm__ volatile("pause");
    }
    if (used->idx == start) { klog("[virtio] timeout\r\n"); return -1; }
    if (status != 0) return -1;

    if (!write && dst) {
        unsigned char *d = (unsigned char *)dst;
        for (int i = 0; i < 512; i++) d[i] = data_buf[i];
    }
    return 0;
}

int vio_read(u64 lba, void *buf, int count)
{
    unsigned char *p = (unsigned char *)buf;
    for (int i = 0; i < count; i++)
        if (submit(0, lba + (u64)i, 0, p + i * 512) != 0) return -1;
    return 0;
}

int vio_write(u64 lba, const void *buf, int count)
{
    const unsigned char *p = (const unsigned char *)buf;
    for (int i = 0; i < count; i++)
        if (submit(1, lba + (u64)i, p + i * 512, 0) != 0) return -1;
    return 0;
}

unsigned long long vio_capacity(void)
{
    if (!ready) return 0;
    u32 lo = inl(io_base + 0x14);
    u32 hi = inl(io_base + 0x18);
    return ((u64)hi << 32) | lo;
}
