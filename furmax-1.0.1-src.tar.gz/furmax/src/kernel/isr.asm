; Furmax OS 中断入口桩（x86-64）
; 调用约定：C 侧用 SysV，参数放 RDI

bits 64
section .text

extern irq_dispatch

global isr_stub_table

; 每个桩：压入错误码占位和向量号，跳到公共路径
%macro ISR_NOERR 1
global isr%1
isr%1:
    push qword 0
    push qword %1
    jmp isr_common
%endmacro

%macro ISR_ERR 1
global isr%1
isr%1:
    push qword %1
    jmp isr_common
%endmacro

%assign v 0
%rep 256
  %if v == 8 || v == 10 || v == 11 || v == 12 || v == 13 || v == 14 || v == 17 || v == 21 || v == 29 || v == 30
    ISR_ERR v
  %else
    ISR_NOERR v
  %endif
%assign v v+1
%endrep

isr_common:
    push rax
    push rcx
    push rdx
    push rbx
    push rbp
    push rsi
    push rdi
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rbx, rsp            ; 保存现场栈指针（rbx 已保存）
    mov rdi, [rbx + 120]    ; 向量号：15 个寄存器之后
    mov rsi, rbx            ; 寄存器帧指针（第 2 个参数）
    and rsp, -16
    call irq_dispatch
    mov rsp, rbx

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rdi
    pop rsi
    pop rbp
    pop rbx
    pop rdx
    pop rcx
    pop rax
    add rsp, 16             ; 丢弃向量号与错误码
    iretq

section .data
global isr_stub_table
isr_stub_table:
%assign v 0
%rep 256
    dq isr%+v
%assign v v+1
%endrep
