#ifndef FURMAX_PAGING_H
#define FURMAX_PAGING_H

/* 建立内核自己的页表：0..4GB 恒等映射为可读写（2MB 大页） */
void paging_init(void);
unsigned long long *paging_pd0(void);

#endif
