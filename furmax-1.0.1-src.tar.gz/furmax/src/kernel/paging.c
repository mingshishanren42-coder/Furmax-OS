/* Furmax OS 分页：退出固件后自建页表，恒等映射 0..4GB
 * 目的：固件留下的页表对某些内存区域加了保护，内核需要完全可控的映射。 */
#include "paging.h"
#include "klog.h"

typedef unsigned long long u64;

static u64 pml4[512] __attribute__((aligned(4096)));
static u64 pdpt[512] __attribute__((aligned(4096)));
static u64 pd[4][512] __attribute__((aligned(4096)));

#define P_PRESENT  (1ULL << 0)
#define P_RW       (1ULL << 1)
#define P_PS       (1ULL << 7)   /* 2MB 页 */

unsigned long long *paging_pd0(void) { return pd[0]; }

void paging_init(void)
{
    for (int i = 0; i < 512; i++) { pml4[i] = 0; pdpt[i] = 0; }

    pml4[0] = (u64)pdpt | P_PRESENT | P_RW | 4;   /* 4 = U/S，允许用户态访问 */

    for (int g = 0; g < 4; g++) {
        pdpt[g] = (u64)pd[g] | P_PRESENT | P_RW | 4;
        for (int j = 0; j < 512; j++) {
            u64 phys = ((u64)g << 30) | ((u64)j << 21);
            pd[g][j] = phys | P_PRESENT | P_RW | P_PS;
        }
    }

    /* 确保 PSE 已开启（单独一条，避免寄存器冲突），然后换页表 */
    __asm__ volatile(
        "mov %%cr4, %%rax\n"
        "or  $0x10, %%rax\n"
        "mov %%rax, %%cr4\n"
        ::: "rax", "memory");

    u64 cr3 = (u64)pml4;
    __asm__ volatile("mov %0, %%cr3" :: "r"(cr3) : "memory");

    {
        u64 a = 0xde54180ULL;
        u64 *t1 = (u64 *)pml4;
        u64 *t2 = (u64 *)(t1[0] & ~0xFFFULL);
        u64 *t3 = (u64 *)(t2[(a >> 30) & 511] & ~0xFFFULL);
        u64 e1 = t1[0], e2 = t2[(a >> 30) & 511], e3 = t3[(a >> 21) & 511];
        klog("[paging] walk: ");
        klog_hex(e1); klog(" / "); klog_hex(e2); klog(" / "); klog_hex(e3);
        klog("\r\n");
    }

    klog("[paging] identity map 0..4GB, cr3=");
    klog_hex((unsigned long long)pml4);
    klog("\r\n");
}
