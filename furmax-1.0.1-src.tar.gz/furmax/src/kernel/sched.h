#ifndef FURMAX_SCHED_H
#define FURMAX_SCHED_H

typedef unsigned long long u64;

int  sched_spawn(const char *name);
int  sched_spawn_args(const char *name, const char *args);
const char *sched_args(int slot);   /* 加载 .fx 到空闲槽位 */
void sched_run_slice(unsigned int ms); /* 运行任务一小段时间后交还内核 */
void sched_tick(u64 *frame);          /* 定时器中断里做时间片切换 */
void sched_on_exit(u64 *frame);       /* exit 系统调用：切到下一个或回内核 */
int  sched_alive(void);
int  sched_count(void);
void sched_write_out(const char *buf, unsigned int len);
const char *sched_output(int slot);
const char *sched_name(int slot);
int  sched_used(int slot);
int  sched_running(int slot);
int  sched_kill(int slot);
int  sched_current(void);
int  sched_out_len(int slot);
unsigned long long sched_user_base(void);

/* 应用窗口绘制指令 */
typedef struct {
    int type;          /* 1 文字 2 矩形 */
    int x, y, w, h;
    unsigned int color;
    char text[40];
} UiOp;

void ui_clear(int slot);
void ui_text(int slot, int x, int y, unsigned int color, const char *text);
void ui_rect(int slot, int x, int y, int w, int h, unsigned int color);
const UiOp *ui_ops(int slot, int *count);

void ui_image(int slot, int x, int y, int w, int h, const void *pixels);
const unsigned char *ui_image_data(int slot, int *w, int *h);

typedef struct { int type; int x; int y; int key; } UiEvent;
void ui_push_event(int slot, int type, int x, int y, int key);
int  ui_pop_event(int slot, UiEvent *out);

#endif
