#include "fsops.h"
#include "mfs.h"
#include "fms64.h"

static int disk_ready;

void fs_set_disk_ready(int ready) { disk_ready = ready; }
int fs_disk_ready(void) { return disk_ready; }
unsigned int fs_free_blocks(void) { return disk_ready ? fms_free_blocks() : 0; }

void fs_persist_write(const char *name, const void *data, unsigned int len)
{
    if (!disk_ready) return;
    fms_write(name, data, len);
}

void fs_persist_remove(const char *name)
{
    if (!disk_ready) return;
    fms_remove(name);
}
