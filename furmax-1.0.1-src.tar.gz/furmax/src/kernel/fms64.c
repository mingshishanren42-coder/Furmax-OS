/* Furmax OS FMS64 文件系统（v0）
 * 布局：扇区0 超级块 | 位图 | inode 表 | 数据区
 * 每个文件占一段连续数据块。 */
#include "fms64.h"
#include "ata.h"
#include "virtio.h"
#include "klog.h"
#include "kmem.h"

#define BLOCK 512
#define MAX_INODES 64
#define BITMAP_MAX 16384        /* 支持最多 131072 块（64MB） */

typedef struct {
    char magic[8];
    unsigned int block_size;
    unsigned int total_blocks;
    unsigned int bitmap_start;
    unsigned int bitmap_blocks;
    unsigned int inode_start;
    unsigned int inode_blocks;
    unsigned int data_start;
    unsigned int inode_count;
    unsigned int root_inode;
} Super;

#define INODE_NAME_MAX 40

typedef struct {
    unsigned int type;          /* 0 空闲 1 文件 2 目录 */
    unsigned int size;
    unsigned int first_block;
    unsigned int blocks;
    char name[INODE_NAME_MAX];
    unsigned int parent;        /* 父目录 inode 号（根为 0） */
    unsigned int owner;         /* 0=系统，N=任务槽位+1 */
} Inode;

/* 目录项：32 字节 */
typedef struct {
    unsigned int ino;           /* 0 表示空槽 */
    char name[28];
} DirEnt;

static int find_by_path(const char *path, int create);
static int dir_find_child(int dir_ino, const char *name);
static int dir_add_child(int dir_ino, int child_ino, const char *leaf);

static Super sb;
static unsigned char *bitmap;
static Inode *inodes;
static int mounted;
static void *provided_bitmap, *provided_inodes;
static int drive = 0;
static int use_virtio;

static int same_name(const char *a, const char *b)
{
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'a' && ca <= 'z') ca -= 32;
        if (cb >= 'a' && cb <= 'z') cb -= 32;
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}

static void copy_name(char *dst, const char *src)
{
    int i = 0;
    for (; src[i] && i < FMS_NAME_MAX - 1; i++) dst[i] = src[i];
    dst[i] = 0;
}

void fms_set_driver(int virtio) { use_virtio = virtio; }

static int blk_read(unsigned long long lba, void *buf, int count)
{
    if (use_virtio) return vio_read(lba, buf, count);
    return ata_read(drive, (unsigned int)lba, buf, count);
}

static int blk_write(unsigned long long lba, const void *buf, int count)
{
    if (use_virtio) return vio_write(lba, buf, count);
    return ata_write(drive, (unsigned int)lba, buf, count);
}

void fms_set_buffers(void *bmp, void *ino)
{
    provided_bitmap = bmp;
    provided_inodes = ino;
}

int fms_mount(void)
{
    klog("[fms64] mount: read super\r\n");
    if (blk_read(0, &sb, 1) != 0) {
        klog("[fms64] superblock read failed\r\n");
        return 0;
    }
    if (sb.magic[0] != 'F' || sb.magic[1] != 'M' || sb.magic[2] != 'S' ||
        sb.magic[3] != '6' || sb.magic[4] != '4') {
        klog("[fms64] bad magic\r\n");
        return 0;
    }

    if (sb.bitmap_blocks > BITMAP_MAX / BLOCK) return 0;

    bitmap = (unsigned char *)provided_bitmap;
    inodes = (Inode *)provided_inodes;
    if (!bitmap || !inodes) {
        klog("[fms64] buffers not set\r\n");
        klog("[fms64] out of memory\r\n");
        return 0;
    }
    klog("[fms64] mount: read bitmap\r\n");
    if (blk_read(sb.bitmap_start, bitmap, (int)sb.bitmap_blocks) != 0) return 0;
    klog("[fms64] mount: read inodes\r\n");
    if (blk_read(sb.inode_start, inodes, (int)sb.inode_blocks) != 0) return 0;
    if (sb.inode_count > MAX_INODES) return 0;

    mounted = 1;
    klog("[fms64] mounted, total blocks=");
    klog_dec(sb.total_blocks);
    klog("\r\n");
    return 1;
}

static int flush_bitmap(void)
{
    return blk_write(sb.bitmap_start, bitmap, (int)sb.bitmap_blocks);
}

static int flush_inodes(void)
{
    return blk_write(sb.inode_start, inodes, (int)sb.inode_blocks);
}

static int flush_inode(int i)
{
    if (i < 0 || i >= MAX_INODES) return -1;
    unsigned long long lba = sb.inode_start + (unsigned long long)(i * 64) / BLOCK;
    unsigned int off = (unsigned int)((i * 64) % BLOCK);
    unsigned char blk[BLOCK];
    if (blk_read(lba, blk, 1) != 0) return -1;
    for (unsigned int k = 0; k < 64; k++) blk[off + k] = ((unsigned char *)&inodes[i])[k];
    return blk_write(lba, blk, 1);
}

static int block_used(unsigned int b);
static void set_block(unsigned int b, int used);

static int alloc_block(void)
{
    for (unsigned int b = sb.data_start; b < sb.total_blocks; b++) {
        if (block_used(b)) continue;
        set_block(b, 1);
        return (int)b;
    }
    return -1;
}

static int alloc_inode(int type, const char *name)
{
    for (int i = 0; i < MAX_INODES; i++) {
        if (inodes[i].type != 0) continue;
        inodes[i].type = (unsigned int)type;
        inodes[i].size = 0;
        inodes[i].first_block = 0;
        inodes[i].blocks = 0;
        inodes[i].parent = 0;
        inodes[i].owner = 0;
        int k = 0;
        for (; name[k] && k < INODE_NAME_MAX - 1; k++) inodes[i].name[k] = name[k];
        inodes[i].name[k] = 0;
        return i;
    }
    return -1;
}

static int block_used(unsigned int b)
{
    return (bitmap[b >> 3] >> (b & 7)) & 1;
}

static void set_block(unsigned int b, int used)
{
    if (used) bitmap[b >> 3] |= (unsigned char)(1u << (b & 7));
    else      bitmap[b >> 3] &= (unsigned char)~(1u << (b & 7));
}

int fms_list(FmsEntry *out, int max)
{
    if (!mounted) return -1;
    int n = 0;
    for (unsigned int i = 0; i < sb.inode_count && n < max; i++) {
        if (inodes[i].type != 1) continue;
        copy_name(out[n].name, inodes[i].name);
        out[n].size = inodes[i].size;
        n++;
    }
    return n;
}

static Inode *find_inode(const char *name)
{
    for (unsigned int i = 0; i < sb.inode_count; i++)
        if (inodes[i].type == 1 && same_name(inodes[i].name, name)) return &inodes[i];
    return 0;
}

int fms_read(const char *name, void *buf, unsigned int max, unsigned int *out_size)
{
    if (!mounted) return -1;
    int fi = find_by_path(name, 0);
    if (fi < 0) return -1;
    Inode *in = &inodes[fi];

    unsigned int n = in->size < max ? in->size : max;
    unsigned int sectors = (n + BLOCK - 1) / BLOCK;
    if (sectors && blk_read(in->first_block, buf, (int)sectors) != 0) return -1;
    if (out_size) *out_size = in->size;
    return 0;
}

static int alloc_run(unsigned int blocks, unsigned int *out_first)
{
    unsigned int run = 0, start = 0;
    for (unsigned int b = sb.data_start; b < sb.total_blocks; b++) {
        if (!block_used(b)) {
            if (run == 0) start = b;
            run++;
            if (run >= blocks) {
                for (unsigned int k = 0; k < blocks; k++) set_block(start + k, 1);
                *out_first = start;
                return 0;
            }
        } else {
            run = 0;
        }
    }
    return -1;
}


/* 拆分 path 为父目录与叶子名（无 '/' 时父目录为空=根） */
static void split_path(const char *path, char *parent, char *leaf)
{
    int last = -1;
    for (int i = 0; path[i]; i++) if (path[i] == '/') last = i;
    int k = 0;
    for (int i = 0; i < last && k < 63; i++) parent[k++] = path[i];
    parent[k] = 0;
    k = 0;
    for (int i = last + 1; path[i] && k < INODE_NAME_MAX - 1; i++) leaf[k++] = path[i];
    leaf[k] = 0;
}

/* 按路径找到文件 inode；不存在返回 -1 */
static int find_by_path(const char *path, int create)
{
    char parent[64], leaf[INODE_NAME_MAX];
    split_path(path, parent, leaf);
    if (!leaf[0]) return -1;

    int pino;
    if (!parent[0]) {
        pino = 0;
    } else {
        pino = fms_lookup(parent);
        if (pino < 0) {
            if (!create) return -1;
            if (fms_mkdir(parent) != 0) return -1;
            pino = fms_lookup(parent);
            if (pino < 0) return -1;
        }
    }

    int ino = dir_find_child(pino, leaf);
    if (ino >= 0) return ino;
    if (!create) return -1;

    ino = alloc_inode(1, leaf);
    if (ino < 0) return -1;
    inodes[ino].parent = (unsigned int)pino;
    flush_inode(ino);
    if (dir_add_child(pino, ino, leaf) != 0) return -1;
    return ino;
}

int fms_write(const char *name, const void *buf, unsigned int size)
{
    if (!mounted || name[0] == 0) return -1;

    int pino_ = find_by_path(name, 1);
    if (pino_ < 0) return -2;
    Inode *in = &inodes[pino_];

    unsigned int need = (size + BLOCK - 1) / BLOCK;
    if (need > in->blocks) {
        /* 简化：重新分配一段连续块，释放旧块 */
        for (unsigned int k = 0; k < in->blocks; k++) set_block(in->first_block + k, 0);
        unsigned int first = 0;
        if (alloc_run(need, &first) != 0) return -3;
        in->first_block = first;
        in->blocks = need;
    }

    klog("[fms64] wr name=");
    klog(name);
    klog(" size=");
    klog_dec(size);
    klog(" need=");
    klog_dec(need);
    klog(" first=");
    klog_dec(in->first_block);
    klog("\r\n");
    if (need && blk_write(in->first_block, buf, (int)need) != 0) return -4;
    in->size = size;

    int fb_ = flush_bitmap();
    int fi_ = flush_inodes();
    klog("[fms64] flush bm=");
    klog_dec(fb_);
    klog(" ino=");
    klog_dec(fi_);
    klog(" bm@");
    klog_dec(sb.bitmap_start);
    klog(" ino@");
    klog_dec(sb.inode_start);
    klog(" blk=");
    klog_dec(in->blocks);
    klog("\r\n");
    if (fb_ != 0) return -5;
    if (fi_ != 0) return -6;
    return 0;
}

int fms_remove(const char *name)
{
    if (!mounted) return -1;
    int fi = find_by_path(name, 0);
    if (fi < 0) return -1;
    Inode *in = &inodes[fi];
    /* 清父目录中的目录项，避免幽灵条目 */
    {
        int pino = (int)in->parent;
        if (pino >= 0 && pino < MAX_INODES && inodes[pino].type == 2) {
            Inode *pd = &inodes[pino];
            unsigned int cnt = pd->size / sizeof(DirEnt);
            for (unsigned int i = 0; i < cnt; i++) {
                unsigned int off = pd->first_block * BLOCK + i * sizeof(DirEnt);
                unsigned char blk[BLOCK];
                if (blk_read(off / BLOCK, blk, 1) != 0) break;
                unsigned int *ino_p = (unsigned int *)(blk + off % BLOCK);
                if (*ino_p == (unsigned int)fi) {
                    *ino_p = 0;
                    blk_write(off / BLOCK, blk, 1);
                    break;
                }
            }
        }
    }

    for (unsigned int k = 0; k < in->blocks; k++) set_block(in->first_block + k, 0);
    in->type = 0;
    in->size = 0;
    in->blocks = 0;
    in->name[0] = 0;
    flush_bitmap();
    flush_inodes();
    return 0;
}

unsigned int fms_free_blocks(void)
{
    unsigned int n = 0;
    for (unsigned int b = sb.data_start; b < sb.total_blocks; b++) if (!block_used(b)) n++;
    return n;
}

/* ---------- v2：真实目录 ---------- */

static int dir_find_child(int dir_ino, const char *name)
{
    if (dir_ino < 0 || dir_ino >= MAX_INODES) return -1;
    Inode *d = &inodes[dir_ino];
    if (d->type != 2 || !d->first_block) return -1;

    unsigned int nentries = d->size / sizeof(DirEnt);
    const DirEnt *e = (const DirEnt *)0;
    (void)e;
    for (unsigned int i = 0; i < nentries; i++) {
        DirEnt ent;
        unsigned int off = d->first_block * BLOCK + i * sizeof(DirEnt);
        unsigned char blk[BLOCK];
        if (blk_read(off / BLOCK, blk, 1) != 0) return -1;
        for (unsigned int k = 0; k < sizeof(DirEnt); k++) ((unsigned char *)&ent)[k] = blk[off % BLOCK + k];
        if (ent.ino && same_name(ent.name, name)) return (int)ent.ino;
    }
    return -1;
}

static int dir_add_child(int dir_ino, int child_ino, const char *leaf)
{
    Inode *d = &inodes[dir_ino];
    unsigned int idx = d->size / sizeof(DirEnt);

    if (d->first_block == 0) {
        unsigned int first = 0;
        if (alloc_run(8, &first) != 0) return -1;   /* 目录预留 8 块 = 128 项 */
        unsigned char zero[BLOCK];
        for (int i = 0; i < BLOCK; i++) zero[i] = 0;
        for (int k = 0; k < 8; k++) blk_write(first + k, zero, 1);
        d->first_block = first;
        d->blocks = 8;
        d->size = 0;
    }

    DirEnt ent;
    ent.ino = (unsigned int)child_ino;
    int k = 0;
    while (leaf[k] && k < 27) { ent.name[k] = leaf[k]; k++; }
    ent.name[k] = 0;

    /* 目录块写满时尝试追加一个**连续**块 */
    if ((idx + 1) * sizeof(DirEnt) > d->blocks * BLOCK) {
        unsigned int next = d->first_block + d->blocks;
        if (next >= sb.total_blocks || block_used(next)) return -1;
        set_block(next, 1);
        unsigned char zero[BLOCK];
        for (int i = 0; i < BLOCK; i++) zero[i] = 0;
        if (blk_write(next, zero, 1) != 0) return -1;
        d->blocks++;
        flush_bitmap();
    }

    unsigned int off = d->first_block * BLOCK + idx * sizeof(DirEnt);
    if (off + sizeof(DirEnt) > (d->first_block + d->blocks) * BLOCK) return -1;
    {
        unsigned char blk[BLOCK];
        unsigned long long lba = off / BLOCK;
        unsigned int boff = off % BLOCK;
        if (blk_read(lba, blk, 1) != 0) return -1;
        for (unsigned int k = 0; k < sizeof(DirEnt); k++) blk[boff + k] = ((unsigned char *)&ent)[k];
        if (blk_write(lba, blk, 1) != 0) return -1;
    }

    d->size += sizeof(DirEnt);
    flush_inode(dir_ino);
    return 0;
}

int fms_lookup(const char *path)
{
    if (!mounted) return -1;
    if (!path || !path[0]) return 0;

    int cur = 0;
    const char *p = path;
    while (*p == '/') p++;

    while (*p) {
        char part[INODE_NAME_MAX];
        int k = 0;
        while (*p && *p != '/' && k < INODE_NAME_MAX - 1) part[k++] = *p++;
        part[k] = 0;
        while (*p == '/') p++;
        if (!part[0]) break;

        if (same_name(part, ".")) continue;
        if (same_name(part, "..")) { cur = (int)inodes[cur].parent; continue; }

        cur = dir_find_child(cur, part);
        if (cur < 0) return -1;
    }
    return cur;
}

int fms_mkdir(const char *path)
{
    if (!mounted) return -1;

    /* 递归创建父目录：a/b/c 会依次建 a、a/b */
    for (int i = 0; path[i]; i++) {
        if (path[i] != '/') continue;
        char sub[64];
        int k = 0;
        for (int j = 0; j < i && k < 63; j++) sub[k++] = path[j];
        sub[k] = 0;
        if (k > 0) fms_mkdir(sub);
    }

    char parent[64], leaf[INODE_NAME_MAX];
    int n = 0, last = -1;
    for (int i = 0; path[i]; i++) { if (path[i] == '/') last = i; }
    int k = 0;
    for (int i = 0; i < last && k < 63; i++) parent[k++] = path[i];
    parent[k] = 0;
    k = 0;
    for (int i = last + 1; path[i] && k < INODE_NAME_MAX - 1; i++) leaf[k++] = path[i];
    leaf[k] = 0;
    if (!leaf[0]) return -1;

    int pino = fms_lookup(parent);
    if (pino < 0) return -1;
    if (inodes[pino].type != 2) return -1;
    if (dir_find_child(pino, leaf) >= 0) return -2;

    int ino = alloc_inode(2, leaf);
    klog("[mkdir] alloc ino=");
    klog_dec(ino);
    klog("\r\n");
    if (ino < 0) return -1;

    inodes[ino].parent = (unsigned int)pino;
    int f_ino = flush_inode(ino);
    int r_child = dir_add_child(pino, ino, leaf);
    int f_bm = flush_bitmap();
    int f_all = flush_inodes();

    klog("[mkdir] child=");
    klog_dec(r_child);
    klog(" f_ino=");
    klog_dec(f_ino);
    klog(" f_bm=");
    klog_dec(f_bm);
    klog(" f_all=");
    klog_dec(f_all);
    klog("\r\n");

    if (r_child != 0) return -1;
    return 0;
}

int fms_readdir(const char *path, FmsEntry *out, int max)
{
    int ino = fms_lookup(path);
    if (ino < 0) return -1;
    Inode *d = &inodes[ino];
    if (d->type != 2) return -1;

    unsigned int n = d->size / sizeof(DirEnt);
    int cnt = 0;
    for (unsigned int i = 0; i < n && cnt < max; i++) {
        DirEnt ent;
        unsigned int off = d->first_block * BLOCK + i * sizeof(DirEnt);
        unsigned char blk[BLOCK];
        if (blk_read(off / BLOCK, blk, 1) != 0) break;
        for (unsigned int k = 0; k < sizeof(DirEnt); k++) ((unsigned char *)&ent)[k] = blk[off % BLOCK + k];
        if (!ent.ino) continue;
        int k = 0;
        while (ent.name[k] && k < FMS_NAME_MAX - 1) { out[cnt].name[k] = ent.name[k]; k++; }
        out[cnt].name[k] = 0;
        out[cnt].size = inodes[ent.ino].size;
        cnt++;
    }
    return cnt;
}

/* 根目录初始化：确保 inode 0 是目录 */
void fms_mkroot(void)
{
    if (!mounted) return;
    if (inodes[0].type != 2) {
        inodes[0].type = 2;
        inodes[0].parent = 0;
        copy_name(inodes[0].name, "");
        flush_inode(0);
    }
}

/* 递归收集所有文件（含目录），路径形如 "A/B/F.TXT" */
static int collect_dir(int dir_ino, const char *prefix, FmsEntry *out, int max, int cnt)
{
    Inode *d = &inodes[dir_ino];
    if (d->type != 2) return cnt;

    unsigned int n = d->size / sizeof(DirEnt);
    for (unsigned int i = 0; i < n && cnt < max; i++) {
        DirEnt ent;
        unsigned int off = d->first_block * BLOCK + i * sizeof(DirEnt);
        unsigned char blk[BLOCK];
        if (blk_read(off / BLOCK, blk, 1) != 0) break;
        for (unsigned int k = 0; k < sizeof(DirEnt); k++) ((unsigned char *)&ent)[k] = blk[off % BLOCK + k];
        if (!ent.ino) continue;

        char path[64];
        int k = 0;
        for (int j = 0; prefix[j] && k < 60; j++) path[k++] = prefix[j];
        if (k) path[k++] = '/';
        for (int j = 0; ent.name[j] && k < 62; j++) path[k++] = ent.name[j];
        path[k] = 0;

        if (inodes[ent.ino].type == 2) {
            cnt = collect_dir((int)ent.ino, path, out, max, cnt);
        } else if (cnt < max) {
            int m = 0;
            while (path[m] && m < FMS_NAME_MAX - 1) { out[cnt].name[m] = path[m]; m++; }
            out[cnt].name[m] = 0;
            out[cnt].size = inodes[ent.ino].size;
            cnt++;
        }
    }
    return cnt;
}

int fms_list_all(FmsEntry *out, int max)
{
    if (!mounted) return -1;
    return collect_dir(0, "", out, max, 0);
}

int fms_rmdir(const char *path)
{
    int ino = fms_lookup(path);
    if (ino <= 0) return -1;
    Inode *d = &inodes[ino];
    if (d->type != 2) return -1;

    unsigned int cnt = d->size / sizeof(DirEnt);
    for (unsigned int i = 0; i < cnt; i++) {
        unsigned int off = d->first_block * BLOCK + i * sizeof(DirEnt);
        unsigned char blk[BLOCK];
        if (blk_read(off / BLOCK, blk, 1) != 0) break;
        unsigned int child = *(unsigned int *)(blk + off % BLOCK);
        if (child) return -2;                 /* 非空目录 */
    }

    int pino = (int)d->parent;
    if (pino >= 0 && inodes[pino].type == 2) {
        Inode *pd = &inodes[pino];
        unsigned int n = pd->size / sizeof(DirEnt);
        for (unsigned int i = 0; i < n; i++) {
            unsigned int off = pd->first_block * BLOCK + i * sizeof(DirEnt);
            unsigned char blk[BLOCK];
            if (blk_read(off / BLOCK, blk, 1) != 0) break;
            unsigned int *ip = (unsigned int *)(blk + off % BLOCK);
            if (*ip == (unsigned int)ino) {
                *ip = 0;
                blk_write(off / BLOCK, blk, 1);
                break;
            }
        }
    }

    for (unsigned int k = 0; k < d->blocks; k++) set_block(d->first_block + k, 0);
    d->type = 0;
    d->size = 0;
    d->blocks = 0;
    d->first_block = 0;
    d->name[0] = 0;
    flush_bitmap();
    flush_inodes();
    return 0;
}

int fms_rename(const char *from, const char *to)
{
    int ino = fms_lookup(from);
    if (ino <= 0) return -1;
    if (fms_lookup(to) >= 0) return -2;

    char parent[64], leaf[INODE_NAME_MAX];
    int last = -1;
    for (int i = 0; to[i]; i++) if (to[i] == '/') last = i;
    int k = 0;
    for (int i = 0; i < last && k < 63; i++) parent[k++] = to[i];
    parent[k] = 0;
    k = 0;
    for (int i = last + 1; to[i] && k < INODE_NAME_MAX - 1; i++) leaf[k++] = to[i];
    leaf[k] = 0;
    if (!leaf[0]) return -1;

    int pino = parent[0] ? fms_lookup(parent) : 0;
    if (pino < 0) return -1;
    if (inodes[pino].type != 2) return -1;

    Inode *in = &inodes[ino];
    int oldparent = (int)in->parent;
    if (oldparent >= 0 && inodes[oldparent].type == 2) {
        Inode *pd = &inodes[oldparent];
        unsigned int n = pd->size / sizeof(DirEnt);
        for (unsigned int i = 0; i < n; i++) {
            unsigned int off = pd->first_block * BLOCK + i * sizeof(DirEnt);
            unsigned char blk[BLOCK];
            if (blk_read(off / BLOCK, blk, 1) != 0) break;
            unsigned int *ip = (unsigned int *)(blk + off % BLOCK);
            if (*ip == (unsigned int)ino) { *ip = 0; blk_write(off / BLOCK, blk, 1); break; }
        }
    }

    copy_name(in->name, leaf);
    in->parent = (unsigned int)pino;
    flush_inode(ino);
    return dir_add_child(pino, ino, leaf);
}

/* 断电一致性：按 inode 重建位图，修复“块被占用但位图丢失/反之”的情况 */
int fms_fsck(void)
{
    if (!mounted) return -1;

    unsigned int repaired = 0;

    for (unsigned int b = 0; b < sb.data_start; b++) set_block(b, 1);

    for (int i = 0; i < MAX_INODES; i++) {
        Inode *in = &inodes[i];
        if (in->type == 0) continue;
        if (!in->first_block || !in->blocks) continue;
        if (in->first_block >= sb.total_blocks) { in->type = 0; repaired++; continue; }
        if (in->first_block + in->blocks > sb.total_blocks) {
            in->blocks = sb.total_blocks - in->first_block;
            repaired++;
        }
        for (unsigned int k = 0; k < in->blocks; k++) {
            unsigned int b = in->first_block + k;
            if (!block_used(b)) { set_block(b, 1); repaired++; }
        }
    }

    if (repaired) {
        flush_bitmap();
        flush_inodes();
        klog("[fsck] repaired=");
        klog_dec(repaired);
        klog("\r\n");
    } else {
        klog("[fsck] clean\r\n");
    }
    return (int)repaired;
}

int fms_get_owner(const char *path)
{
    int ino = fms_lookup(path);
    if (ino < 0) return -1;
    return (int)inodes[ino].owner;
}

int fms_set_owner(const char *path, unsigned int owner)
{
    int ino = fms_lookup(path);
    if (ino < 0) return -1;
    inodes[ino].owner = owner;
    flush_inode(ino);
    return 0;
}
