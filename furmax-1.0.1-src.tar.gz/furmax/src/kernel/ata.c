/* Furmax OS ATA PIO 磁盘驱动（LBA28） */
#include "ata.h"
#include "klog.h"

static inline void outb(unsigned short p, unsigned char v)
{ __asm__ volatile("outb %0, %1" :: "a"(v), "Nd"(p)); }
static inline unsigned char inb(unsigned short p)
{ unsigned char v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outsw(unsigned short p, const void *b, int n)
{ __asm__ volatile("rep outsw" : "+d"(p), "+c"(n) : "S"(b) : "memory"); }
static inline void insw(unsigned short p, void *b, int n)
{ __asm__ volatile("rep insw" : "+d"(p), "+c"(n) : "D"(b) : "memory"); }

#define IO   0x1F0
#define CTL  0x3F6
#define DBIT(d) ((d) ? 0x10 : 0)

static void io_delay(void) { for (int i = 0; i < 4; i++) (void)inb(CTL); }

static int wait_bsy_clear(void)
{
    for (int i = 0; i < 5000000; i++) {
        unsigned char st = inb(IO + 7);
        if (!(st & 0x80)) return 0;
    }
    return -1;
}

static int wait_drq(void)
{
    for (int i = 0; i < 5000000; i++) {
        unsigned char st = inb(IO + 7);
        if (st & 0x80) continue;
        if (st & 0x01) return -1;      /* ERR */
        if (st & 0x08) return 0;       /* DRQ */
    }
    return -2;
}

/* 若设备仍有待取数据（DRQ=1），读掉一个扇区把它清干净 */
static void drain_pending(void)
{
    for (int i = 0; i < 200000; i++) {
        unsigned char st = inb(IO + 7);
        if (st & 0x80) continue;
        if (!(st & 0x08)) return;
        for (int k = 0; k < 256; k++) (void)inb(IO);
        return;
    }
}

/* 若设备还有待取数据，读掉它，直到 DRQ 清零 */
static void drain_drq(void)
{
    for (int k = 0; k < 64; k++) {
        unsigned char st = inb(IO + 7);
        if (st & 0x80) continue;      /* BSY，等下一轮 */
        if (!(st & 0x08)) return;     /* DRQ 清零，完成 */
        for (int i = 0; i < 256; i++) (void)inb(IO);
    }
}

static int select_lba(int drive, unsigned int lba)
{
    outb(IO + 6, (unsigned char)(0xE0 | DBIT(drive) | ((lba >> 24) & 0x0F)));
    io_delay();
    return wait_bsy_clear();
}

int ata_init(int drive)
{
    outb(CTL, 0x00);
    outb(IO + 6, (unsigned char)(0xA0 | DBIT(drive)));
    io_delay();
    if (wait_bsy_clear() != 0) return 0;

    outb(IO + 2, 0);
    outb(IO + 3, 0);
    outb(IO + 4, 0);
    outb(IO + 5, 0);
    outb(IO + 7, 0xEC);
    if (wait_drq() != 0) {
        klog("[ata] drive ");
        klog_dec((long long)drive);
        klog(" not present\r\n");
        return 0;
    }
    for (int i = 0; i < 256; i++) (void)inb(IO);
    return 1;
}

int ata_read(int drive, unsigned int lba, void *buf, int count)
{
    if (count <= 0) return 0;
    if (count > 128) count = 128;

    if (select_lba(drive, lba) != 0) return -1;
    outb(IO + 2, (unsigned char)count);
    outb(IO + 3, (unsigned char)(lba & 0xFF));
    outb(IO + 4, (unsigned char)((lba >> 8) & 0xFF));
    outb(IO + 5, (unsigned char)((lba >> 16) & 0xFF));
    outb(IO + 7, 0x20);
    io_delay();

    if (wait_drq() != 0) return -1;
    insw(IO, buf, count * 256);
    io_delay();
    (void)wait_bsy_clear();
    return 0;
}

int ata_write(int drive, unsigned int lba, const void *buf, int count)
{
    if (count <= 0) return 0;
    if (count > 128) count = 128;

    if (select_lba(drive, lba) != 0) return -1;
    outb(IO + 2, (unsigned char)count);
    outb(IO + 3, (unsigned char)(lba & 0xFF));
    outb(IO + 4, (unsigned char)((lba >> 8) & 0xFF));
    outb(IO + 5, (unsigned char)((lba >> 16) & 0xFF));
    outb(IO + 7, 0x30);
    io_delay();

    if (wait_drq() != 0) return -1;
    outsw(IO, buf, count * 256);
    io_delay();
    (void)wait_bsy_clear();

    outb(IO + 7, 0xE7);
    io_delay();
    (void)wait_bsy_clear();
    return 0;
}
