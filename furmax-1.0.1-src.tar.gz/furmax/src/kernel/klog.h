#ifndef FURMAX_KLOG_H
#define FURMAX_KLOG_H
void klog_init(void);
void klog(const char *s);
void klog_hex(unsigned long long v);
void klog_dec(unsigned long long v);
#endif
