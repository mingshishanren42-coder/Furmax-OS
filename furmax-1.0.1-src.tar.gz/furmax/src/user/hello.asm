; Furmax OS 第一个用户态程序
BITS 64
org 0x400000

start:
    mov rax, 1          ; sys_write
    lea rdi, [rel msg]
    mov rsi, mlen
    int 0x80

    mov rax, 2          ; sys_exit
    int 0x80

    jmp $

msg: db "Hello from ring 3!", 10
mlen equ $ - msg
