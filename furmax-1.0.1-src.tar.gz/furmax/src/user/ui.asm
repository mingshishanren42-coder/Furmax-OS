; Furmax OS 窗口绘制示例：自己画一个界面
BITS 64
org 0x400000

%macro RECT 5
    mov rax, 7
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    mov rcx, %4
    mov r8,  %5
    int 0x80
%endmacro

%macro TXT 4
    mov rax, 6
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    lea rcx, [rel %4]
    int 0x80
%endmacro

start:
    mov rax, 5              ; ui_clear
    mov rdi, 0x101820
    int 0x80

    RECT 0, 0, 600, 44, 0x2A3550
    TXT 16, 14, 0xFFFFFF, title
    TXT 16, 60, 0x8FD0FF, sub

    RECT 16, 92, 250, 90, 0x1E2A3C
    TXT 32, 108, 0xFFD28A, card1
    TXT 32, 136, 0xD0D8E4, card1b

    RECT 286, 92, 250, 90, 0x1E2A3C
    TXT 302, 108, 0x9BE8A8, card2
    TXT 302, 136, 0xD0D8E4, card2b

    mov rax, 2
    int 0x80
    jmp $

title:  db "FURMAX UI DEMO",0
sub:    db "APP DRAWS ITS OWN WINDOW",0
card1:  db "RENDERED BY APP",0
card1b: db "SYSCALL 5 6 7",0
card2:  db "KERNEL COMPOSES",0
card2b: db "OPS QUEUE",0
