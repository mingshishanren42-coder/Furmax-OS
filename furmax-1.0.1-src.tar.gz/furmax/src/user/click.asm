; 轮询输入事件：点击或按键后换一个色块
BITS 64
org 0x400000

%macro RECT 5
    mov rax, 7
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    mov rcx, %4
    mov r8,  %5
    int 0x80
%endmacro

%macro TXT 4
    mov rax, 6
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    lea rcx, [rel %4]
    int 0x80
%endmacro

start:
    mov rax, 5
    mov rdi, 0x0E1626
    int 0x80
    RECT 0, 0, 600, 44, 0x24405C
    TXT 16, 14, 0xFFFFFF, title
    TXT 16, 60, 0x9FB4CC, hint

    RECT 40, 100, 160, 120, 0x3B82F6     ; 初始蓝块
    TXT 40, 240, 0xE2F0FF, idle

.wait:
    mov rax, 8
    lea rdi, [rel ev]
    int 0x80
    cmp rax, 0
    jle .wait

    ; 有事件：把方块换成绿色并提示
    mov rax, 5
    mov rdi, 0x0E1626
    int 0x80
    RECT 0, 0, 600, 44, 0x24405C
    TXT 16, 14, 0xFFFFFF, title
    RECT 40, 100, 160, 120, 0x22C55E
    TXT 40, 240, 0xB9F6D0, done

    mov rax, 2
    int 0x80
    jmp $

title: db "CLICK TEST",0
hint:  db "CLICK INSIDE THIS WINDOW",0
idle:  db "WAITING FOR EVENT",0
done:  db "EVENT RECEIVED",0
ev:    times 4 dd 0
