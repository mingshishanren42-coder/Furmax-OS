; Furmax OS 记事本（用户态）
; 用法：run notepad.fx [文件名]   （默认 NOTE.TXT）
; 编辑输入，F2 保存，ESC 退出
BITS 64
org 0x400000

%macro RECT 5
    mov rax, 7
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    mov rcx, %4
    mov r8,  %5
    int 0x80
%endmacro

%macro TXT 4
    mov rax, 6
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    lea rcx, [rel %4]
    int 0x80
%endmacro

start:
    ; 取命令行参数作为文件名
    mov rax, 10
    lea rdi, [rel namebuf]
    mov rsi, 31
    int 0x80
    cmp rax, 0
    jle .usedefault
    lea r15, [rel namebuf]
    jmp .load

.usedefault:
    lea r15, [rel fname]

.load:
    mov rdi, r15
    lea rsi, [rel buf]
    mov rdx, 100
    mov rax, 3
    int 0x80
    cmp rax, 0
    jl .noload
    mov r12, rax
    lea r13, [rel buf]
    mov byte [r13 + r12], 0
    jmp .loop

.noload:
    xor r12, r12
    lea r13, [rel buf]
    mov byte [r13], 0

.loop:
    mov byte [rel saved], 0
.redraw:
    mov rax, 5
    mov rdi, 0x101A2A
    int 0x80

    RECT 0, 0, 600, 44, 0x2B4A6F
    TXT 16, 14, 0xFFFFFF, title
    ; 显示文件名（参数或默认）
    mov rax, 6
    mov rdi, 16
    mov rsi, 64
    mov rdx, 0x9FD0FF
    mov rcx, r15
    int 0x80

    RECT 16, 96, 560, 60, 0x16233A
    TXT 28, 116, 0xE6EEF8, buf

    TXT 16, 180, 0x8FA8C0, hint
    cmp byte [rel saved], 0
    je .nohint2
    TXT 16, 208, 0x8CE8A8, savedmsg

.nohint2:
    mov rax, 8
    lea rdi, [rel ev]
    int 0x80
    cmp rax, 0
    jle .nohint2

    mov eax, [rel ev]       ; type
    cmp eax, 2
    jne .loop

    mov eax, [rel ev + 12]  ; key
    cmp eax, 0x1B
    je .bye
    cmp eax, 0x105          ; F2
    je .save
    cmp eax, 8
    je .back
    cmp eax, 32
    jl .loop
    cmp r12, 90
    jae .loop
    lea r13, [rel buf]
    mov [r13 + r12], al
    inc r12
    mov byte [r13 + r12], 0
    jmp .redraw

.back:
    test r12, r12
    jz .loop
    dec r12
    lea r13, [rel buf]
    mov byte [r13 + r12], 0
    jmp .redraw

.save:
    mov rdi, r15
    lea rsi, [rel buf]
    mov rdx, r12
    mov rax, 4
    int 0x80
    mov byte [rel saved], 1
    jmp .redraw

.bye:
    mov rax, 2
    int 0x80
    jmp $

fname:    db "NOTE.TXT",0
title:    db "NOTEPAD",0
hint:     db "TYPE TO EDIT   F2 SAVE   ESC EXIT",0
savedmsg: db "SAVED",0
saved:    db 0
ev:       times 4 dd 0
namebuf:  times 32 db 0
buf:      times 128 db 0
