; Furmax OS 第二个用户程序
BITS 64
org 0x400000

start:
    mov rax, 1          ; sys_write
    lea rdi, [rel msg]
    mov rsi, mlen
    int 0x80

    mov rax, 2          ; sys_exit
    int 0x80
    jmp $

msg: db "GREET.FX: second user app", 10
mlen equ $ - msg
