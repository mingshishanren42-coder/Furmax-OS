; 故意触发异常，验证系统故障提示
BITS 64
org 0x400000
start:
    mov rax, 6
    mov rdi, 20
    mov rsi, 20
    mov rdx, 0xFF8080
    lea rcx, [rel msg]
    int 0x80
    mov rax, qword 0x1000      ; 访问内核地址（无用户权限）
    mov rbx, [rax]
    mov rax, 2
    int 0x80
    jmp $
msg: db "ABOUT TO CRASH ON PURPOSE",0
