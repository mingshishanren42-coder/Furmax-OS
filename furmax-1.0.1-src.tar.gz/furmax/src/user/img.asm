; Furmax OS 图像示例：生成 32x32 渐变并通过 ui_image 显示
BITS 64
org 0x400000

start:
    mov rax, 5
    mov rdi, 0x0F1826
    int 0x80

    xor r12, r12              ; y
.yloop:
    xor r13, r13              ; x
.xloop:
    mov rax, r13
    shl rax, 3                ; r = x*8
    mov rbx, r12
    shl rbx, 3                ; g = y*8
    mov rcx, r12
    shl rcx, 2                ; b = y*4

    mov rdx, r12
    shl rdx, 5
    add rdx, r13              ; y*32 + x
    shl rdx, 2                ; *4

    lea rdi, [rel img]
    add rdi, rdx
    mov [rdi], al
    mov [rdi + 1], bl
    mov [rdi + 2], cl
    mov byte [rdi + 3], 0

    inc r13
    cmp r13, 32
    jb .xloop
    inc r12
    cmp r12, 32
    jb .yloop

    mov rax, 6
    mov rdi, 40
    mov rsi, 36
    mov rdx, 0xFFFFFF
    lea rcx, [rel title]
    int 0x80

    mov rax, 9
    mov rdi, 40
    mov rsi, 64
    mov rdx, 32
    mov rcx, 32
    lea r8, [rel img]
    int 0x80

    mov rax, 6
    mov rdi, 40
    mov rsi, 110
    mov rdx, 0x9FD0FF
    lea rcx, [rel sub]
    int 0x80

    mov rax, 2
    int 0x80
    jmp $

title: db "IMAGE VIEWER",0
sub:   db "32X32 GRADIENT VIA UI_IMAGE",0
img:   times 32*32*4 db 0
