; 用系统调用把 SHEET.CVP 复制成 COPY.CVP
BITS 64
org 0x400000

start:
    lea rdi, [rel src]
    lea rsi, [rel buf]
    mov rdx, 2048
    mov rax, 3              ; read_file
    int 0x80
    cmp rax, 0
    jl fail

    mov rdx, rax
    lea rdi, [rel dst]
    lea rsi, [rel buf]
    mov rax, 4              ; write_file
    int 0x80
    cmp rax, 0
    jl fail

    mov rax, 1
    lea rdi, [rel msg_ok]
    mov rsi, oklen
    int 0x80
    jmp done

fail:
    mov rax, 1
    lea rdi, [rel msg_fail]
    mov rsi, faillen
    int 0x80

done:
    mov rax, 2
    int 0x80
    jmp $

src:      db "SHEET.CVP",0
dst:      db "COPY.CVP",0
msg_ok:   db "COPIED SHEET.CVP TO COPY.CVP",10
oklen equ $ - msg_ok
msg_fail: db "COPY FAILED",10
faillen equ $ - msg_fail
buf: times 2048 db 0
