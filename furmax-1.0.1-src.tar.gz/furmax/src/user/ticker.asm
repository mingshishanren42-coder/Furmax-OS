; 持续输出的小程序，用来观察多任务是否交替运行
BITS 64
org 0x400000

start:
    mov r12, 100         ; 输出次数
.loop:
    mov rax, 1           ; sys_write
    lea rdi, [rel msg]
    mov rsi, 1
    int 0x80

    mov rcx, 20000000    ; 忙等，放慢节奏
.delay:
    dec rcx
    jnz .delay

    dec r12
    jnz .loop

    mov rax, 2           ; sys_exit
    int 0x80
    jmp $

msg: db "T"
