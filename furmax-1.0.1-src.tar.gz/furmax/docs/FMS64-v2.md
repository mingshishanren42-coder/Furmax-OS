# FMS64 磁盘格式 v2（目录支持）

> 目标：从「路径化文件名」升级为**真正的目录 inode + 目录项**。
> 影响面：`fms64.c`（内核）、`tools/mkfms64.py`（宿主机镜像工具）、`mfs.c`（内存视图）。
> 兼容性：**破坏性**，旧镜像需迁移（见文末）。

## 1. 布局（不变部分）

```
块 0            超级块（4096B）
块 1..32        位图
块 33..          inode 表（每项 64B）
数据区           4KB 块，按位图分配
```

超级块字段不变，新增 `format_version = 2`（旧镜像为 1 或 0）。

## 2. inode（64 字节，扩容不破坏对齐）

| 偏移 | 大小 | 字段 |
|---|---|---|
| 0 | 4 | type：1=文件，2=目录 |
| 4 | 4 | size（文件：字节数；目录：目录项字节数） |
| 8 | 4 | first_block（首块号） |
| 12 | 4 | blocks（占用块数） |
| 16 | 40 | name（本项名称，**不再含 `/`**） |
| 56 | 4 | parent（父目录 inode 号，根为 0） |
| 60 | 4 | reserved |

## 3. 目录内容（存放于数据区）

目录 inode 的 `first_block` 指向一个或多个数据块，内容是一串定长目录项：

| 偏移 | 大小 | 字段 |
|---|---|---|
| 0 | 4 | child_ino（0 表示空槽） |
| 4 | 28 | child_name |
| 32 | 4 | reserved |

每块 4096 / 32 = **128 个目录项**。`size` 记录有效字节数，删除只把 `child_ino` 置 0（惰性删除）。

## 4. 路径解析

```
lookup(path):
  ino = 0                     # 根目录
  for part in path.split('/'):
      if part == "" or ".": continue
      if part == "..": ino = parent(ino); continue
      ino = dir_find(ino, part)     # 遍历目录块
      if ino == 0: return ENOENT
  return ino
```

- 绝对路径从 inode 0 开始；相对路径从进程 `cwd_ino` 开始。
- 挂载点/符号链接本期不做。

## 5. 关键操作

| 操作 | 语义 |
|---|---|
| `mkdir(path)` | 解析父目录 → 分配 inode(type=2) → 在父目录追加目录项 |
| `unlink(path)` | 从父目录把目录项置空；文件释放块；目录必须为空才能删 |
| `rename(old,new)` | 移动目录项（同一父目录内先实现，跨目录后续） |
| `readdir(ino)` | 顺序返回 child_ino != 0 的项 |

## 6. 迁移（v1 → v2）

旧镜像里文件名形如 `DOC/NOTE.TXT`。迁移脚本按 `/` 拆分：

1. 为每级前缀创建目录 inode（type=2，parent 指向上一级）；
2. 把文件 inode 的 `name` 改为末段名，`parent` 指向对应目录；
3. 生成每个目录的目录块；
4. 超级块 `format_version = 2`。

迁移工具：`tools/migrate_fms64.py`（宿主机运行，读旧镜像写新镜像）。

## 7. 落地顺序（建议）

| 步骤 | 内容 | 风险 |
|---|---|---|
| 1 | `fms64.c` 增加 v2 读写：inode 新字段、目录项块 | 中 |
| 2 | `fms_mkdir / fms_lookup / fms_readdir` | 中 |
| 3 | 终端命令切到 v2 路径解析（`cd/pwd/mkdir/ls` 用 inode） | 低 |
| 4 | 内存 MFS 视图改为「按需从磁盘读目录」或保持路径键（过渡期双写） | 中 |
| 5 | 迁移工具 + 镜像重建 | 低 |
| 6 | 旧路径化代码删除 | 低 |

## 8. 过渡期策略

第 2–4 步完成前，磁盘上可能同时存在：
- v1 风格路径名（`DOC/NOTE.TXT`）
- v2 目录项（目录 `DOC` 下 `NOTE.TXT`）

建议：**只允许 v2 写入**，启动时若检测到 `format_version != 2`，从旧镜像迁移或重建（当前测试镜像可直接重建，无真实用户数据）。

## 9. 当前状态

- [x] 格式设计（本文档）
- [x] 内核 v2 inode 布局（name 40B + parent + pad，仍 64B）
- [x] 目录项结构 DirEnt（32B）与目录数据块
- [x] `fms_lookup` / `fms_mkdir` / `fms_readdir` / `fms_mkroot`
- [x] 宿主机 `mkfms64.py` 同步新布局；启动时确保根目录为目录 inode
- [x] 镜像工具把 inode 0 保留为根目录（内含 README/PROJECTS 目录项）
- [x] 终端 `mkdir`/`ls` 已切到 `fms_mkdir`/`fms_readdir`（内存中验证：创建 DOC、`ls` 显示空目录）
- [x] 目录 inode **落盘通过**：磁盘上可见 `doc`（inode 20）、根目录项增长
  - 根因 1：`blk_write` 第三参数是**扇区数**，v2 代码传了字节数（512 扇区），改成「读一块→改→写一块」
  - 根因 2：路径无 `/` 时 leaf 切分从下标 1 开始，导致 `DOC` 变 `oc`
  - 根因 3：`alloc_inode` / `alloc_block` / `flush_inode` 之前只写了调用没实现，链接失败后一直在跑旧镜像
- [x] `mkdir` 多级路径：**已验证** `mkdir /A/B` → A(22, parent 0)、B(23, parent 22)，`fms_lookup` 两级均命中
- [x] 文件进入目录：`fms_write/read` 按「父目录 + leaf」定位，自动建父目录；已验证 `/T/F.TXT` 写入(inode 26)并读回 "hi"（`fms_write` 按父目录 + leaf 存 inode 并追加目录项）
- [x] 删除文件清理父目录项（幽灵条目）：验证 `afterDelCnt=0`
- [x] 目录预留 8 块（128 项）并按需追加连续块
- [x] `fms_rmdir`（非空拒绝，返回 -2）与 `fms_rename`（同/跨目录）验证通过
- [x] 导入上限 32 → 64（MFS_MAX 与启动导入）
- [ ] 旧路径化层（`.dir` 标记、`dir_list`）待删除
- [x] 启动导入按目录树递归（`fms_list_all`），文件池已显示 `T/F.TXT` 这类带路径的文件
- [ ] 迁移工具（旧镜像可重建，暂不需要）
