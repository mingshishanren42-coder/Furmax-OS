# Furmax OS 磁盘格式化（FMS64）方案

> 状态：**设计定稿**，暂未实现。
> 目标：用户能把一块空白/其它文件系统的磁盘格式化成 FMS64，供系统挂载使用。

---

## 1. 三种场景

| 场景 | 用户想做什么 | 推荐路径 |
|---|---|---|
| A | 在 PC 上准备一块 FMS64 盘（做启动盘/数据盘） | 宿主机工具（现有 `tools/mkfms64.py`） |
| B | 在 Furmax 里格式化第二块盘（U 盘/移动硬盘） | 系统内格式化命令（需多盘支持） |
| C | 首次安装，把整块盘做成系统盘 | 引导期安装/格式化模式 |

---

## 2. 场景 A：宿主机工具（现在就能用）

```sh
python3 tools/mkfms64.py build/furmax-data.img 64   # 64MB
```

- 生成 FMS64 v2：超级块（带 `format_version`）、位图、inode 表、根目录 inode 0（8 个连续块 = 128 目录项）
- 可选：写入示例文件（README / PROJECTS.CVP）
- 用法：把镜像写入 U 盘（`dd`/Rufus），或作为 QEMU 第二块盘挂载

**限制**：只能在 PC 上做，且要小心 `dd` 写错盘。

---

## 3. 场景 C：引导期格式化（推荐正式方案）

在 `BOOTX64.EFI` 里加一个「维护模式」，启动时按住 **F12** 进入：

```
┌─ FURMAX 维护模式 ─────────────┐
│ 1) 格式化磁盘为 FMS64          │
│ 2) 检查磁盘（fsck）            │
│ 3) 退出并正常启动              │
└───────────────────────────────┘
```

选择 1 后列出可用块设备（用 UEFI **Block I/O 协议**枚举，不依赖我们自己的 virtio 驱动）：

```
编号  设备              大小     现有文件系统
0     ATA0: P0          64 MB    FAT32（启动盘）
1     VIRTIO0: P0       64 MB    FMS64
2     USB0: P0         8.0 GB    无法识别
```

选择设备后：

1. 显示警告与设备指纹（大小 + 首扇区哈希前 8 位）；
2. 要求用户**手输设备编号**确认（防误触）；
3. 若是启动盘/数据盘，**禁止**（除非同时输入 `ERASE` 全大写）；
4. 写入 FMS64 v2 结构：
   - 扇区 0：超级块
   - 位图区（按容量计算）
   - inode 表（64 项 × 64B）
   - 根目录 inode 0 + 8 个目录块
5. 回读校验（超级块 magic + 根 inode 类型）；
6. 显示结果并返回菜单。

**为什么用 UEFI Block I/O**：固件已经为所有磁盘提供统一读写接口，格式化工具不必自己写 ATA/USB 驱动，风险最低。

---

## 4. 场景 B：系统内格式化（后续）

需要两项新能力：

1. **多块设备枚举**：当前 virtio 驱动只初始化第一块盘，需要扫描 PCI 找所有 virtio-blk 设备；
2. **块设备抽象层**：`struct blkdev { read, write, capacity, name }`，文件系统挂在某个 blkdev 上，而不是写死“第 0 号盘”。

有了这两项，终端可以加命令：

```
format D:            # D: 是枚举出的第二块盘
fsck D:
mount D: /mnt
```

**安全约束**：

- 系统盘/数据盘不可格式化（设备表里标记 `protected`）
- 必须二次确认：`format D:` → 提示「将清空 8GB 磁盘 USB0，输入 D 确认」
- 格式化在后台任务执行，显示进度（FMS64 写位图 + inode 表很快，主要是清零首几 MB）

---

## 5. FMS64 v2 格式化要做的事（供实现参考）

```
1. 读设备容量 → total_blocks = capacity / 512
2. bitmap_blocks = ceil(total_blocks / (8 * 512))
3. inode_blocks  = ceil(64 * 64 / 512) = 8
4. data_start    = 1 + bitmap_blocks + inode_blocks
5. 写超级块（magic "FMS64", block_size=512, totals,
             bitmap_start=1, bitmap_blocks, inode_start, inode_blocks,
             data_start, inode_count=64, root_inode=0, format_version=2）
6. 位图：标记 0 .. data_start-1 已用，其余空闲
7. inode 0：type=2（目录），first_block=第一个空闲块，blocks=8，size=0，parent=0
8. 分配 8 个连续块作为根目录块并清零
9. 回读校验
```

> 注意：**目录必须预留连续块**（128 项），这是 v2 的约束，格式化时就要留好。

---

## 6. 风险与约束

| 风险 | 缓解 |
|---|---|
| 误格式化系统盘/数据盘 | 设备标记 protected + 手输编号 + 二次确认 |
| 掉电导致半格式化 | 先写数据区，再写超级块（超级块最后写，magic 出现即视为完成） |
| 容量识别错误 | 以 UEFI Block I/O 的 `LastBlock` 为准，交叉校验 |
| 格式化后旧数据泄漏 | 提供「安全擦除」选项（可选，写零，慢） |

---

## 7. 实施阶段

| 阶段 | 内容 | 依赖 | 工作量 |
|---|---|---|---|
| F1 | 引导期维护模式（枚举设备 + 格式化 + 校验） | UEFI Block I/O | 中 |
| F2 | `fsck` 维护菜单项 | 现有 `fms_fsck` | 小 |
| F3 | 多块设备枚举 + 块设备抽象层 | virtio 扫描 | 中 |
| F4 | 终端 `format` / `mount` | F3 | 中 |

**建议**：先做 F1（对用户最有用，且不碰内核驱动），F3/F4 等有多盘需求时再做。

---

## 8. 与更新方案的关系

- 格式化工具可以顺带实现「安装系统到磁盘」：写入 FMS64 + 复制 `BOOTX64.EFI` 到 FAT32 引导分区
- 这与 `docs/UPDATE.md` 共享同一套 FAT32 写能力，应一起实现，避免重复开发
