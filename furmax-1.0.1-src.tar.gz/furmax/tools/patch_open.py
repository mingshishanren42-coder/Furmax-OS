p = 'src/boot/wm.c'
s = open(p).read()

# 1) 首次预装示例办公文件
s = s.replace('''                    fms_write(".SEEDED", "1", 1);''', '''                    static const char sheet[] =
                        "PROJECT,FILES,STATUS,OWNER\\n"
                        "FURMAX,12,ACTIVE,CORE\\n"
                        "KERNEL,48,ACTIVE,CORE\\n"
                        "UI,26,REVIEW,TEAM\\n"
                        "DOCS,9,PLANNED,TEAM\\n";
                    static const char doc[] =
                        "FURMAX OS\\nPRODUCT BRIEF\\n"
                        "FURMAX IS A GRAPHICAL OPERATING SYSTEM\\n"
                        "BUILT FROM SCRATCH.\\n"
                        "OWN KERNEL, COMPOSITOR AND FILESYSTEM.\\n"
                        "THIS IS A SAMPLE .PVC DOCUMENT.\\n";
                    static const char deck[] =
                        "FURMAX OS\\nA NEW GRAPHICAL SYSTEM\\n"
                        "---\\n"
                        "ARCHITECTURE\\nOWN KERNEL\\nOWN COMPOSITOR\\nOWN FILESYSTEM\\n"
                        "---\\n"
                        "STATUS\\nBOOT TO DESKTOP\\nUSER MODE APPS\\nDISK PERSISTENCE\\n";
                    fms_write("SHEET.CVP", sheet, (unsigned int)(sizeof(sheet) - 1));
                    fms_write("DOC.PVC", doc, (unsigned int)(sizeof(doc) - 1));
                    fms_write("DECK.VPC", deck, (unsigned int)(sizeof(deck) - 1));
                    fms_write(".SEEDED", "1", 1);''')

# 2) 打开文件时按扩展名选择视图
old = '''                    if (file_count > 0 && file_sel < file_count) {
                        Win *ew = &wins[1];
                        unsigned int sz = 0;
                        mfs_read(files[file_sel].name, ew->text, (unsigned int)sizeof(ew->text) - 1, &sz);
                        ew->tlen = (int)(sz < sizeof(ew->text) - 1 ? sz : sizeof(ew->text) - 1);
                        int k = 0;
                        for (; files[file_sel].name[k] && k < 47; k++) ew->fname[k] = files[file_sel].name[k];
                        ew->fname[k] = 0;
                        focus_window(1);
                        raise_to_front(1);
                        panel = PANEL_NONE;
                    }'''
new = '''                    if (file_count > 0 && file_sel < file_count) {
                        Win *ew = &wins[1];
                        int k = 0;
                        for (; files[file_sel].name[k] && k < 47; k++) ew->fname[k] = files[file_sel].name[k];
                        ew->fname[k] = 0;

                        viewlen = 0;
                        viewbuf[0] = 0;
                        mfs_read(files[file_sel].name, viewbuf, sizeof(viewbuf) - 1, &viewlen);
                        viewbuf[viewlen < sizeof(viewbuf) ? viewlen : sizeof(viewbuf) - 1] = 0;

                        if (ends_with(ew->fname, ".cvp")) { ew->view = 1; sheet_row = sheet_col = 0; }
                        else if (ends_with(ew->fname, ".pvc")) { ew->view = 2; doc_scroll = 0; }
                        else if (ends_with(ew->fname, ".vpc")) { ew->view = 3; slide_idx = 0; }
                        else {
                            ew->view = 0;
                            unsigned int sz = viewlen;
                            ew->tlen = (int)(sz < sizeof(ew->text) - 1 ? sz : sizeof(ew->text) - 1);
                            for (int i = 0; i < ew->tlen; i++) ew->text[i] = viewbuf[i];
                        }

                        focus_window(1);
                        raise_to_front(1);
                        panel = PANEL_NONE;
                    }'''
assert old in s, 'open handler not found'
s = s.replace(old, new)

# 3) 视图内导航
anchor = '''            Win *w = &wins[focus];
            if (!w->open) continue;'''
assert anchor in s
s = s.replace(anchor, anchor + '''

            if (w->view) {
                if (c == KEY_ESC) { w->view = 0; dirty = changed = 1; continue; }
                if (w->view == 1) {
                    if (c == KEY_LEFT && sheet_col > 0) sheet_col--;
                    if (c == KEY_RIGHT && sheet_col < 7) sheet_col++;
                    if (c == KEY_UP && sheet_row > 0) sheet_row--;
                    if (c == KEY_DOWN && sheet_row < 11) sheet_row++;
                } else if (w->view == 2) {
                    if (c == KEY_UP && doc_scroll > 0) doc_scroll--;
                    if (c == KEY_DOWN && doc_scroll < 40) doc_scroll++;
                } else if (w->view == 3) {
                    if ((c == KEY_LEFT || c == KEY_UP) && slide_idx > 0) slide_idx--;
                    if (c == KEY_RIGHT || c == KEY_DOWN) slide_idx++;
                }
                dirty = changed = 1;
                continue;
            }''')

open(p, 'w').write(s)
print('ok')
