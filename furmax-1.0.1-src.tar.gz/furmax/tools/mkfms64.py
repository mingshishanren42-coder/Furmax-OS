#!/usr/bin/python3
"""生成 FMS64 磁盘镜像（v0 布局：超级块 / 位图 / inode 表 / 数据区）。"""
import struct, sys

MAGIC = b'FMS64\0\0\0'
BLOCK = 512
INODE_COUNT = 64
DATA_START = 41          # 1 + 32 + 8

def add_file(img, bitmap, inode_index, name, data):
    """按 FMS64 v0 布局写入一个文件（连续块）。"""
    total = len(img) // BLOCK
    used = set()
    for b in range(total):
        if bitmap[b // 8] >> (b % 8) & 1:
            used.add(b)
    need = max(1, (len(data) + BLOCK - 1) // BLOCK)
    first = None
    run = 0
    for b in range(33 + 8, total):
        if b in used:
            run = 0
            continue
        if run == 0:
            start = b
        run += 1
        if run == need:
            first = start
            break
    if first is None:
        raise SystemExit('no space')
    for k in range(need):
        bitmap[(first + k) // 8] |= 1 << ((first + k) % 8)
    leaf = name.split('/')[-1]
    inode = struct.pack('<IIII', 1, len(data), first, need) + leaf.encode()[:39].ljust(40, b'\0') + struct.pack('<II', 0, 0)
    off = 33 * BLOCK + inode_index * 64
    img[off:off + 64] = inode
    img[first * BLOCK:first * BLOCK + len(data)] = data


def make(path, mb=64, extra=None):
    total_blocks = mb * 1024 * 1024 // BLOCK
    bitmap_blocks = (total_blocks + 8 * BLOCK - 1) // (8 * BLOCK)
    inode_blocks = (INODE_COUNT * 64 + BLOCK - 1) // BLOCK
    super_ = struct.pack('<8sIIIIIIIII', MAGIC, BLOCK, total_blocks, 1,
                         bitmap_blocks, 33, inode_blocks, 33 + inode_blocks,
                         INODE_COUNT, 0)

    img = bytearray(total_blocks * BLOCK)
    img[0:len(super_)] = super_

    # 位图：标记超级块、位图、inode 区已用
    bitmap = bytearray(bitmap_blocks * BLOCK)
    for b in range(0, 33 + inode_blocks):
        bitmap[b // 8] |= 1 << (b % 8)
    img[1 * BLOCK:1 * BLOCK + len(bitmap)] = bitmap

    add_file(img, bitmap, 1, 'README.TXT',
             b'Furmax OS FMS64\nWritten by mkfms64 on host.\n')
    add_file(img, bitmap, 2, 'PROJECTS.CVP',
             b'project,files,status\nfurmax,12,active\n')

    entries = [(1, 'README.TXT'), (2, 'PROJECTS.CVP')]
    next_ino = 3
    for name, fp in (extra or []):
        add_file(img, bitmap, next_ino, name, open(fp, 'rb').read())
        entries.append((next_ino, name))
        next_ino += 1

    # inode 0：根目录
    root_blk = None
    for b in range(33 + inode_blocks, total_blocks - 8):
        free = True
        for k in range(8):
            if bitmap[(b + k) // 8] >> ((b + k) % 8) & 1:
                free = False
                break
        if free:
            root_blk = b
            break
    if root_blk is None:
        raise SystemExit('no space for root dir')
    for k in range(8):
        bitmap[(root_blk + k) // 8] |= 1 << ((root_blk + k) % 8)
    ents = b''
    for ino, nm in entries:
        ents += struct.pack('<I28s', ino, nm.encode()[:27])
    img[root_blk * BLOCK:root_blk * BLOCK + len(ents)] = ents
    root = struct.pack('<IIII', 2, len(ents), root_blk, 8) + b''.ljust(40, b'\0') + struct.pack('<II', 0, 0)
    img[33 * BLOCK:33 * BLOCK + 64] = root

    img[1 * BLOCK:1 * BLOCK + len(bitmap)] = bitmap
    open(path, 'wb').write(img)

if __name__ == '__main__':
    extra = []
    for a in sys.argv[2:]:
        if '=' in a:
            nm, fp = a.split('=', 1)
            extra.append((nm, fp))
    make(sys.argv[1] if len(sys.argv) > 1 else 'build/furmax-data.img', 64, extra)
    print('formatted')
