#!/usr/bin/python3
"""把两个二进制文件写进一个 C 头文件。"""
import sys
a, b, dst = sys.argv[1], sys.argv[2], sys.argv[3]
da, db = open(a, 'rb').read(), open(b, 'rb').read()
lines = ['/* 由 tools/bin2c2.py 生成 */', '#ifndef FURMAX_APPS_BLOB_H', '#define FURMAX_APPS_BLOB_H', '',
         f'static const unsigned char hello_fx[{len(da)}] = {{']
for i in range(0, len(da), 16):
    lines.append('    ' + ','.join('0x%02x' % x for x in da[i:i+16]) + ',')
lines += ['};', f'#define HELLO_FX_LEN {len(da)}', '',
          f'static const unsigned char greet_fx[{len(db)}] = {{']
for i in range(0, len(db), 16):
    lines.append('    ' + ','.join('0x%02x' % x for x in db[i:i+16]) + ',')
lines += ['};', f'#define GREET_FX_LEN {len(db)}', '', '#endif']
open(dst, 'w').write('\n'.join(lines) + '\n')
print('apps blob ok')
