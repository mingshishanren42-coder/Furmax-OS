#!/usr/bin/python3
"""把开机画面 Logo 转成 4bpp 灰度遮罩 C 头文件（20 级透明）。

用法: make_logo.py <输入图> <输出头文件> [目标宽度]
每像素 4 位：0=全黑，15=纯白；按行高四位在前打包。
"""
import sys
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
target_w = int(sys.argv[3]) if len(sys.argv) > 3 else 1200

im = Image.open(src).convert("L")
bbox = im.point(lambda v: 255 if v > 20 else 0).getbbox()
if bbox:
    im = im.crop(bbox)
w, h = im.size
im = im.resize((target_w, max(1, round(h * target_w / w))), Image.LANCZOS)
w, h = im.size
px = im.load()

row_bytes = (w + 1) // 2
data = bytearray()
for y in range(h):
    for bx in range(row_bytes):
        x0 = bx * 2
        a = min(15, (px[x0, y] * 15 + 127) // 255) if x0 < w else 0
        b = min(15, (px[x0 + 1, y] * 15 + 127) // 255) if x0 + 1 < w else 0
        data.append((a << 4) | b)

lines = ["/* 由 tools/make_logo.py 生成，勿手改。Furmax OS 开机标志（4bpp 遮罩） */",
         "#ifndef FURMAX_LOGO_H", "#define FURMAX_LOGO_H", "",
         f"#define LOGO_W {w}", f"#define LOGO_H {h}", "",
         f"static const unsigned char LOGO_BITS[{len(data)}] = {{"]
for i in range(0, len(data), 16):
    lines.append("    " + ",".join("0x%02x" % b for b in data[i:i+16]) + ",")
lines += ["};", "", "#endif"]
open(dst, "w").write("\n".join(lines) + "\n")
print(f"logo {w}x{h}, {len(data)} bytes -> {dst}")
