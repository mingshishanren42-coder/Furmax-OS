#!/usr/bin/python3
"""把扁平二进制包成 .fx 可执行文件：magic + 头部 + 代码。"""
import struct, sys

src, dst = sys.argv[1], sys.argv[2]
code = open(src, 'rb').read()
header = b'FX01' + struct.pack('<II', len(code), 0)   # magic, code_size, entry_off
open(dst, 'wb').write(header + code)
print(f'{dst}: {len(code)} bytes code')
