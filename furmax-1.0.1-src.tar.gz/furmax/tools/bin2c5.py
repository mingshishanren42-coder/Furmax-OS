#!/usr/bin/python3
import sys
files = sys.argv[1:6]; dst = sys.argv[6]
names = ['hello_fx','greet_fx','ticker_fx','copy_fx','ui_fx']
lines = ['/* 由 tools/bin2c5.py 生成 */', '#ifndef FURMAX_APPS_BLOB_H', '#define FURMAX_APPS_BLOB_H', '']
for path, name in zip(files, names):
    d = open(path,'rb').read()
    lines.append(f'static const unsigned char {name}[{len(d)}] = {{')
    for i in range(0, len(d), 16):
        lines.append('    ' + ','.join('0x%02x' % x for x in d[i:i+16]) + ',')
    lines += ['};', f'#define {name.upper()}_LEN {len(d)}', '']
lines.append('#endif')
open(dst,'w').write('\n'.join(lines) + '\n')
print('apps blob (5) ok')
