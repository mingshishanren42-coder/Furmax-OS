#!/usr/bin/env python3
"""把 font.art 转成 C 头文件（5x7 点阵，ASCII 32..126 覆盖）。"""
import sys

def code_of(name):
    if name == 'space': return 32
    if len(name) == 1: return ord(name)
    raise SystemExit('unknown glyph name: ' + name)

lines = [l.rstrip('\n') for l in open(sys.argv[1], encoding='utf-8') if l.strip() != '']
glyphs = {}
i = 0
while i < len(lines):
    name = lines[i].strip()
    rows = lines[i+1:i+8]
    if len(rows) != 7 or any(len(r) != 5 for r in rows):
        raise SystemExit(f'bad glyph {name}: {rows}')
    bits = []
    for r in rows:
        v = 0
        for ch in r:
            v = (v << 1) | (1 if ch == '#' else 0)
        bits.append(v)
    glyphs[code_of(name)] = bits
    i += 8

out = ['/* 由 tools/gen_font.py 生成，勿手改。Furmax OS 自有 5x7 点阵字体 */',
       '#ifndef FURMAX_FONT5X7_H', '#define FURMAX_FONT5X7_H', '',
       'static const unsigned char FONT5X7[95][7] = {']
for c in range(32, 127):
    bits = glyphs.get(c, [0]*7)
    out.append('    {' + ','.join('0x%02x' % b for b in bits) + '}, /* %s */' % (
        rep := (chr(c) if 32 < c < 127 else 'space')))
out += ['};', '', '#endif']
open(sys.argv[2], 'w').write('\n'.join(out) + '\n')
print('glyphs:', len(glyphs), '->', sys.argv[2])
