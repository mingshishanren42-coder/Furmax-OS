#!/usr/bin/python3
"""把二进制文件转成 C 数组头文件。"""
import sys
src, dst, name = sys.argv[1], sys.argv[2], sys.argv[3]
data = open(src, 'rb').read()
lines = [f'/* 由 tools/bin2c.py 生成：{name} */', '#ifndef FURMAX_BLOB_H', '#define FURMAX_BLOB_H', '',
         f'static const unsigned char {name}[{len(data)}] = {{']
for i in range(0, len(data), 16):
    lines.append('    ' + ','.join('0x%02x' % b for b in data[i:i+16]) + ',')
lines += ['};', f'#define {name.upper()}_LEN {len(data)}', '', '#endif']
open(dst, 'w').write('\n'.join(lines) + '\n')
print(f'{name}: {len(data)} bytes')
