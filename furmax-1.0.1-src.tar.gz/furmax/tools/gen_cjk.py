#!/usr/bin/python3
"""从 TTF/TTC 生成 14x14 中文点阵 C 头文件。"""
import sys
from PIL import Image, ImageFont, ImageDraw

FONT = '/system/fonts/NotoSansCJK-Regular.ttc'
SIZE = 14
TEXT_FILE = 'tools/cjk_text.txt'
OUT = 'src/boot/cjk_font.h'

chars = []
with open(TEXT_FILE, encoding='utf-8') as f:
    for line in f:
        for ch in line.strip():
            if ord(ch) > 0x7F and ch not in chars:
                chars.append(ch)

font = ImageFont.truetype(FONT, SIZE + 1, index=0)  # SC
glyphs = []
for ch in chars:
    img = Image.new('L', (SIZE, SIZE), 0)
    d = ImageDraw.Draw(img)
    d.text((SIZE / 2, SIZE / 2), ch, fill=255, font=font, anchor='mm')
    rows = []
    for y in range(SIZE):
        bits = 0
        for x in range(SIZE):
            if img.getpixel((x, y)) > 90:
                bits |= 1 << (SIZE - 1 - x)
        rows.append(bits)
    data = []
    acc = 0; n = 0
    for r in rows:
        for x in range(SIZE):
            acc = (acc << 1) | ((r >> (SIZE - 1 - x)) & 1)
            n += 1
            if n == 8:
                data.append(acc); acc = 0; n = 0
    if n:
        data.append(acc << (8 - n))
    glyphs.append((ord(ch), data))

lines = ['/* 自动生成：tools/gen_cjk.py，字体 Noto Sans CJK SC %dpx */' % SIZE,
         '#ifndef FURMAX_CJK_FONT_H',
         '#define FURMAX_CJK_FONT_H',
         '',
         '#define CJK_W %d' % SIZE,
         '#define CJK_H %d' % SIZE,
         '#define CJK_STRIDE %d' % len(glyphs[0][1]),
         '#define CJK_COUNT %d' % len(glyphs),
         '',
         'typedef struct { unsigned int cp; unsigned char bits[CJK_STRIDE]; } CjkGlyph;',
         '',
         'static const CjkGlyph cjk_glyphs[CJK_COUNT] = {']
for cp, data in glyphs:
    body = ','.join('0x%02x' % b for b in data)
    lines.append('    { 0x%04x, { %s } },' % (cp, body))
lines += ['};', '', '#endif', '']
open(OUT, 'w').write('\n'.join(lines))
print('glyphs:', len(glyphs), '->', OUT)
