#!/usr/bin/python3
"""生成离线更新包 UPDATE.PKG（FXU1）。"""
import hashlib, struct, sys

def make(payload_path, version, out, flags=0):
    data = open(payload_path, 'rb').read()
    major, minor, patch = [int(x) for x in version.split('.')]
    ver = (major << 16) | (minor << 8) | patch
    head = b'FXU1' + struct.pack('<II', ver, 1) + struct.pack('<I', len(data))
    head += hashlib.sha256(data).digest()
    head += struct.pack('<II', flags, 0)
    assert len(head) == 56, len(head)
    open(out, 'wb').write(head + data)
    print(f'{out}: v{version} payload={len(data)}')

if __name__ == '__main__':
    make(sys.argv[1], sys.argv[2], sys.argv[3])
