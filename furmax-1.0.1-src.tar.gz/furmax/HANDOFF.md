# Furmax OS 交接文档（HANDOFF）

> 当前版本：**Furmax OS 1.0.1（基础测试版）**，版本说明见 `RELEASE-1.0.1.md`。
> 许可：Apache-2.0（见 `LICENSE`），第三方声明见 `NOTICE.md`，贡献需同意 `CLA.md`。
> 格式化方案：`docs/FORMAT.md`（FMS64 磁盘格式化，设计定稿、未实现）
> 更新方案：`docs/UPDATE.md`（离线更新包 B 方案，设计定稿、未实现）
> 应用开发规范：`docs/APP-DEV.md`（.fx 格式、系统调用、事件、权限、禁忌）
> 新会话从这里开始：读本文件 + `README.md`，再决定下一步。
> 项目根目录：`/root/workspace/furmax`

## 一句话状态

自研图形操作系统原型：UEFI 引导 → 自有内核接管 → 桌面/窗口/四向面板 → 用户态应用（.fx）+ 多任务调度 + 持久化文件系统 + 办公文件视图 + 终端。

## 架构地图

```
src/boot/
  main.c        UEFI 引导、GOP 初始化、ExitBootServices、交接内核
  wm.c          窗口管理、四向面板、编辑器/表格/文档/幻灯片视图、终端、文件池/应用池
  gfx.c/h       帧缓冲绘制（矩形/圆角/渐变/文字）
  ps2.c/h       PS/2 鼠标（IRQ12）+ 键盘字节排空
  efi.h         最小 UEFI 定义（自有，不依赖 gnu-efi）
src/kernel/
  idt.c         中断表、8259 PIC、PIT 100Hz
  paging.c      内核自有页表（0–4GB 恒等映射，含 U 位）
  gdt.c         自有 GDT + TSS
  sched.c       任务调度、任务槽位、应用窗口绘制指令队列、事件队列
  usermode.c    系统调用处理
  um.asm        um_enter / um_resume / um_exit_stub
  isr.asm       256 个中断桩 + 公共入口
  mfs.c         内存文件系统（最多 32 文件）
  fms64.c       FMS64 磁盘文件系统（超级块/位图/inode/数据区）
  virtio.c      legacy virtio-blk 驱动（轮询 virtqueue）
  ata.c         IDE PIO 驱动（回退用，写不可靠）
  fsops.c       文件写穿（内存 FS → 磁盘）共享层
  kmem.c        物理内存 bump 分配器（基于 UEFI 内存映射）
  klog.c        串口日志（COM1）
src/user/       .fx 应用汇编源码（hello/greet/ticker/copy/ui/click/notepad）
tools/          字体/logo 生成、.fx 打包、二进制转 C 数组、宿主机 FMS64 镜像工具
scripts/        build.sh、run_qemu.py、record.py、interact.py、ppm2png.py
docs/DESIGN.md  设计规范（唯一实现依据）
```

## 构建与运行

```sh
cd /root/workspace/furmax
./scripts/build.sh                 # 产出 build/furmax.img + build/furmax-data.img
python3 scripts/run_qemu.py 30     # 无头运行并截图到 build/screenshots/
```

QEMU 需要两块盘：启动盘 `furmax.img`（IDE），数据盘 `furmax-data.img`（**virtio**）。
固件用 `/usr/share/OVMF/OVMF_CODE_4M.fd` + 可写 VARS 副本。

## 已完成里程碑

| 编号 | 内容 |
|---|---|
| M0–M1 | UEFI 引导、GOP 图形、自有字体、开机画面 |
| M2 | ExitBootServices、IDT、8259、PIT、内存映射分配 |
| M3 | PS/2 键鼠、文本输入、窗口层级 |
| M4 | 四向面板（文件池/动效视窗/应用池/设置） |
| M5 | 分页 + 内存文件系统 MFS + 内置编辑器 |
| M6 | FMS64 磁盘文件系统（virtio 后端） |
| M7 | 用户态 ring3 + 系统调用 + .fx 加载器 |
| M8–M10 | 多任务调度、任务窗口绑定、时间片、动效视窗真实数据 |
| M11–M12 | virtio-blk 驱动、MFS 与磁盘统一（写穿 + 启动导入） |
| M13 | 应用池改为磁盘来源、删除持久化（`.SEEDED` 预装一次） |
| M14 | 办公格式视图：.cvp 表格 / .pvc 文档 / .vpc 幻灯片 |
| M15 | 表格编辑（单元格编辑、回车提交、写回 CSV 落盘） |
| M16 | 用户态文件系统调用 read_file/write_file，COPY.FX |
| M17–M18 | TMI 终端：ls/cat/cp/mv/rm/run/ps/df/echo/uptime、历史、Tab 补全、自动换行 |
| M19–M20 | 窗口绘制调用（ui_clear/ui_text/ui_rect）、输入事件（ui_poll） |
| M21 | 用户态记事本 NOTEPAD.FX（读文件/编辑/F2 保存/Esc 退出） |
| M22 | 图像显示：ui_image 系统调用 + IMG.FX 渐变示例 |
| M23 | 任务终止：关闭应用窗口 / `kill NAME` 结束任务，槽位回收 |
| M24 | 应用参数：`run APP ARG` + `get_arg`（串口已确认参数到达任务），终端连续输入丢字待修 |

## 系统调用表（int 0x80）

| 号 | 名称 | 参数 | 说明 |
|---|---|---|---|
| 1 | write | rdi=ptr, rsi=len | 输出到本任务窗口（旧式） |
| 2 | exit | — | 结束任务 |
| 3 | read_file | rdi=名字, rsi=buf, rdx=max | 返回字节数 |
| 4 | write_file | rdi=名字, rsi=buf, rdx=len | 写文件并落盘 |
| 5 | ui_clear | rdi=颜色 | 清空本任务窗口指令 |
| 6 | ui_text | rdi=x, rsi=y, rdx=颜色, rcx=文本 | 画文字 |
| 7 | ui_rect | rdi=x, rsi=y, rdx=w, rcx=h, r8=颜色 | 画矩形 |
| 8 | ui_poll | rdi=事件buf | 事件 {type,x,y,key}，返回 1/0 |

用户指针都会被校验是否落在该任务的 2MB 用户区内。

## 快捷键

- `Ctrl+←/↑/→/↓`：文件池 / 动效视窗 / 应用池 / 系统设置
- `F2`：应用内使用（记事本保存）
- `F3`：聚焦 TMI 终端
- `F5`：一次启动 TICKER/HELLO/GREET 三个任务
- `Esc`：关闭面板 / 退出视图 / 应用内退出
- 窗口按钮（右→左）：红=关闭（并结束应用任务）、绿=最大化/还原、橙=最小化

## 已知问题（下次优先）

1. **ATA PIO 写入不可靠**（已用 virtio 替代，ATA 仅回退）。
   - 已修：MFS/导入/列表三处文件上限（16 → 32），大文件（>4KB）导入缓冲区扩到 8KB。
2. **MFS 上限 32 文件**，超出静默丢弃；需要时可再提高并做 LRU。
3. **任务槽位已扩到 6 个**（窗口表 9 个），任务窗口按 3×2 网格排布；系统窗口仍固定位置，可能与网格重叠，`Wins` 只有 3 个应用窗口；扩到更多需要动态窗口表。
4. **.fx 最大 3 页（12KB）**，加载器限制。
5. **办公视图只读**（文档/幻灯片），表格可编辑但不支持公式、列宽。
6. **应用无参数传递（argc/argv）**、无标准输入，终端不能直接运行 .fx 并传参。
7. **无线程/进程隔离**：所有任务共享内核地址空间，仅靠不同 VA 区段隔离。
8. **快速输入（已修复，待长期观察）**
   - 根因：整屏重绘约 400–500ms，每次按键都要等一次全屏合成，期间 8042 缓冲被顶掉。
   - 修复：**脏矩形渲染**——主循环只标记变化区域（打字时是焦点窗口矩形），render 只恢复该区域壁纸、
     裁剪后重绘相交窗口、只提交该区域；`present` 改为 64 位整行拷贝。
   - 验证：0.25 秒/键连打 6 个字符全部到达并落到 `NOTE.TXT`（此前只到 1 个）。
   - 扩展：鼠标移动只刷新旧/新光标矩形；窗口拖动只重绘旧+新窗口矩形；
     `present_rect` 只提交变化区域（不再每帧整屏拷贝）。
   - 注意：早期日志里看到的 `HIHIHI` 是**已保存文件内容**被加载显示，不是重复输入。
