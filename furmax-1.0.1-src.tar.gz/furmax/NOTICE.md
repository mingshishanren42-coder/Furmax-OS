# NOTICE

Furmax OS
Copyright 2026 Deepblue Network

本产品基于 Apache License 2.0 发布（见 `LICENSE`）。
依据该许可证第 4(d) 条，若分发本软件或其衍生作品，须一并保留本 NOTICE 文件的内容。

## 商标

"Furmax"、"Furmax OS"、"Deepblue Network" 为项目所有者的名称与标识。
Apache License 2.0 第 6 条明确不授予商标权：你可以分发基于本项目的衍生版本，
但不得以"Furmax"名义发布，也不得暗示获得官方背书。

## 第三方组件

### 1. Noto Sans CJK（中文字形）

- 用途：`tools/gen_cjk.py` 从 `NotoSansCJK-Regular.ttc` 渲染 14×14 点阵，生成 `src/boot/cjk_font.h`
- 许可：SIL Open Font License 1.1（OFL-1.1）
- 义务：分发时须保留版权与许可声明，并附带 OFL 全文；衍生字形不得使用保留字体名
- 说明：OFL 与本项目的 Apache-2.0 兼容，但字体部分仍受 OFL 约束

### 2. 构建与测试工具（不随软件分发）

| 工具 | 许可 | 说明 |
|---|---|---|
| GNU binutils / GCC | GPL | 仅作编译工具，不链接进产物 |
| NASM | BSD-2-Clause | 汇编器 |
| Python 3 / Pillow | PSF / HPND | 构建脚本与资源生成 |
| QEMU | GPLv2 | 仅用于测试 |
| OVMF / TianoCore | BSD-2-Clause | 仅用于测试固件 |

## 用户素材

`assets/` 下的 Furmax 开机 Logo 由 Deepblue Network 提供，随本项目以 Apache-2.0 授权。
