# Furmax OS 1.0.1（基础测试版）

> 许可：**Apache License 2.0**（见 [LICENSE](LICENSE)），商标与第三方组件见 [NOTICE.md](NOTICE.md)，贡献需同意 [CLA](CLA.md)
> 版本说明见 [RELEASE-1.0.1.md](RELEASE-1.0.1.md)　应用开发规范见 [docs/APP-DEV.md](docs/APP-DEV.md)　更新方案见 [docs/UPDATE.md](docs/UPDATE.md)　格式化方案见 [docs/FORMAT.md](docs/FORMAT.md)

# Furmax OS

全新的图形操作系统原型：自有内核方向、自有图形栈、自有字体、FMS64 文件系统设计。
设计规范见 [docs/DESIGN.md](docs/DESIGN.md)。

## 当前状态

| 里程碑 | 内容 | 状态 |
|---|---|---|
| M0 | x86-64 UEFI 引导，固件交接 | ✅ |
| M1 | GOP 帧缓冲、自有 5x7 字体、开机画面 | ✅ |
| M1.5 | 窗口管理器原型：拖动、聚焦换透明度、灰条按钮 | ✅ 原型 |
| M2 | 内核接管：ExitBootServices、IDT、8259 中断、PIT 定时器 | ✅ |
| M3 | 物理内存分配（UEFI 内存映射）、PS/2 键盘与鼠标、文本输入、窗口层级 | ✅ |
| M4 | 四向面板：文件池、动效视窗、应用池、系统设置 | ✅ 原型 |
| M5 | 内核分页 + 内存文件系统 MFS + 编辑器 | ✅ 新建/追加/删除/打开/编辑/保存 |
| M6 | 磁盘文件系统 FMS64 | ✅ 经 virtio-blk 读写，落盘正常 |
| M7 | 用户态：ring3 + 系统调用 + .fx 加载器 | ✅ 应用池可启动 .fx 程序 |
| M8 | 多任务调度 | ✅ 最多 3 个用户任务，时钟中断轮转 |
| M9 | 任务与窗口绑定 | ✅ 每个任务一个窗口，输出进各自窗口 |
| M10 | 时间片调度 + 动效视窗真实数据 | ✅ 界面与任务共存，视窗显示任务名/状态/输出量 |
| M11 | virtio-blk 驱动 | ✅ 替代 IDE PIO，FMS64 写入落盘 |
| M12 | MFS 与磁盘统一 | ✅ 启动导入磁盘文件，编辑写穿，重启后文件仍在 |
| M13 | 应用池改为磁盘来源 | ✅ 列出磁盘 .fx、可运行、可删除（预装只做一次） |
| M14 | 办公格式基础视图 | ✅ .cvp 表格 / .pvc 文档 / .vpc 幻灯片（只读） |
| M15 | 表格可编辑 | ✅ 单元格编辑、提交即写回 CSV 并落盘 |
| M16 | 用户态文件系统调用 | ✅ read_file / write_file，示例 COPY.FX 复制文件 |
| M17 | TMI 终端 | ✅ 命令解析与输出 |
| M18 | 终端完善 | ✅ 自动换行、命令历史、Tab 补全、cp/mv/ps/df/echo/uptime |
| M19 | 窗口系统调用 | ✅ 应用可自绘窗口（清屏/矩形/文字），示例 UI.FX |
| M20 | 输入事件 | ✅ 点击/按键进任务事件队列，ui_poll 取用，示例 CLICK.FX |
| M21 | 用户态记事本 | ✅ NOTEPAD.FX：读 NOTE.TXT、编辑、F2 保存、Esc 退出 |
| M22 | 图像显示 | ✅ ui_image 系统调用，示例 IMG.FX 绘制 32×32 渐变 |
| M23 | 任务终止 | ✅ 关闭应用窗口或 `kill NAME` 结束任务并回收槽位 |
| M24 | 应用参数 | ⚠️ 接口与链路已通；长命令行丢字（驱动层，已知问题 #8） |
| M25 | 终端历史/补全 | ✅ ↑↓ 调历史、Tab 补文件名（已截图验证） |

## 构建

```sh
./scripts/build.sh          # 生成 build/furmax.img
```

依赖：`nasm qemu-system-x86 ovmf gcc-x86-64-linux-gnu binutils-x86-64-linux-gnu mtools dosfstools`

## 运行

```sh
qemu-system-x86_64 -machine pc -m 256 \
  -drive if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd \
  -drive if=pflash,format=raw,unit=1,file=build/vars.fd \
  -drive file=build/furmax.img,format=raw,if=ide
```

或直接 `python3 scripts/run_qemu.py`（无头运行并截图到 `build/screenshots/`）。

## 已验证

- UEFI 引导 → 开机画面 → 桌面
- `ExitBootServices` 后内核独立运行：自有 IDT、IOAPIC 路由、APIC EOI、100Hz PIT
- 固件退出后鼠标（自写 PS/2 驱动）与键盘（IRQ1 + IRQ12）均可工作
- 窗口可拖动、点选置顶、聚焦换透明度；聚焦窗口可键入文字
- 内核内存分配器从 UEFI 内存映射挑选常规内存，界面显示可用容量
- Ctrl+←/↑/→/↓ 分别滑出文件池、动效视窗、应用池、系统设置，Esc 关闭

## 录屏

```sh
MACHINE=pc DURATION=24 /usr/bin/python3 scripts/record.py
# 输出 build/furmax-demo.mp4 与 build/furmax-demo.gif
```

脚本会从固件启动开始逐帧抓取，中途注入鼠标拖动与聚焦点击。

## 磁盘与文件系统

- `tools/mkfms64.py` 在宿主机生成 FMS64 镜像（超级块 / 位图 / inode 表 / 数据区），可预置文件。
- 内核侧 `src/kernel/ata.c` + `src/kernel/fms64.c` 提供挂载、列举、读写、删除。
- 编译时加 `EXTRA_CFLAGS=-DFMS_ENABLE` 会启用挂载与启动计数；**当前写盘在 QEMU IDE 从盘上不生效**，默认关闭以免影响启动。

## 内存文件系统（MFS）

`src/kernel/mfs.c`，跑在内核堆上，文件池直接操作：

- **N** 新建文件（`NOTE<n>.TXT`）
- **↑ / ↓** 选择
- **X** 删除选中文件
- **直接打字** 追加到选中文件
- **Enter** 在编辑器窗口打开选中文件
- 编辑器里编辑后 **Ctrl+S** 保存回文件（大小与预览立即更新）
- 面板显示字节数、已用空间与选中文件的内容预览

数据只在内存中，重启即清空——这是磁盘驱动完善前的过渡方案。

## TMI 终端

窗口标题 `TMI TERMINAL`，按 **F3** 直接聚焦。命令：

- `ls [目录]` 列出目录内容，`cd 目录` / `pwd` / `mkdir 目录`
- 目录实现：路径化文件名 + `.dir` 标记（`doc/.dir` 表示目录 `doc/`），支持相对/绝对路径
- `cat NAME` 显示文件内容
- `cp SRC DST` 复制文件，`mv SRC DST` 移动/改名
- `rm NAME` 删除文件（同时删磁盘副本）
- `run NAME` 启动 .fx 应用
- `kill NAME` 终止运行中的应用并关闭其窗口
- `ps` 列出用户任务及运行状态
- `df` 显示磁盘可用空间
- `echo TEXT` 输出文本，`uptime` 运行时长
- `clear` 清屏，`help` 命令列表

支持 **↑/↓ 命令历史**、**Tab 文件名补全**，输出超出窗口宽度会自动换行、超出高度只保留最新行。

## 用户态

- `src/kernel/gdt.c`：自有 GDT（ring0/ring3 段）+ TSS（ring3 进中断用的内核栈）
- `src/kernel/paging.c`：为用户区段建 4KB 页表并置 U 位
- `src/user/hello.asm`：第一个用户程序，通过 `int 0x80` 调用内核
- 系统调用：
  - `1 = write(ptr,len)` 输出到本任务窗口
  - `2 = exit`
  - `3 = read_file(name,buf,max)` 读文件（buf 必须在调用者用户区）
  - `4 = write_file(name,buf,len)` 写文件并落盘
  - `5 = ui_clear(color)` 清空本任务窗口
  - `6 = ui_text(x,y,color,ptr)` 在窗口画文字
  - `7 = ui_rect(x,y,w,h,color)` 在窗口画矩形
  - `8 = ui_poll(event_ptr)` 取一个输入事件（type 1=鼠标 2=按键），返回 1/0
  - `9 = ui_image(x,y,w,h,ptr)` 显示 RGBA 位图（≤64×64）
- 示例应用 `COPY.FX`：读取 `SHEET.CVP` 并复制为 `COPY.CVP`（验证用户态文件 I/O）
- 控制台窗口按 **F2** 运行 `HELLO.FX`，输出显示在窗口里，退出后回到内核

### 内置应用

- `NOTEPAD.FX`：读 `NOTE.TXT` → 编辑 → **F2 保存** → **Esc 退出**（全部走系统调用）
- `CLICK.FX`：点击事件演示
- `UI.FX`：自绘界面演示
- `COPY.FX`：文件复制（read_file + write_file）
- `TICKER.FX` / `HELLO.FX` / `GREET.FX`：多任务与输出演示

启动快捷键：`F5` 一次启动 TICKER/HELLO/GREET 三个任务（原先占用 F2，现已让给应用）。

### 故障与电源

- CPU 异常：串口记录向量/错误码/出错地址；**屏幕上弹出红色 SYSTEM FAULT 面板**（含任务名），
  `Esc` 清除；用户态任务出错只结束该任务，系统继续运行
- 终端 `shutdown` / `poweroff`：通过 ACPI 关机（QEMU 直接退出）
- 终端 `reboot`：复位系统

### 内存

- 内核堆：页粒度分块分配器，支持 `kmem_free()` 与相邻空闲块合并；分配/释放走关中断临界区
- 任务内存：页表 4KB + 最多 3 个用户页 + 4KB 栈；任务结束 / 槽位复用前自动归还
- 统计：`[mem] used=..KB free=..MB` 每次启动任务时输出到串口

### 系统服务

- 实时时钟：读 CMOS RTC，带 UTC+8 时区偏移；顶栏显示「时间 HH:MM」，终端 `date` 输出年月日时分秒

### 容量

- 任务槽位：**6 个**（可同时运行 6 个用户态程序）
- 应用窗口：9 个（3 个系统窗口 + 6 个任务窗口），任务窗口按 3×2 网格自动排布
- 每个任务独立 2MB 用户地址段

### 窗口按钮

标题栏右侧三个圆点（从右到左）：

| 颜色 | 功能 |
|---|---|
| 红 | 关闭窗口（应用窗口同时结束对应任务） |
| 绿 | 最大化 / 还原（留 8px 边距与底部托盘） |
| 橙 | 最小化 / 展开 |

拖动标题栏可移动窗口；鼠标移动、窗口拖动、文字输入都只重绘受影响区域。

### 应用输入

应用窗口获得焦点时，鼠标点击与键盘按键会进入该任务的事件队列（最多 16 条），
事件结构 `int type, x, y, key`。应用用 `ui_poll` 轮询，自行重绘界面。

### 多任务

- `src/kernel/sched.c`：每个任务独立 2MB 用户区（代码 + 栈），时钟中断里保存/恢复完整寄存器帧做轮转
- `exit` 系统调用会把任务标记结束并切到下一个；全部结束才回内核
- 在控制台窗口按 **F2** 会同时启动 `TICKER.FX`、`HELLO.FX`、`GREET.FX` 三个任务
- 每个任务有独立窗口，系统调用 `write` 的输出进入自己任务的窗口（不再共用一个控制台）
- **时间片**：任务每次运行约 25ms 就交还内核，界面在任务运行时依然流畅刷新
- **动效视窗**（Ctrl+↑）显示真实任务列表：名称、运行/结束状态、输出字节数

### 办公文件视图

在文件池里按字母可跳转（同字母再按一次切换下一个），Enter 按扩展名打开对应视图：

- **.cvp**：表格视图，列头 A–H、行号、表头行、单元格选中框
  - 方向键移动选区，**Enter** 编辑当前单元格（直接打字可覆盖）
  - 编辑中 **Enter** 提交并自动写回文件与磁盘，**Esc** 取消
- **.pvc**：文档视图，灰底白纸、标题与正文层级
- **.vpc**：幻灯片视图，左侧缩略图栏 + 16:9 画布，方向键翻页
- Esc 回到纯文本编辑模式

### .fx 可执行格式

```
偏移 0: "FX01"          魔数
偏移 4: u32 code_size   代码长度
偏移 8: u32 entry_off   入口偏移
偏移 12: 代码
```

- `tools/mkfx.py` 打包扁平二进制；`tools/bin2c2.py` 嵌入内核作为初始应用
- 应用池（Ctrl+→）列出磁盘上的 `.fx` 文件，↑↓ 选择、Enter 启动、X 删除
- 预装只在首次运行（`.SEEDED` 标记文件不存在时）发生，之后删除的应用不会被恢复
- 目前应用：`HELLO.FX`（F2 也触发）、`GREET.FX`

## 分页与磁盘文件系统

- **分页**：`src/kernel/paging.c` 在退出固件后自建页表，0–4GB 恒等映射为可读写（2MB 大页）。这一步解决了固件页表带来的写保护崩溃。
- **FMS64**：默认构建会挂载数据盘（`build/furmax-data.img`），文件池列出真实文件名与大小，并显示可用空间。
- **写入**：改由 `src/kernel/virtio.c`（legacy virtio-blk，轮询 virtqueue）承担，读写均正常落盘。
- **统一**：启动时把磁盘上的文件全部导入 MFS；新建 / 追加 / 保存 / 删除都会写穿到磁盘，重启后文件与内容保留。
- 已知现象：inode 表读取返回空，文件池只显示本次运行写入的 `BOOTCNT.TXT`；超级块与位图读取正常（可用空间 63MB 可信）。

## 致谢/工具

- `tools/mkfms64.py`：宿主机生成并预置文件的 FMS64 镜像。

## 目录

- `src/boot/`：引导与图形原型（EFI 应用）
- `tools/`：字体与标志点阵生成脚本
- `scripts/`：构建、运行、截图、交互测试
- `docs/`：设计规范
